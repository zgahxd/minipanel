#!/usr/bin/env python3
"""Run with sudo on the server; restarts panel to revoke all old sessions."""
import getpass
import json
import os
from pathlib import Path
import subprocess
import sys

if os.geteuid() != 0:
    raise SystemExit("请使用 sudo python3 reset-password.py")
sys.path.insert(0, "/opt/minipanel")
from app import make_config

password = getpass.getpass("新密码（至少 12 位）：")
if password != getpass.getpass("再输入一次："):
    raise SystemExit("两次密码不一致")
config = make_config(password)
target = Path("/etc/minipanel/auth.json")
target.write_text(json.dumps(config))
target.chmod(0o640)
subprocess.run(["systemctl", "restart", "minipanel"], check=True)
print("密码已更新，所有旧会话已失效。/root/minipanel-login.txt 中的初始密码已不再适用。")
