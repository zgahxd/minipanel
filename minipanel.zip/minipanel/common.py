"""Shared validation and fixed Nginx configuration generation."""
import ipaddress
import re


def domain_name(value):
    if not isinstance(value, str) or len(value) > 253:
        raise ValueError("请输入有效域名，不要包含协议、端口或路径")
    value = value.strip().lower().rstrip(".")
    try:
        value = value.encode("idna").decode("ascii")
    except UnicodeError:
        raise ValueError("域名格式不正确") from None
    if len(value) > 253 or "." not in value:
        raise ValueError("请输入完整域名，例如 example.com")
    if any(not re.fullmatch(r"[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?", p) for p in value.split(".")):
        raise ValueError("域名格式不正确")
    try:
        ipaddress.ip_address(value)
    except ValueError:
        return value
    raise ValueError("请填写域名，不是 IP 地址")


def database_name(value):
    if not isinstance(value, str) or not re.fullmatch(r"[a-z][a-z0-9_]{0,23}", value):
        raise ValueError("数据库名须以小写字母开头，只含小写字母、数字和下划线，最多 24 字符")
    return value


def nginx_config(domain, php_version, ssl=False, enabled=True, force_https=False):
    domain = domain_name(domain)
    if not re.fullmatch(r"\d+\.\d+", php_version):
        raise ValueError("PHP 版本无效")
    if force_https and not ssl:
        raise ValueError("请先启用网站 SSL，再开启强制 HTTPS")
    tls = ''
    if ssl:
        tls = f'''    listen 443 ssl;
    listen [::]:443 ssl;
    ssl_certificate /etc/minipanel/sites-ssl/{domain}/cert.pem;
    ssl_certificate_key /etc/minipanel/sites-ssl/{domain}/key.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_session_cache shared:MiniPanelSSL:10m;
'''
    if not enabled:
        return f'server {{\n    listen 80;\n    listen [::]:80;\n{tls}    server_name {domain};\n    return 503;\n}}\n'
    redirect = f'    if ($scheme = http) {{ return 308 https://{domain}$request_uri; }}\n' if force_https else ''
    return f'''# Managed by MiniPanel. Edit via the panel.
server {{
    listen 80;
    listen [::]:80;
{tls}\
    server_name {domain};
{redirect}\
    root /var/www/minipanel/{domain}/public;
    index index.php index.html;
    client_max_body_size 0;
    client_body_timeout 3600s;
    access_log /var/log/nginx/mp-{domain}.access.log;
    error_log /var/log/nginx/mp-{domain}.error.log;

    location / {{
        try_files $uri $uri/ /index.php?$query_string;
    }}
    location ~ /\\. {{ deny all; }}
    location ~* \\.(?:sql|bak|ini|log|conf|env)$ {{ deny all; }}
    location ~ \\.php$ {{
        try_files $uri =404;
        include fastcgi_params;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        fastcgi_read_timeout 3600s;
        fastcgi_send_timeout 3600s;
        fastcgi_pass unix:/run/php/php{php_version}-fpm.sock;
    }}
}}
'''
