"""Site-scoped filesystem operations, executed only after dropping to www-data."""
from contextlib import contextmanager
import os
import secrets
import stat
import tarfile
import time
import zipfile

CHUNK_SIZE = 256 * 1024
ARCHIVE_TIMEOUT = 1200
ARCHIVE_ENTRIES = 10000


@contextmanager
def archive_members(source, name):
    """Preflight every member before writing anything; never use extractall()."""
    lower = name.lower()
    try:
        if lower.endswith('.zip'):
            archive = zipfile.ZipFile(source)
        elif lower.endswith(('.tar', '.tar.gz', '.tgz', '.tar.bz2', '.tbz2', '.tar.xz', '.txz')):
            archive = tarfile.open(fileobj=source, mode='r:*')
        else:
            raise ValueError('支持 ZIP、TAR、TAR.GZ、TGZ、TAR.BZ2 和 TAR.XZ 压缩包')
        with archive:
            entries, seen = [], {}
            deadline = time.monotonic() + ARCHIVE_TIMEOUT
            items = archive.infolist() if isinstance(archive, zipfile.ZipFile) else archive
            for index, item in enumerate(items):
                if index >= ARCHIVE_ENTRIES or time.monotonic() > deadline:
                    raise ValueError('压缩包条目过多或解析超时（最多 10000 个条目）')
                if isinstance(archive, zipfile.ZipFile):
                    raw, directory, size = item.orig_filename, item.is_dir(), item.file_size
                    mode = item.external_attr >> 16
                    kind = stat.S_IFMT(mode)
                    if kind not in (0, stat.S_IFREG, stat.S_IFDIR) or item.flag_bits & 1:
                        raise ValueError('不支持含链接、特殊文件或加密内容的压缩包')
                else:
                    raw, directory, size = item.name, item.isdir(), item.size
                    if not (item.isdir() or item.isfile()) or item.issparse():
                        raise ValueError('不支持含链接、特殊文件或稀疏文件的压缩包')
                if '\x00' in raw or '\\' in raw or raw.startswith('/'):
                    raise ValueError('压缩包包含不安全路径')
                while raw.startswith('./'):
                    raw = raw[2:]
                raw = raw.rstrip('/') if directory else raw
                if raw in ('', '.') and directory:
                    continue
                parts = relative_path(raw)
                if not parts or len(parts) > 64 or any(':' in part for part in parts):
                    raise ValueError('压缩包包含不安全或过深的路径')
                if raw in seen:
                    raise ValueError('压缩包包含重复路径')
                seen[raw] = directory
                entries.append((raw, directory, size, item))
            for raw, directory, size, item in entries:
                parts = raw.split('/')
                if any(seen.get('/'.join(parts[:i])) is False for i in range(1, len(parts))):
                    raise ValueError('压缩包文件与目录路径冲突')
            def opener(item):
                return archive.open(item) if isinstance(archive, zipfile.ZipFile) else archive.extractfile(item)
            yield entries, opener
    except (zipfile.BadZipFile, tarfile.TarError, EOFError, NotImplementedError) as error:
        raise ValueError('压缩包损坏或压缩格式不受支持') from error


def copy_archive_member(source, target, size, deadline):
    remaining = size
    while remaining:
        if time.monotonic() > deadline:
            raise ValueError('解压超过 20 分钟，请使用 SSH 解压此文件')
        chunk = source.read(min(CHUNK_SIZE, remaining))
        if not chunk:
            raise ValueError('压缩包内容不完整')
        target.write(chunk)
        remaining -= len(chunk)


@contextmanager
def archive_directory(fd, parts):
    current = os.dup(fd)
    try:
        for part in parts:
            try:
                os.mkdir(part, mode=0o755, dir_fd=current)
            except FileExistsError:
                pass
            child = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=current)
            os.close(current)
            current = child
        yield current
    finally:
        os.close(current)


def extract_archive(root, data):
    destination = file_name(data.get('destination'))
    source, _ = open_download(root, data)
    created = False
    try:
        with source, archive_members(source, data['name']) as (entries, opener):
            with directory_fd(root, data.get('path', '')) as parent:
                free = os.fstatvfs(parent)
                if sum(size for _, directory, size, _ in entries if not directory) > free.f_bavail * free.f_frsize:
                    raise ValueError('磁盘剩余空间不足，未开始解压')
                # Always a new folder: never overwrite an existing website or follow links.
                os.mkdir(destination, mode=0o755, dir_fd=parent)
                created = True
                target = os.open(destination, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=parent)
                try:
                    deadline = time.monotonic() + ARCHIVE_TIMEOUT
                    for raw, directory, size, item in entries:
                        parts = raw.split('/')
                        with archive_directory(target, parts if directory else parts[:-1]) as folder:
                            if not directory:
                                fd = os.open(parts[-1], os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o644, dir_fd=folder)
                                with os.fdopen(fd, 'wb') as output, opener(item) as content:
                                    copy_archive_member(content, output, size, deadline)
                finally:
                    os.close(target)
        return {'message': '解压完成', 'path': '/'.join(filter(None, [data.get('path', ''), destination])), 'entries': len(entries)}
    except Exception as error:
        if created:
            raise ValueError(f'解压未完成：{error}。部分文件保留在 {destination}，请使用其他目录名重试。') from error
        raise


def relative_path(value):
    if not isinstance(value, str) or len(value) > 2048 or '\x00' in value or '\\' in value:
        raise ValueError("目录路径无效")
    if value == '':
        return []
    parts = value.split('/')
    if any(p in ('', '.', '..') or len(p.encode('utf-8')) > 255 for p in parts):
        raise ValueError("只能访问当前网站目录，不允许跳转到上级目录")
    return parts


def file_name(value):
    parts = relative_path(value)
    if len(parts) != 1:
        raise ValueError("文件名不能包含目录或路径分隔符")
    return parts[0]


@contextmanager
def directory_fd(root, path):
    # No resolve()+open() race: every component is opened relative to a held fd,
    # with symlink following forbidden. root's parent belongs to root, not PHP.
    flags = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW
    fd = os.open(root, flags)
    try:
        for part in relative_path(path):
            child = os.open(part, flags, dir_fd=fd)
            os.close(fd)
            fd = child
        yield fd
    finally:
        os.close(fd)


def open_download(root, data):
    with directory_fd(root, data.get('path', '')) as folder:
        fd = os.open(file_name(data.get('name')), os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=folder)
    file = os.fdopen(fd, 'rb')
    info = os.fstat(file.fileno())
    if not stat.S_ISREG(info.st_mode):
        file.close()
        raise ValueError('仅支持下载普通文件，不支持链接或设备文件')
    return file, info.st_size


def copy_upload(source, target, size):
    if type(size) is not int or size < 0:
        raise ValueError('文件大小无效')
    remaining = size
    while remaining:
        chunk = source.read(min(CHUNK_SIZE, remaining))
        if not chunk:
            raise ValueError('上传连接中断，文件尚未完整接收')
        target.write(chunk)
        remaining -= len(chunk)


def operate(root, action, data):
    path = data.get('path', '')
    relative_path(path)
    try:
        if action == 'files_extract':
            return extract_archive(root, data)
        with directory_fd(root, path) as folder:
            if action == 'files_list':
                result = []
                for name in os.listdir(folder):
                    try:
                        info = os.stat(name, dir_fd=folder, follow_symlinks=False)
                    except FileNotFoundError:
                        continue
                    kind = 'directory' if stat.S_ISDIR(info.st_mode) else 'file' if stat.S_ISREG(info.st_mode) else 'blocked'
                    result.append({'name': name, 'kind': kind, 'size': info.st_size, 'modified': info.st_mtime})
                    if len(result) > 5000:
                        raise ValueError("此目录超过 5000 个条目，请通过 SFTP 管理")
                result.sort(key=lambda x: (x['kind'] != 'directory', x['name'].casefold()))
                return {'path': path, 'entries': result, 'limit': None}
            name = file_name(data.get('name'))
            if action == 'files_mkdir':
                os.mkdir(name, mode=0o755, dir_fd=folder)
                return {'message': '文件夹已创建'}
            if action == 'files_upload':
                overwrite = data.get('overwrite', False)
                if type(overwrite) is not bool:
                    raise ValueError("覆盖选项无效")
                temporary = '.minipanel-upload-' + secrets.token_hex(12)
                fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o644, dir_fd=folder)
                try:
                    with os.fdopen(fd, 'wb') as file:
                        copy_upload(data['_stream'], file, data['size'])
                        file.flush()
                        os.fsync(file.fileno())
                    if overwrite:
                        try:
                            existing = os.stat(name, dir_fd=folder, follow_symlinks=False)
                        except FileNotFoundError:
                            existing = None
                        if existing and not stat.S_ISREG(existing.st_mode):
                            raise ValueError("不能覆盖目录、符号链接或特殊文件")
                        # rename replaces the entry itself, never follows its target.
                        os.replace(temporary, name, src_dir_fd=folder, dst_dir_fd=folder)
                    else:
                        # Atomic create-if-absent, so a concurrent upload cannot overwrite.
                        os.link(temporary, name, src_dir_fd=folder, dst_dir_fd=folder, follow_symlinks=False)
                    return {'message': '文件上传完成'}
                finally:
                    try:
                        os.unlink(temporary, dir_fd=folder)
                    except FileNotFoundError:
                        pass
            raise ValueError("不支持的文件操作")
    except FileExistsError:
        raise ValueError("同名文件或目录已存在；如需替换文件，请勾选覆盖") from None
    except FileNotFoundError:
        raise ValueError("文件或目录不存在，请刷新后重试") from None
    except (NotADirectoryError, PermissionError):
        raise ValueError("无法访问此目录或文件：请检查权限，不允许访问符号链接") from None
    except OSError as error:
        if error.errno == 40:  # ELOOP, symlink with O_NOFOLLOW
            raise ValueError("不允许访问符号链接") from None
        raise


def drop_privileges():
    import pwd
    account = pwd.getpwnam('www-data')
    os.setgroups([])
    os.setgid(account.pw_gid)
    os.setuid(account.pw_uid)
