#!/usr/bin/env bash
set -euo pipefail
umask 022

[[ $EUID -eq 0 ]] || { echo '请使用 sudo bash install.sh'; exit 1; }
source /etc/os-release
[[ ${ID:-} == debian && ${VERSION_ID:-} =~ ^(12|13)$ ]] || { echo '仅支持 Debian 12 / 13'; exit 1; }
[[ -d /run/systemd/system ]] || { echo '需要运行 systemd 的 Debian 服务器'; exit 1; }
[[ $(dpkg --print-architecture) == amd64 ]] || { echo '当前安装包支持 x86_64 / amd64 服务器'; exit 1; }
script_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
for file in app.py common.py helper.py file_manager.py reset-password.py static/index.html static/style.css static/app.js; do
    [[ -f "$script_dir/$file" ]] || { echo "缺少文件：$file"; exit 1; }
done
export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y python3 gunicorn sudo ca-certificates openssl

if ! id minipanel >/dev/null 2>&1; then
    useradd --system --home-dir /var/lib/minipanel --shell /usr/sbin/nologin minipanel
fi
[[ $(id -u minipanel) -ne 0 ]] || { echo 'minipanel 账号异常'; exit 1; }
install -d -o root -g root -m 0755 /opt/minipanel /opt/minipanel/static
install -d -o root -g minipanel -m 0750 /etc/minipanel
install -d -o minipanel -g minipanel -m 0700 /var/lib/minipanel
install -d -o root -g root -m 0700 /var/lib/minipanel-system
install -d -o root -g root -m 0755 /var/www/minipanel
if systemctl is-active --quiet minipanel; then
    systemctl stop minipanel
fi
for file in app.py common.py helper.py file_manager.py reset-password.py; do
    install -o root -g root -m 0644 "$script_dir/$file" "/opt/minipanel/$file"
done
for file in index.html style.css app.js; do
    install -o root -g root -m 0644 "$script_dir/static/$file" "/opt/minipanel/static/$file"
done

if [[ ! -e /etc/minipanel/auth.json ]]; then
    python3 -I - <<'PY'
import json, os, secrets, sys
from pathlib import Path
sys.path.insert(0, '/opt/minipanel')
from app import make_config
password = secrets.token_urlsafe(20)
auth = Path('/etc/minipanel/auth.json')
fd = os.open(auth, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o640)
with os.fdopen(fd, 'w') as file:
    json.dump(make_config(password), file)
credentials = Path('/root/minipanel-login.txt')
fd = os.open(credentials, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
with os.fdopen(fd, 'w') as file:
    file.write('用户名：admin\n密码：' + password + '\n')
print('\n管理员：admin\n初始密码：' + password + '\n密码另存于 /root/minipanel-login.txt\n')
PY
fi
chown root:minipanel /etc/minipanel/auth.json
chmod 0640 /etc/minipanel/auth.json

# Exact executable + argument match. The panel cannot execute arbitrary sudo commands.
sudoers_tmp=$(mktemp)
trap 'rm -f -- "$sudoers_tmp"' EXIT
printf '%s\n' 'minipanel ALL=(root) NOPASSWD: /usr/bin/python3 -I /opt/minipanel/helper.py' > "$sudoers_tmp"
chmod 0440 "$sudoers_tmp"
visudo -cf "$sudoers_tmp"
install -o root -g root -m 0440 "$sudoers_tmp" /etc/sudoers.d/minipanel

if [[ ! -f /etc/minipanel/tls.key || ! -f /etc/minipanel/tls.crt ]]; then
    openssl req -x509 -newkey rsa:3072 -sha256 -nodes -days 365 \
        -keyout /etc/minipanel/tls.key -out /etc/minipanel/tls.crt \
        -subj '/CN=MiniPanel' -addext 'subjectAltName=DNS:localhost,IP:127.0.0.1'
fi
chown root:minipanel /etc/minipanel/tls.key /etc/minipanel/tls.crt
chmod 0640 /etc/minipanel/tls.key
chmod 0644 /etc/minipanel/tls.crt

cat > /etc/systemd/system/minipanel.service <<'UNIT'
[Unit]
Description=MiniPanel lightweight server control panel
After=network.target

[Service]
Type=simple
User=minipanel
Group=minipanel
WorkingDirectory=/opt/minipanel
ExecStart=/usr/bin/gunicorn --bind 0.0.0.0:8888 --workers 1 --worker-class gthread --threads 6 --timeout 180 --certfile /etc/minipanel/tls.crt --keyfile /etc/minipanel/tls.key --access-logfile - --error-logfile - app:create_app()
Environment=PYTHONDONTWRITEBYTECODE=1
Environment=PYTHONUNBUFFERED=1
Restart=on-failure
RestartSec=3
UMask=0077
PrivateTmp=false
# sudo broker needs elevation and write access to system configuration.
# Do not add NoNewPrivileges or ProtectSystem without moving the broker to a separate service.
KillMode=control-group
TimeoutStopSec=30

[Install]
WantedBy=multi-user.target
UNIT
systemctl daemon-reload
systemctl enable minipanel
systemctl restart minipanel
systemctl is-active --quiet minipanel

echo '面板已安装。直接在浏览器访问：https://服务器公网IP:8888'
echo '管理员：admin；新安装初始密码保存在 /root/minipanel-login.txt。升级保留现有密码。'
echo '修改密码后请使用新密码；初始密码文件不会同步更新。忘记密码可运行：sudo python3 /opt/minipanel/reset-password.py'
echo '请在云服务器安全组及系统防火墙放行 TCP 8888；网站需要 TCP 80。'
echo '初始使用自签名证书，浏览器会显示证书提示；可替换为你的有效证书。'
echo '证书 SHA256 指纹（用于核对服务器身份）：'
openssl x509 -in /etc/minipanel/tls.crt -noout -fingerprint -sha256
echo '登录后，点击“一键安装环境”安装 Nginx、PHP、MySQL。'
