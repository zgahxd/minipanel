'use strict';
const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
let csrf = '', state = null, loggedIn = false, job = null, timer = null, polling = false;
let fileView = {domain:'', scope:'system', path:'/'}, sslDomain = '', rootDomain = '', filesLoaded = false;
let fileEntries = [], selectedFiles = new Set(), fileHistory = [], fileRequest = 0, extractRequest = null;
const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

async function api(path, body) {
  const options = {credentials:'same-origin', headers:{}, cache:'no-store'};
  if (body !== undefined) {
    options.method = 'POST'; options.headers['Content-Type'] = 'application/json';
    options.headers['X-CSRF-Token'] = csrf; options.body = JSON.stringify(body);
  }
  const response = await fetch('/api/' + path, options);
  const result = await response.json();
  if (!response.ok) {
    if (response.status === 401 && path !== 'login') showLogin();
    throw new Error(result.error || '请求失败，请稍后重试');
  }
  return result;
}
function notify(message) {
  $('#toast').textContent = message; $('#toast').classList.remove('hidden');
  clearTimeout(timer); timer = setTimeout(() => $('#toast').classList.add('hidden'), 4500);
}
function showLogin() {
  loggedIn = false; csrf = ''; $('#app').classList.add('hidden'); $('#login').classList.remove('hidden');
  $$('dialog[open]').forEach(d => d.close());
}
function showApp() {
  loggedIn = true; $('#login').classList.add('hidden'); $('#app').classList.remove('hidden');
}
function page(name) {
  $$('.page').forEach(p => p.classList.toggle('hidden', p.id !== 'page-' + name));
  $$('.nav-item').forEach(b => b.classList.toggle('active', b.dataset.page === name));
  $('#breadcrumb').textContent = ({overview:'总览', sites:'网站管理', databases:'数据库', logs:'安装日志', files:'文件管理', settings:'面板设置'})[name];
}
function confirmAction(title, description) {
  const dialog = $('#confirm-dialog'); $('#confirm-title').textContent = title; $('#confirm-description').textContent = description;
  dialog.returnValue = ''; dialog.showModal();
  return new Promise(resolve => dialog.addEventListener('close', () => resolve(dialog.returnValue === 'ok'), {once:true}));
}
async function busy(button, action) {
  button.disabled = true;
  try { await action(); } catch (error) { notify(error.message); }
  finally { button.disabled = false; }
}
function openSite() { $('#site-form').reset(); $('#site-form .form-error').textContent = ''; $('#root-preview').textContent = '/var/www/minipanel/你的域名/public'; $('#site-dialog').showModal(); }
function tag(running, installed=true) { return `<span class="tag ${running ? 'good' : 'neutral'}">${running ? '● 运行中' : installed ? '未就绪' : '待安装'}</span>`; }
function render() {
  $('#demo-banner').classList.toggle('hidden', !state.demo);
  $('#server-name').textContent = state.hostname; $('#os-name').textContent = state.os;
  $('#connection-status').textContent = state.demo ? '演示模式' : '已连接';
  $('#last-updated').textContent = '更新于 ' + new Date().toLocaleTimeString('zh-CN', {hour12:false});
  const descriptions = {Nginx:'高效的 Web 服务器', PHP:'动态应用运行环境', MySQL:'可靠的关系型数据库'};
  $('#services').innerHTML = state.services.map(s => `<article class="service-card"><div class="service-card-top"><span class="service-symbol symbol-${esc(s.name)}">${({Nginx:'N',PHP:'php',MySQL:'M'})[s.name]}</span><div><h3>${esc(s.name)}</h3><span class="service-description">${descriptions[s.name]}</span></div>${tag(s.running,s.installed)}</div><div class="service-version" title="${esc(s.version)}">${esc(s.version)}</div><div class="service-bottom"><span>${s.installed?'已安装':'等待安装环境'}</span><button data-restart="${esc(s.name)}" ${s.installed?'':'disabled'}>↻ 重启服务</button></div></article>`).join('');
  const ready = state.services.every(s => s.running);
  $('#install').innerHTML = ready ? '检查 / 补全环境 <span>↗</span>' : '一键安装环境 <span>↗</span>';
  $('#install-hint').textContent = ready ? '运行环境已就绪，可以开始添加网站' : '使用 Debian 软件源及 MySQL 官方安装源';
  $('#install').disabled = job?.status === 'running';
  $('#site-count').textContent = $('#overview-count').textContent = state.sites.length;
  $('#recent-sites').innerHTML = state.sites.length ? state.sites.slice(-3).reverse().map(s => `<div class="site-row"><span class="site-avatar">${esc(s.domain[0])}</span><div><a href="http://${esc(s.domain)}" target="_blank" rel="noopener noreferrer">${esc(s.domain)} ↗</a><small>PHP ${esc(s.php)}</small></div><span class="tag ${s.enabled?'good':'neutral'}">${s.enabled?'已启用':'已暂停'}</span></div>`).join('') : '<div class="empty"><span class="empty-icon">◎</span><h3>这里是你下一个网站的位置</h3><p>添加一个域名，开始你的新项目。</p><button class="secondary" data-open-site>＋ 添加网站</button></div>';
  $('#sites-table').innerHTML = state.sites.map(s => `<tr><td><a href="${s.ssl?'https':'http'}://${esc(s.domain)}" target="_blank" rel="noopener noreferrer">${esc(s.domain)} ↗</a><button class="path-button" data-files="${esc(s.domain)}" title="打开网站目录">▱ ${esc(s.root)}</button></td><td>PHP ${esc(s.php)}<small class="site-ssl-summary">${s.ssl ? (s.force_https?'自签名 SSL · 强制 HTTPS':'自签名 SSL · HTTP/HTTPS'):'SSL 未启用'}</small></td><td><span class="tag ${s.enabled?'good':'neutral'}">${s.enabled?'已启用':'已暂停'}</span></td><td><button class="text-button" data-root="${esc(s.domain)}">修改目录</button><button class="text-button" data-ssl="${esc(s.domain)}">SSL 设置</button><button class="text-button" data-toggle="${esc(s.domain)}" data-enabled="${!s.enabled}">${s.enabled?'暂停':'启用'}</button></td></tr>`).join('');
  $('#sites-empty').classList.toggle('hidden', state.sites.length > 0);
  $('#databases-table').innerHTML = state.databases.map(d => `<tr><td>${esc(d.name)}</td><td>${esc(d.username)}</td><td>${esc(d.host)}:${d.port}</td></tr>`).join('');
  $('#databases-empty').classList.toggle('hidden', state.databases.length > 0);
  $('#load').textContent = state.demo ? '演示模式' : Number(state.load).toFixed(2);
  const gb = n => (n / 1073741824).toFixed(1);
  $('#disk').textContent = state.demo ? '—' : `${gb(state.disk.used)} / ${gb(state.disk.total)} GB`;
  $('#disk-bar').value = state.disk.total ? 100 * state.disk.used / state.disk.total : 0;
}
async function refresh() {
  try { state = await api('status'); render(); $('#page-error').classList.add('hidden'); }
  catch (error) { $('#connection-status').textContent = '连接异常'; $('#page-error').textContent = error.message; $('#page-error').classList.remove('hidden'); }
}
async function pollJob() {
  if (!loggedIn || polling) return;
  polling = true;
  try {
    const previous = job?.status; job = await api('job');
    if (!job) return;
    $('#job-badge').textContent = ({running:'安装中',success:'已完成',failed:'安装失败'})[job.status];
    $('#job-badge').className = 'tag ' + ({running:'warning',success:'good',failed:'failed'})[job.status];
    const log = $('#job-log'); const atEnd = log.scrollTop + log.clientHeight >= log.scrollHeight - 60;
    log.textContent = job.logs.join('\n') || '任务已启动，正在准备…';
    if (atEnd) log.scrollTop = log.scrollHeight;
    $('#job-message').textContent = job.message; $('#install').disabled = job.status === 'running';
    if (previous === 'running' && job.status !== 'running') { notify(job.message); await refresh(); }
  } catch (error) { if (loggedIn) $('#job-message').textContent = error.message; }
  finally { polling = false; }
}
$('#login-form').addEventListener('submit', async event => {
  event.preventDefault(); const button = event.submitter; button.disabled = true; $('#login-error').textContent = '';
  try { const result = await api('login', {username:$('#username').value, password:$('#password').value}); csrf = result.csrf; $('#password').value = ''; showApp(); await refresh(); await pollJob(); }
  catch (error) { $('#login-error').textContent = error.message; }
  finally { button.disabled = false; }
});
$('#logout').addEventListener('click', () => busy($('#logout'), async () => { await api('logout', {}); showLogin(); }));
$$('.nav-item').forEach(button => button.addEventListener('click', () => {
  if (button.dataset.page === 'files') {
    openFiles('', fileView.path || '/');
  } else page(button.dataset.page);
}));
$$('[data-go]').forEach(button => button.addEventListener('click', () => page(button.dataset.go)));
$$('.refresh').forEach(button => button.addEventListener('click', () => busy(button, refresh)));
$$('[data-close]').forEach(button => button.addEventListener('click', () => button.closest('dialog').close()));
$('#add-site').addEventListener('click', openSite);
document.addEventListener('click', async event => {
  const add = event.target.closest('[data-open-site]'); if (add) openSite();
  const files = event.target.closest('[data-files]'); if (files) openFiles(files.dataset.files, '');
  const directory = event.target.closest('[data-directory]'); if (directory) openFiles(fileView.domain, directory.dataset.directory);
  const download = event.target.closest('[data-download]'); if (download) await busy(download, () => downloadFile(download.dataset.download));
  const extract = event.target.closest('[data-extract]'); if (extract) openExtract(extract.dataset.extract);
  const root = event.target.closest('[data-root]'); if (root) openRoot(root.dataset.root);
  const remove = event.target.closest('[data-delete]'); if (remove) await deleteFiles([remove.dataset.delete]);
  const ssl = event.target.closest('[data-ssl]'); if (ssl) openSSL(ssl.dataset.ssl);
  const restart = event.target.closest('[data-restart]');
  if (restart && !restart.disabled) {
    const name = restart.dataset.restart;
    if (await confirmAction(`重启 ${name}`, '服务重启期间，相关网站或数据库连接可能短暂中断。'))
      await busy(restart, async () => { const result = await api('restart', {service:name}); notify(result.message); await refresh(); });
  }
  const toggle = event.target.closest('[data-toggle]');
  if (toggle) {
    const enabled = toggle.dataset.enabled === 'true';
    if (await confirmAction(enabled ? '启用网站' : '暂停网站', `${toggle.dataset.toggle} ${enabled?'将恢复访问。':'将返回 HTTP 503，网站文件仍然保留。'}`))
      await busy(toggle, async () => { const result = await api('sites/toggle', {domain:toggle.dataset.toggle, enabled}); notify(result.message); await refresh(); });
  }
});

function openSSL(domain) {
  const site = state.sites.find(s => s.domain === domain); if (!site) return;
  sslDomain = domain; $('#ssl-domain').textContent = domain;
  $('#ssl-enabled').checked = !!site.ssl; $('#force-https').checked = !!site.force_https;
  $('#force-https').disabled = !site.ssl;
  $('#ssl-certificate').textContent = site.certificate || '启用后为此域名生成自签名证书，有效期 365 天。';
  $('#ssl-form .form-error').textContent = ''; $('#ssl-dialog').showModal();
}
$('#ssl-enabled').addEventListener('change', () => {
  $('#force-https').disabled = !$('#ssl-enabled').checked;
  if (!$('#ssl-enabled').checked) $('#force-https').checked = false;
});
$('#ssl-form').addEventListener('submit', async event => {
  event.preventDefault(); event.submitter.disabled = true; $('#ssl-form .form-error').textContent = '';
  try {
    const result = await api('sites/ssl', {domain:sslDomain, ssl:$('#ssl-enabled').checked, force_https:$('#force-https').checked});
    $('#ssl-dialog').close(); notify(result.message); await refresh();
  } catch (error) { $('#ssl-form .form-error').textContent = error.message; }
  finally { event.submitter.disabled = false; }
});
function sizeText(size) { return size >= 1048576 ? (size/1048576).toFixed(1)+' MB' : size >= 1024 ? (size/1024).toFixed(1)+' KB' : size+' B'; }
function isArchive(name) { return /\.(zip|tar|tar\.gz|tgz|tar\.bz2|tbz2|tar\.xz|txz)$/i.test(name); }
function updateSelection() {
  const selected = fileEntries.filter(e => selectedFiles.has(e.name));
  $('#file-selection-count').textContent = selected.length ? `已选择 ${selected.length} 项` : `共 ${fileEntries.length} 项 · 未选择文件`;
  $('#download-selected').disabled = !selected.length || selected.some(e => e.kind !== 'file');
  $('#extract-selected').disabled = selected.length !== 1 || selected[0].kind !== 'file' || !isArchive(selected[0].name);
  $('#clear-selection').disabled = !selected.length;
  $('#delete-selected').disabled = !selected.length;
  const available = fileEntries.filter(e => e.kind !== 'blocked');
  $('#select-all-files').disabled = !available.length;
  $('#select-all-files').checked = !!available.length && selected.length === available.length;
  $('#select-all-files').indeterminate = !!selected.length && selected.length < available.length;
  $$('#files-table [data-select-file]').forEach(box => {
    box.checked = selectedFiles.has(box.dataset.selectFile);
    box.closest('tr').classList.toggle('selected-file',box.checked);
  });
}
async function openFiles(domain, path='', navigation='push') {
  if (domain) { const site=state.sites.find(s=>s.domain===domain); if (!site) return notify('网站不存在'); path=site.root+(path?'/'+path:''); domain=''; }
  path=path||'/';
  const request = ++fileRequest;
  page('files'); $('#file-error').classList.add('hidden');
  $('#file-path').textContent = '正在读取目录…';
  $('#files-table').setAttribute('inert','');
  for (const id of ['file-back','file-up','download-selected','extract-selected','delete-selected','select-all-files']) $('#'+id).disabled=true;
  try {
    const result = await api('files?' + new URLSearchParams({domain,path}));
    if (request !== fileRequest) return;
    if (navigation === 'back') fileHistory.pop();
    else if (filesLoaded && (fileView.domain !== domain || fileView.path !== result.path)) fileHistory.push({...fileView});
    fileView = {domain:'',scope:'system',path:result.path}; filesLoaded=true; path=result.path; fileEntries=result.entries; selectedFiles.clear();
    $('#file-domain').textContent = '系统目录 · '+(state.demo?'模拟文件系统':'管理员访问');
    $('#file-path').textContent = path; $('#file-location').value=path;
    let prefix=''; const crumbs = ['<button class="text-button" data-directory="/">/ 根目录</button>'];
    for (const part of path.split('/').filter(Boolean)) { prefix += '/'+part; crumbs.push(`<span>/</span><button class="text-button" data-directory="${esc(prefix)}">${esc(part)}</button>`); }
    $('#file-breadcrumbs').innerHTML = crumbs.join('');
    $('#files-table').innerHTML = result.entries.map(e => {
      const target = path.replace(/\/$/,'')+'/'+e.name;
      const label = e.kind === 'directory' ? `<button class="text-button folder-link" data-directory="${esc(target)}">▱ ${esc(e.name)}</button>` : `<span class="file-name">${e.kind==='file'?(isArchive(e.name)?'▣':'▤'):'⊘'} ${esc(e.name)}</span>`;
      return `<tr><td class="select-cell"><input type="checkbox" data-select-file="${esc(e.name)}" aria-label="选择 ${esc(e.name)}" ${e.kind==='blocked'?'disabled':''}></td><td>${label}</td><td>${e.kind==='file'?sizeText(e.size):e.kind==='directory'?'文件夹':'链接 / 特殊文件'}</td><td>${esc(new Date(e.modified*1000).toLocaleString('zh-CN',{hour12:false}))}</td><td>${e.kind==='file'?`<button class="text-button" data-download="${esc(e.name)}">下载 ↓</button>${isArchive(e.name)?`<button class="text-button" data-extract="${esc(e.name)}">解压</button>`:''}`:''}${e.kind!=='blocked'?`<button class="text-button danger-text" data-delete="${esc(e.name)}">删除</button>`:''}</td></tr>`;
    }).join('');
    $('#files-empty').classList.toggle('hidden', result.entries.length > 0);
  } catch (error) {
    if (request !== fileRequest) return;
    $('#file-error').textContent = error.message; $('#file-error').classList.remove('hidden');
    $('#file-path').textContent = fileView.path;
  } finally {
    if (request === fileRequest) {
      $('#files-table').removeAttribute('inert');
      $('#file-back').disabled = !fileHistory.length; $('#file-up').disabled = fileView.path === '/';
      updateSelection();
    }
  }
}
$('#file-back').addEventListener('click', () => { const previous=fileHistory.at(-1); if(previous) openFiles(previous.domain,previous.path,'back'); });
$('#file-up').addEventListener('click', () => { if(fileView.path !== '/') openFiles('',fileView.path.split('/').slice(0,-1).join('/') || '/'); });
$('#files-table').addEventListener('change', event => {
  const box=event.target.closest('[data-select-file]'); if(!box) return;
  if(box.checked) selectedFiles.add(box.dataset.selectFile); else selectedFiles.delete(box.dataset.selectFile);
  updateSelection();
});
$('#files-table').addEventListener('click', event => {
  if(event.target.closest('button,a,input')) return;
  const box=event.target.closest('tr')?.querySelector('[data-select-file]'); if(!box || box.disabled) return;
  if(selectedFiles.has(box.dataset.selectFile)) selectedFiles.delete(box.dataset.selectFile); else selectedFiles.add(box.dataset.selectFile);
  updateSelection();
});
$('#select-all-files').addEventListener('change', event => { selectedFiles = new Set(event.target.checked?fileEntries.filter(e=>e.kind!=='blocked').map(e=>e.name):[]); updateSelection(); });
$('#clear-selection').addEventListener('click', () => {selectedFiles.clear();updateSelection();});
$('#download-selected').addEventListener('click', () => {
  const names=fileEntries.filter(e=>selectedFiles.has(e.name)&&e.kind==='file').map(e=>e.name);
  names.forEach(name=>downloadFile(name));
  if(names.length>1) notify('已发起下载；如浏览器询问，请允许多个文件下载');
});
function openExtract(name) {
  extractRequest={...fileView,name};
  $('#extract-source').textContent=name;
  $('#extract-destination').value=name.replace(/\.(zip|tar\.gz|tar\.bz2|tar\.xz|tgz|tbz2|txz|tar)$/i,'') || 'extracted';
  $('#extract-form .form-error').textContent=''; $('#extract-progress').textContent='';
  $('#extract-dialog').showModal();
}
$('#extract-selected').addEventListener('click',()=>{if(selectedFiles.size===1) openExtract([...selectedFiles][0]);});
$('#extract-dialog').addEventListener('cancel',event=>{if($('#extract-form button[type=submit]').disabled) event.preventDefault();});
$('#extract-form').addEventListener('submit', async event => {
  event.preventDefault();
  const request={...extractRequest,destination:$('#extract-destination').value};
  $$('#extract-form button, #extract-form input').forEach(e=>e.disabled=true);
  $('#extract-form .form-error').textContent=''; $('#extract-progress').textContent='正在解压，请保持页面打开…';
  try {
    const result=await api('files/extract',request);
    $('#extract-dialog').close(); notify(result.message); await openFiles(request.domain,result.path);
  } catch(error) {$('#extract-form .form-error').textContent=error.message;}
  finally {$('#extract-progress').textContent=''; $$('#extract-form button, #extract-form input').forEach(e=>e.disabled=false);}
});
$('#file-refresh').addEventListener('click', () => { openFiles('',fileView.path); });
$('#file-upload-form').addEventListener('submit', async event => {
  event.preventDefault(); const selected = [...$('#upload-file').files];
  if (!filesLoaded || !selected.length) return notify('请先打开目录并选择文件');
  event.submitter.disabled = true;
  try {
    const destination = {...fileView};
    for (let i=0;i<selected.length;i++) {
      const file=selected[i]; $('#upload-progress').textContent = `正在上传 ${i+1}/${selected.length}：${file.name}`;
      await new Promise((resolve,reject) => {
        const xhr = new XMLHttpRequest();
        xhr.open('POST','/api/files/upload?' + new URLSearchParams({...destination,name:file.name,overwrite:String($('#overwrite-file').checked)}));
        xhr.setRequestHeader('Content-Type','application/octet-stream'); xhr.setRequestHeader('X-CSRF-Token',csrf);
        xhr.responseType='json';
        xhr.upload.onprogress = e => { $('#upload-progress').textContent = `正在上传 ${i+1}/${selected.length}：${file.name}` + (e.lengthComputable ? ` · ${Math.round(e.loaded/e.total*100)}%` : ''); };
        xhr.onload=()=>xhr.status>=200&&xhr.status<300 ? resolve(xhr.response) : reject(new Error(xhr.response?.error || '上传失败'));
        xhr.onerror=()=>reject(new Error('上传连接中断，请检查网络后重试'));
        xhr.send(file);
      });
    }
    $('#upload-file').value=''; notify('文件上传完成');
  } catch (error) { notify(error.message); }
  finally { event.submitter.disabled=false; $('#upload-progress').textContent=''; await openFiles(fileView.domain,fileView.path); }
});
$('#new-folder').addEventListener('click', () => { $('#folder-form').reset(); $('#folder-form .form-error').textContent=''; $('#folder-dialog').showModal(); });
$('#folder-form').addEventListener('submit', async event => {
  event.preventDefault(); event.submitter.disabled=true;
  try { await api('files/mkdir',{...fileView,name:$('#folder-name').value}); $('#folder-dialog').close(); notify('文件夹已创建'); await openFiles(fileView.domain,fileView.path); }
  catch(error) { $('#folder-form .form-error').textContent=error.message; }
  finally { event.submitter.disabled=false; }
});
async function downloadFile(name) {
  // Let the browser stream directly to disk; do not create a whole-file Blob in JS.
  const link=document.createElement('a'); link.href='/api/files/download?' + new URLSearchParams({...fileView,name});
  link.download=name; document.body.append(link); link.click(); link.remove();
}
$('#domain').addEventListener('input', () => { $('#root-preview').textContent = '/var/www/minipanel/' + ($('#domain').value.trim().toLowerCase() || '你的域名') + '/public'; });
$('#site-form').addEventListener('submit', async event => {
  event.preventDefault(); event.submitter.disabled = true; $('#site-form .form-error').textContent = '';
  try { const result = await api('sites', {domain:$('#domain').value, root:$('#site-root').value.trim()}); $('#site-dialog').close(); notify(result.message); page('sites'); await refresh(); }
  catch (error) { $('#site-form .form-error').textContent = error.message; }
  finally { event.submitter.disabled = false; }
});
$('#add-database').addEventListener('click', () => { $('#database-form').reset(); $('#database-form .form-error').textContent = ''; $('#database-dialog').showModal(); });
$('#database-form').addEventListener('submit', async event => {
  event.preventDefault(); event.submitter.disabled = true; $('#database-form .form-error').textContent = '';
  try {
    const result = await api('databases', {name:$('#database-name').value}); const d = result.database;
    $('#database-dialog').close(); $('#credentials').textContent = `数据库：${d.name}\n用户名：${d.username}\n密码：${result.password}\n地址：${d.host}\n端口：${d.port}`;
    $('#credentials-dialog').showModal(); await refresh();
  } catch (error) { $('#database-form .form-error').textContent = error.message; }
  finally { event.submitter.disabled = false; }
});
$('#credentials-dialog').addEventListener('close', () => { $('#credentials').textContent = ''; });
$('#copy-credentials').addEventListener('click', () => busy($('#copy-credentials'), async () => { await navigator.clipboard.writeText($('#credentials').textContent); notify('连接信息已复制'); }));
$('#install').addEventListener('click', async () => {
  const description = state?.demo ? '这是本地演示，将模拟环境安装流程。' : '将直接在 Debian 系统安装 Nginx、PHP 和 MySQL 8.4。需要访问 Debian 与 MySQL 官方软件源，首次安装可能需要数分钟。';
  if (!await confirmAction('安装运行环境', description)) return;
  await busy($('#install'), async () => { await api('install', {}); page('logs'); await pollJob(); });
  $('#install').disabled = job?.status === 'running';
});
setInterval(pollJob, 2000);
setInterval(() => { if (loggedIn && job?.status !== 'running' && !document.hidden) refresh(); }, 20000);
(async () => {
  try { const result = await api('session'); csrf = result.csrf; showApp(); await refresh(); await pollJob(); }
  catch { showLogin(); }
})();

$('#file-location-form').addEventListener('submit',event=>{event.preventDefault();openFiles('',$('#file-location').value.trim());});
$('#system-root').addEventListener('click',()=>openFiles('','/'));
$('#new-file').addEventListener('click',()=>{$('#file-form').reset();$('#file-form .form-error').textContent='';$('#file-dialog').showModal();});
$('#file-form').addEventListener('submit',async event=>{
  event.preventDefault(); event.submitter.disabled=true;
  try {await api('files/create',{...fileView,name:$('#new-file-name').value});$('#file-dialog').close();notify('空文件已创建');await openFiles('',fileView.path);}
  catch(error){$('#file-form .form-error').textContent=error.message;}
  finally{event.submitter.disabled=false;}
});
async function deleteFiles(names) {
  if(!names.length) return;
  const destination={...fileView};
  const paths=names.map(name=>destination.path.replace(/\/$/,'')+'/'+name);
  if(!await confirmAction('永久删除 '+names.length+' 项',paths.join('\n')+'\n文件夹内所有内容也会删除，无法撤销。')) return;
  let removed=0;
  try {for(const name of names){await api('files/delete',{...destination,name});removed++;}notify('已删除 '+removed+' 项');}
  catch(error){notify('已删除 '+removed+' 项；'+error.message);}
  finally{await openFiles('',destination.path);}
}
$('#delete-selected').addEventListener('click',()=>deleteFiles([...selectedFiles]));
function openRoot(domain){
  const site=state.sites.find(s=>s.domain===domain);if(!site)return;
  rootDomain=domain;$('#root-domain').textContent=domain;$('#edit-root').value=site.root;
  $('#root-form .form-error').textContent='';$('#root-dialog').showModal();
}
$('#root-form').addEventListener('submit',async event=>{
  event.preventDefault();event.submitter.disabled=true;
  try{const result=await api('sites/root',{domain:rootDomain,root:$('#edit-root').value.trim()});$('#root-dialog').close();notify(result.message);await refresh();}
  catch(error){$('#root-form .form-error').textContent=error.message;}
  finally{event.submitter.disabled=false;}
});
$('#password-form').addEventListener('submit',async event=>{
  event.preventDefault();event.submitter.disabled=true;$('#password-form .form-error').textContent='';
  try{const result=await api('account/password',{old_password:$('#old-password').value,new_password:$('#new-password').value,confirm_password:$('#confirm-password').value});$('#password-form').reset();showLogin();notify(result.message);}
  catch(error){$('#password-form .form-error').textContent=error.message;}
  finally{event.submitter.disabled=false;}
});
