"""MiniPanel WSGI application. Production: Gunicorn HTTPS on the Debian host."""
import argparse
import io
from collections import deque
import hashlib
import hmac
from http.cookies import SimpleCookie
import json
import mimetypes
import os
from pathlib import Path
import secrets
import re
import subprocess
import threading
import tempfile
import time
from urllib.parse import parse_qs, quote

from common import database_name, domain_name, website_root, validate_file_request, check_system_path, make_config, password_hash, within
from file_manager import CHUNK_SIZE, ARCHIVE_TIMEOUT, archive_members, copy_archive_member, copy_upload, file_name, relative_path

BASE = Path(__file__).resolve().parent


class APIError(Exception):
    def __init__(self, status, message):
        self.status, self.message = status, message


class FileStream:
    def __init__(self, chunks, size, name):
        self.chunks, self.size, self.name = chunks, size, name


class DemoBackend:
    def __init__(self):
        self.installed = False
        self.sites, self.databases = [], []
        self.files = {'': {}}
        self.directories = {'': {'', 'etc', 'root', 'var', 'var/www', 'var/www/minipanel', 'srv', 'opt', 'tmp', 'home', 'mnt'}}
        self.io_lock = threading.Lock()

    def file_context(self, data, action):
        validate_file_request(data)
        if data['scope'] == 'site':
            site = next((s for s in self.sites if s['domain'] == data['domain']), None)
            if not site:
                raise ValueError('网站不存在')
            base = site['root']
            absolute = base + ('/' + data['path'] if data.get('path') else '')
        else:
            base, absolute = '/', data['path']
        check_system_path(absolute, 'files_list' if action == 'files_delete' else action)
        for key in ('name', 'destination'):
            if data.get(key):
                check_system_path(absolute.rstrip('/') + '/' + file_name(data[key]), action)
        if action == 'files_delete':
            target = absolute.rstrip('/') + '/' + file_name(data.get('name'))
            if any(within(s['root'], target) for s in self.sites):
                raise ValueError('不能删除网站根目录或其上级目录')
        return '', absolute.lstrip('/'), base

    def upload(self, data, source, size):
        domain, path, _ = self.file_context(data, 'files_upload')
        name = data['name']
        if domain not in self.files or path not in self.directories[domain]:
            raise ValueError('网站或目录不存在')
        key = (path+'/' if path else '') + name
        if key in self.directories[domain] or (key in self.files[domain] and not data.get('overwrite')):
            raise ValueError('同名文件或目录已存在')
        file = tempfile.TemporaryFile()
        try:
            copy_upload(source, file, size)
            file.flush()
            self.files[domain][key] = file
        except Exception:
            file.close()
            raise
        return {'message':'演示文件已上传'}

    def download(self, data):
        domain, path, _ = self.file_context(data, 'files_download')
        name = data['name']
        key = (path+'/' if path else '') + name
        if domain not in self.files or key not in self.files[domain]:
            raise ValueError('文件不存在')
        file = self.files[domain][key]
        size = len(file) if isinstance(file, bytes) else os.fstat(file.fileno()).st_size
        def chunks():
            position = 0
            while position < size:
                if isinstance(file, bytes):
                    chunk = file[position:position+CHUNK_SIZE]
                else:
                    with self.io_lock:
                        file.seek(position)
                        chunk = file.read(min(CHUNK_SIZE, size-position))
                if not chunk:
                    raise IOError('文件读取中断')
                position += len(chunk)
                yield chunk
        return FileStream(chunks(), size, name)

    def call(self, action, data, log=None):
        if action == "status":
            return {"demo": True, "hostname": "local-preview", "os": "Debian 12 / 13 · 演示", "load": 0,
                    "disk": {"used": 0, "total": 0}, "sites": self.sites[:], "databases": self.databases[:],
                    "services": [{"name": n, "installed": self.installed, "running": self.installed, "version": v if self.installed else "未安装"}
                                 for n, v in [("Nginx", "系统仓库版本"), ("PHP", "系统仓库版本"), ("MySQL", "8.4 · 原生安装")]]}
        if action == "install":
            for message in ["演示：更新软件源", "演示：安装 Nginx 与 PHP", "演示：准备 MySQL 8.4", "演示环境已就绪（未安装真实服务）"]:
                if log:
                    log(message)
                time.sleep(0.5)
            self.installed = True
            return {"message": "演示安装完成"}
        if not self.installed and not action.startswith('files_') and action != 'change_password':
            raise APIError(409, "请先安装运行环境")
        if action == "create_site":
            domain = domain_name(data.get("domain"))
            if any(s["domain"] == domain for s in self.sites):
                raise ValueError("该域名已经添加")
            self.sites.append({"domain": domain, "root": website_root(data.get("root"), domain), "enabled": True, "php": "系统默认", "ssl": False, "force_https": False, "created": time.strftime("%Y-%m-%d %H:%M")})
            path = self.sites[-1]['root'].lstrip('/')
            existed = path in self.directories['']
            for i in range(1, len(path.split('/'))+1):
                self.directories[''].add('/'.join(path.split('/')[:i]))
            if not existed:
                self.files[''][path+'/index.html'] = b'<!doctype html><h1>MiniPanel demo site</h1>'
        elif action == 'change_password':
            return {'config': make_config(data.get('new_password'))}
        elif action == 'site_root':
            site = next((s for s in self.sites if s['domain'] == data['domain']), None)
            if not site:
                raise ValueError('网站不存在')
            target = website_root(data.get('root'), data['domain'])
            for i in range(1, len(target.lstrip('/').split('/'))+1):
                self.directories[''].add('/'.join(target.lstrip('/').split('/')[:i]))
            site['root'] = target
        elif action == "toggle_site":
            site = next((s for s in self.sites if s["domain"] == data.get("domain")), None)
            if not site:
                raise ValueError("网站不存在")
            site["enabled"] = data["enabled"]
        elif action == 'configure_ssl':
            site = next((s for s in self.sites if s['domain'] == data.get('domain')), None)
            if not site:
                raise ValueError('网站不存在')
            if data['force_https'] and not data['ssl']:
                raise ValueError('请先启用网站 SSL，再开启强制 HTTPS')
            site.update(ssl=data['ssl'], force_https=data['force_https'], certificate='演示自签名证书 · 有效期 365 天（未生成真实证书）')
        elif action.startswith('files_'):
            domain, path, base = self.file_context(data, action)
            if domain not in self.files or path not in self.directories[domain]:
                raise ValueError('网站或目录不存在')
            prefix = path + '/' if path else ''
            if action == 'files_list':
                entries = []
                for key in self.directories[domain] | set(self.files[domain]):
                    if key.startswith(prefix) and key != path and '/' not in key[len(prefix):]:
                        content = self.files[domain].get(key, b'')
                        size = len(content) if isinstance(content,bytes) else os.fstat(content.fileno()).st_size
                        entries.append({'name': key[len(prefix):], 'kind': 'directory' if key in self.directories[domain] else 'file', 'size': size, 'modified': time.time()})
                return {'path': data.get('path', ''), 'root': base, 'entries': sorted(entries, key=lambda e: (e['kind'] != 'directory', e['name'])), 'limit': None}
            name = file_name(data.get('name'))
            key = prefix + name
            if action == 'files_delete':
                if key not in self.directories[domain] and key not in self.files[domain]:
                    raise ValueError('文件或目录不存在')
                for item in list(self.files[domain]):
                    if item == key or item.startswith(key + '/'):
                        content = self.files[domain].pop(item)
                        if not isinstance(content, bytes):
                            content.close()
                self.directories[domain].difference_update({p for p in self.directories[domain] if p == key or p.startswith(key + '/')})
                return {'message': '已删除'}
            if action == 'files_extract':
                destination = file_name(data.get('destination'))
                target = prefix + destination
                if target in self.directories[domain] or target in self.files[domain]:
                    raise ValueError('解压目标已存在，请使用新目录名')
                if key not in self.files[domain]:
                    raise ValueError('压缩包不存在')
                stored = self.files[domain][key]
                pending, folders = {}, {target}
                try:
                    with self.io_lock:
                        source = io.BytesIO(stored) if isinstance(stored, bytes) else stored
                        source.seek(0)
                        with archive_members(source, name) as (entries, opener):
                            deadline = time.monotonic() + ARCHIVE_TIMEOUT
                            for raw, directory, size, item in entries:
                                parts = raw.split('/')
                                for i in range(1, len(parts) + (1 if directory else 0)):
                                    folders.add(target + '/' + '/'.join(parts[:i]))
                                if not directory:
                                    output = tempfile.TemporaryFile()
                                    pending[target + '/' + raw] = output
                                    with opener(item) as content:
                                        copy_archive_member(content, output, size, deadline)
                                    output.flush()
                    self.directories[domain].update(folders)
                    self.files[domain].update(pending)
                    return {'message': '解压完成（本地演示）', 'path': (data.get('path', '').rstrip('/') + '/' + destination).lstrip('/') if data['scope'] == 'site' else '/' + target, 'entries': len(entries)}
                except Exception:
                    for output in pending.values():
                        output.close()
                    raise
            if key in self.directories[domain] or (key in self.files[domain] and (action in {'files_mkdir', 'files_create'} or not data.get('overwrite'))):
                raise ValueError('同名文件或目录已存在')
            if action == 'files_mkdir':
                self.directories[domain].add(key)
            elif action == 'files_create':
                self.files[domain][key] = b''
        elif action == "create_database":
            name = database_name(data.get("name"))
            if any(d["name"] == name for d in self.databases):
                raise ValueError("数据库已经存在")
            database = {"name": name, "username": name, "host": "127.0.0.1", "port": 3306}
            self.databases.append(database)
            return {"message": "演示数据库已创建", "database": database, "password": secrets.token_hex(16)}
        return {"message": "演示操作完成"}


class SystemBackend:
    COMMAND = ["/usr/bin/sudo", "-n", "/usr/bin/python3", "-I", "/opt/minipanel/helper.py"]

    def upload(self, data, source, size):
        process = subprocess.Popen(self.COMMAND, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
        try:
            request = dict(data, action='files_upload', size=size)
            process.stdin.write((json.dumps(request)+'\n').encode())
            copy_upload(source, process.stdin, size)
            process.stdin.close(); process.stdin = None
            output, _ = process.communicate(timeout=150)
            item = json.loads(output)
            if 'error' in item:
                raise RuntimeError(item['error'])
            return item['result']
        finally:
            if process.stdin:
                process.stdin.close()
            if process.poll() is None:
                try:
                    process.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    process.kill(); process.wait()
            process.stdout.close()

    def download(self, data):
        process = subprocess.Popen(self.COMMAND, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
        try:
            process.stdin.write((json.dumps(dict(data,action='files_download'))+'\n').encode())
            process.stdin.close()
            item = json.loads(process.stdout.readline(8193))
            if 'error' in item:
                raise RuntimeError(item['error'])
            metadata = item['stream']
        except Exception:
            process.stdout.close()
            process.kill(); process.wait()
            raise
        def chunks():
            remaining = metadata['size']
            try:
                while remaining:
                    chunk = process.stdout.read(min(CHUNK_SIZE, remaining))
                    if not chunk:
                        raise IOError('下载连接中断，文件未传输完整')
                    remaining -= len(chunk)
                    yield chunk
            finally:
                process.stdout.close()
                try:
                    process.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    process.kill(); process.wait()
        return FileStream(chunks(), metadata['size'], metadata['name'])

    def call(self, action, data, log=None):
        request = dict(data, action=action)
        command = self.COMMAND
        if log is None:
            completed = subprocess.run(command, input=json.dumps(request), text=True, capture_output=True, timeout=2 * ARCHIVE_TIMEOUT + 60 if action == 'files_extract' else 150)
            output = completed.stdout.splitlines()
            if not output:
                raise RuntimeError("系统助手未响应，请检查 minipanel 的 sudo 配置")
        else:
            process = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
            # The broker imposes per-command timeouts; the service's cgroup kills children on shutdown.
            process.stdin.write(json.dumps(request))
            process.stdin.close()
            output = []
            for line in process.stdout:
                try:
                    item = json.loads(line)
                except ValueError:
                    log(line[:4000])
                    continue
                if "log" in item:
                    log(item["log"])
                else:
                    output.append(line)
            process.wait()
        for line in reversed(output):
            item = json.loads(line)
            if "error" in item:
                raise RuntimeError(item["error"])
            if "result" in item:
                return item["result"]
        raise RuntimeError("系统助手返回格式异常")


class Panel:
    def __init__(self, config, backend=None, data_dir=None):
        self.config = config
        self.backend = backend or SystemBackend()
        self.data_dir = Path(data_dir) if data_dir else None
        self.sessions, self.attempts = {}, deque()
        self.password_attempts = deque()
        self.lock = threading.RLock()
        self.operation = threading.Lock()
        self.job = None
        if self.data_dir:
            self.data_dir.mkdir(parents=True, exist_ok=True)
            file = self.data_dir / "last-job.json"
            if file.exists():
                self.job = json.loads(file.read_text())
                if self.job["status"] == "running":
                    self.job.update(status="failed", message="面板曾重启，任务中断。请检查服务状态后重试。")

    def save_job(self):
        if self.data_dir:
            temp = self.data_dir / "last-job.tmp"
            temp.write_text(json.dumps(self.job, ensure_ascii=False), encoding="utf-8")
            temp.replace(self.data_dir / "last-job.json")

    def append_log(self, message):
        with self.lock:
            self.job["logs"].extend(message.strip().splitlines())
            self.job["logs"] = self.job["logs"][-350:]
            self.save_job()

    def install_worker(self):
        try:
            result = self.backend.call("install", {}, self.append_log)
            with self.lock:
                self.job.update(status="success", message=result["message"])
        except Exception as error:
            with self.lock:
                self.job.update(status="failed", message=str(error))
        finally:
            with self.lock:
                self.save_job()
            self.operation.release()

    def session(self, env):
        cookie = SimpleCookie()
        try:
            cookie.load(env.get("HTTP_COOKIE", ""))
        except Exception:
            return None, None
        item = cookie.get("mp_session")
        token = item.value if item else None
        with self.lock:
            now = time.time()
            self.sessions = {k: v for k, v in self.sessions.items() if v["expires"] > now}
            return token, self.sessions.get(token)

    def body(self, env, limit=8192):
        try:
            size = int(env.get("CONTENT_LENGTH") or "0")
        except ValueError:
            raise APIError(400, "请求长度无效") from None
        if not 0 < size <= limit:
            raise APIError(413, "请求过大或为空")
        if env.get("CONTENT_TYPE", "").split(";")[0] != "application/json":
            raise APIError(415, "仅接受 JSON 请求")
        try:
            data = json.loads(env["wsgi.input"].read(size))
        except (ValueError, UnicodeError):
            raise APIError(400, "JSON 格式无效") from None
        if not isinstance(data, dict):
            raise APIError(400, "请求内容必须是对象")
        return data

    def dispatch(self, env):
        path, method = env.get("PATH_INFO", "/"), env["REQUEST_METHOD"]
        headers = []
        host = env.get("HTTP_HOST", "")
        scheme = env.get("wsgi.url_scheme", "http")
        if isinstance(self.backend, DemoBackend):
            if host not in {"127.0.0.1:8888", "localhost:8888", "[::1]:8888"}:
                raise APIError(403, "演示模式仅允许本地访问")
        else:
            if not re.fullmatch(r"[a-zA-Z0-9.-]+:8888", host):
                raise APIError(403, "请通过服务器地址的 8888 端口访问")
            if scheme != "https":
                raise APIError(403, "请使用 HTTPS 访问面板")
        if method == "POST":
            origin = env.get("HTTP_ORIGIN")
            if origin and origin != f"{scheme}://{host}":
                raise APIError(403, "请求来源不匹配")
            if env.get("HTTP_SEC_FETCH_SITE") == "cross-site":
                raise APIError(403, "拒绝跨站请求")
        if method == "GET" and path in {"/", "/static/style.css", "/static/app.js"}:
            file = BASE / ("static/index.html" if path == "/" else path.lstrip("/"))
            content_type = {".html": "text/html", ".css": "text/css", ".js": "text/javascript"}[file.suffix]
            return 200, file.read_bytes(), [("Content-Type", content_type + "; charset=utf-8")]
        token, session = self.session(env)
        if method == "POST" and path == "/api/login":
            data = self.body(env)
            now = time.time()
            with self.lock:
                while self.attempts and self.attempts[0] < now - 300:
                    self.attempts.popleft()
                if len(self.attempts) >= 10:
                    raise APIError(429, "登录尝试过多，请 5 分钟后重试")
                # Count before hashing to bound concurrent attempts as well.
                self.attempts.append(now)
            password = data.get("password", "")
            username = data.get("username", "")
            if not isinstance(password, str) or len(password) > 256:
                raise APIError(400, "密码格式无效")
            with self.lock:
                config = self.config.copy()
            valid = hmac.compare_digest(password_hash(password, config["salt"]), config["password_hash"])
            if not valid or username != self.config["username"]:
                raise APIError(401, "用户名或密码不正确")
            token = secrets.token_urlsafe(32)
            session = {"csrf": secrets.token_urlsafe(24), "expires": now + 8 * 3600}
            with self.lock:
                if self.config != config:
                    raise APIError(401, "密码已变更，请重新登录")
                self.sessions[token] = session
            secure = "; Secure" if scheme == "https" else ""
            headers.append(("Set-Cookie", f"mp_session={token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=28800{secure}"))
            return 200, {"csrf": session["csrf"], "username": username}, headers
        if not session:
            raise APIError(401, "请先登录")
        if method == "POST":
            if not hmac.compare_digest(env.get("HTTP_X_CSRF_TOKEN", ""), session["csrf"]):
                raise APIError(403, "操作令牌失效，请重新登录")
            if path == '/api/files/upload':
                query = parse_qs(env.get('QUERY_STRING', ''), keep_blank_values=True)
                data = {key: values[0] for key, values in query.items() if len(values) == 1}
                if data.get('overwrite', 'false') not in {'true', 'false'}:
                    raise ValueError('覆盖选项无效')
                data['overwrite'] = data.get('overwrite') == 'true'
                if env.get('CONTENT_TYPE') != 'application/octet-stream':
                    raise APIError(415, '上传接口仅接受文件二进制数据')
                size = int(env.get('CONTENT_LENGTH') or '-1')
                if size < 0:
                    raise APIError(411, '上传请求必须提供文件大小')
            else:
                data = self.body(env)
        else:
            data = {}
        if method == "GET" and path == "/api/session":
            result = {"csrf": session["csrf"], "username": self.config["username"]}
        elif method == "POST" and path == "/api/logout":
            with self.lock:
                self.sessions.pop(token, None)
            headers.append(("Set-Cookie", "mp_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0"))
            result = {"message": "已退出登录"}
        elif method == 'POST' and path == '/api/account/password':
            old, new = data.get('old_password'), data.get('new_password')
            if not isinstance(old, str) or len(old) > 256:
                raise ValueError('原密码格式无效')
            if not isinstance(new, str) or not 12 <= len(new) <= 256:
                raise ValueError('新密码需要 12 至 256 个字符')
            if new != data.get('confirm_password'):
                raise ValueError('两次输入的新密码不一致')
            if not self.operation.acquire(blocking=False):
                raise APIError(409, '已有任务正在进行，请稍后修改密码')
            try:
                with self.lock:
                    if token not in self.sessions:
                        raise APIError(401, '登录已失效')
                    now = time.time()
                    while self.password_attempts and self.password_attempts[0] < now - 300:
                        self.password_attempts.popleft()
                    if len(self.password_attempts) >= 5:
                        raise APIError(429, '密码验证尝试过多，请 5 分钟后重试')
                    self.password_attempts.append(now)
                    if not hmac.compare_digest(password_hash(old, self.config['salt']), self.config['password_hash']):
                        raise ValueError('原密码不正确')
                    result = self.backend.call('change_password', {'old_password': old, 'new_password': new})
                    self.config = result['config']
                    self.sessions.clear()
                    self.attempts.clear()
                headers.append(('Set-Cookie', 'mp_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0'))
                result = {'message': '密码已修改，所有登录已退出，请使用新密码登录'}
            finally:
                self.operation.release()
        elif method == "GET" and path == "/api/status":
            result = self.backend.call("status", {})
        elif method == 'GET' and path in {'/api/files', '/api/files/download'}:
            query = parse_qs(env.get('QUERY_STRING', ''), keep_blank_values=True)
            data = {key: values[0] for key, values in query.items() if len(values) == 1}
            validate_file_request(data)
            if path.endswith('download'):
                data['name'] = file_name(data.get('name'))
                result = self.backend.download(data)
                return 200, result, [('Content-Type', 'application/octet-stream'), ('Content-Disposition', "attachment; filename*=UTF-8''" + quote(result.name, safe=''))]
            result = self.backend.call('files_list', data)
        elif method == "GET" and path == "/api/job":
            with self.lock:
                result = json.loads(json.dumps(self.job)) if self.job else None
        elif method == "POST" and path == "/api/install":
            if not self.operation.acquire(blocking=False):
                raise APIError(409, "已有任务正在进行")
            with self.lock:
                self.job = {"status": "running", "message": "正在安装运行环境", "logs": [], "started": time.time()}
                self.save_job()
            threading.Thread(target=self.install_worker, daemon=True).start()
            result = {"message": "安装任务已开始"}
        elif method == "POST" and path in {"/api/sites", "/api/sites/toggle", "/api/sites/ssl", "/api/restart", "/api/databases", '/api/files/upload', '/api/files/mkdir', '/api/files/extract', '/api/files/create', '/api/files/delete', '/api/sites/root'}:
            actions = {"/api/sites": "create_site", "/api/sites/toggle": "toggle_site", "/api/restart": "restart", "/api/databases": "create_database", '/api/sites/ssl': 'configure_ssl', '/api/files/upload': 'files_upload', '/api/files/mkdir': 'files_mkdir', '/api/files/extract': 'files_extract', '/api/files/create': 'files_create', '/api/files/delete': 'files_delete', '/api/sites/root': 'site_root'}
            if path.startswith("/api/sites"):
                data["domain"] = domain_name(data.get("domain"))
                if path in {"/api/sites", "/api/sites/root"}:
                    data["root"] = website_root(data.get("root"), data["domain"])
                if path.endswith("toggle") and type(data.get("enabled")) is not bool:
                    raise ValueError("网站状态无效")
                if path.endswith('ssl'):
                    if type(data.get('ssl')) is not bool or type(data.get('force_https')) is not bool:
                        raise ValueError('SSL 设置格式无效')
                    if data['force_https'] and not data['ssl']:
                        raise ValueError('请先启用网站 SSL，再开启强制 HTTPS')
            if path.startswith('/api/files/'):
                validate_file_request(data)
                data['name'] = file_name(data.get('name'))
                if path == '/api/files/extract':
                    data['destination'] = file_name(data.get('destination'))
            if path == "/api/databases":
                data["name"] = database_name(data.get("name"))
            if path == "/api/restart" and data.get("service") not in {"Nginx", "PHP", "MySQL"}:
                raise ValueError("不支持的服务")
            if not self.operation.acquire(blocking=False):
                raise APIError(409, "已有任务正在进行，请稍后重试")
            try:
                if path == '/api/files/upload':
                    result = self.backend.upload(data, env['wsgi.input'], size)
                else:
                    result = self.backend.call(actions[path], data)
            finally:
                self.operation.release()
        else:
            raise APIError(404, "接口不存在")
        return 200, result, headers

    def __call__(self, env, start_response):
        try:
            status, data, headers = self.dispatch(env)
        except APIError as error:
            status, data, headers = error.status, {"error": error.message}, []
        except ValueError as error:
            status, data, headers = 400, {"error": str(error)}, []
        except Exception as error:
            status, data, headers = 500, {"error": str(error)}, []
        streamed = isinstance(data, FileStream)
        if not isinstance(data, bytes) and not streamed:
            data = json.dumps(data, ensure_ascii=False).encode()
            headers.append(("Content-Type", "application/json; charset=utf-8"))
        headers.extend([("Content-Length", str(data.size if streamed else len(data))), ("Cache-Control", "no-store"), ("X-Content-Type-Options", "nosniff"),
                        ("X-Frame-Options", "DENY"), ("Referrer-Policy", "no-referrer"),
                        ("Content-Security-Policy", "default-src 'self'; style-src 'self'; script-src 'self'; img-src 'self' data:; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")])
        from http import HTTPStatus
        start_response(f"{status} {HTTPStatus(status).phrase}", headers)
        return data.chunks if streamed else [data]


def create_app():
    config = json.loads(Path("/etc/minipanel/auth.json").read_text())
    return Panel(config, data_dir="/var/lib/minipanel")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--demo", action="store_true", help="Local preview; all system actions are simulated")
    args = parser.parse_args()
    if args.demo:
        password = os.environ.get("MINIPANEL_DEMO_PASSWORD") or secrets.token_urlsafe(16)
        app = Panel(make_config(password), DemoBackend())
        print(f"DEMO ONLY http://127.0.0.1:8888  admin / {password}", flush=True)
        from socketserver import ThreadingMixIn
        from wsgiref.simple_server import make_server, WSGIServer
        class ThreadedServer(ThreadingMixIn, WSGIServer):
            daemon_threads = True
        make_server("127.0.0.1", 8888, app, server_class=ThreadedServer).serve_forever()
    else:
        raise SystemExit("服务器请使用安装脚本创建的 minipanel systemd 服务启动。预览可使用 --demo。")


if __name__ == "__main__":
    main()
