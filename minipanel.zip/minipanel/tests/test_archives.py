import io
import os
from pathlib import Path
import stat
import tarfile
import tempfile
import time
import unittest
import zipfile

import test_panel
import file_manager as fm


def zip_bytes(entries):
    data = io.BytesIO()
    with zipfile.ZipFile(data, 'w', zipfile.ZIP_DEFLATED) as archive:
        for name, content in entries:
            if isinstance(name, str):
                info = zipfile.ZipInfo(name)
                info.filename = name  # Preserve malicious backslashes even on Windows.
                name = info
            archive.writestr(name, content)
    return data.getvalue()


class ArchiveTests(unittest.TestCase):
    def test_zip_roundtrip_and_streaming(self):
        data = zip_bytes([('app/', b''), ('app/index.php', b'<?php echo 1;'), ('中文.txt', b'hello')])
        with fm.archive_members(io.BytesIO(data), 'app.zip') as (entries, opener):
            self.assertEqual(len(entries), 3)
            with opener(entries[1][3]) as source:
                target = io.BytesIO()
                fm.copy_archive_member(source, target, entries[1][2], time.monotonic()+10)
                self.assertEqual(target.getvalue(), b'<?php echo 1;')

    def test_tar_gzip_common_dot_prefix(self):
        data = io.BytesIO()
        with tarfile.open(fileobj=data, mode='w:gz') as archive:
            root=tarfile.TarInfo('./'); root.type=tarfile.DIRTYPE; archive.addfile(root)
            item=tarfile.TarInfo('./app/index.php'); item.size=3
            archive.addfile(item, io.BytesIO(b'php'))
        data.seek(0)
        with fm.archive_members(data, 'app.tgz') as (entries, opener):
            self.assertEqual(entries[0][0], 'app/index.php')
            with opener(entries[0][3]) as source:
                self.assertEqual(source.read(), b'php')

    def test_zip_rejects_traversal_absolute_windows_duplicate_and_conflicts(self):
        bad = [('../escape', b'x'), ('/etc/passwd', b'x'), ('a/../../b', b'x'), ('C:/x', b'x'), ('a\\b', b'x')]
        for entry in bad:
            with self.subTest(entry=entry), self.assertRaises(ValueError):
                with fm.archive_members(io.BytesIO(zip_bytes([entry])), 'x.zip'):
                    pass
        for entries in [[('a', b'x'), ('a/b', b'x')], [('a', b'x'), ('./a', b'x')]]:
            with self.assertRaises(ValueError):
                with fm.archive_members(io.BytesIO(zip_bytes(entries)), 'x.zip'):
                    pass

    def test_reject_zip_symlink_and_tar_links_devices(self):
        link=zipfile.ZipInfo('link'); link.create_system=3; link.external_attr=(stat.S_IFLNK|0o777)<<16
        with self.assertRaises(ValueError):
            with fm.archive_members(io.BytesIO(zip_bytes([(link,'/etc/passwd')])), 'x.zip'):
                pass
        for kind in [tarfile.SYMTYPE,tarfile.LNKTYPE,tarfile.CHRTYPE,tarfile.FIFOTYPE]:
            data=io.BytesIO()
            with tarfile.open(fileobj=data,mode='w') as archive:
                member=tarfile.TarInfo('danger'); member.type=kind; member.linkname='/etc/passwd'; archive.addfile(member)
            data.seek(0)
            with self.subTest(kind=kind), self.assertRaises(ValueError):
                with fm.archive_members(data,'x.tar'):
                    pass

    def test_corrupt_archive_and_interrupted_stream(self):
        for name in ['app.zip','app.tar.gz','app.rar']:
            with self.subTest(name=name),self.assertRaises(ValueError):
                with fm.archive_members(io.BytesIO(b'not an archive'),name):
                    pass
        with self.assertRaises(ValueError):
            fm.copy_archive_member(io.BytesIO(b'x'),io.BytesIO(),10,time.monotonic()+5)
        with self.assertRaises(ValueError):
            fm.copy_archive_member(io.BytesIO(b'x'),io.BytesIO(),1,time.monotonic()-1)

    @unittest.skipUnless(os.name == 'posix', 'Linux dir_fd integration requires Debian')
    def test_real_extraction_nested_files_no_overwrite_and_symlink(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder)
            (root/'app.zip').write_bytes(zip_bytes([('app/index.php',b'hello'),('empty/',b'')]))
            data={'path':'','name':'app.zip','destination':'unpacked'}
            result=fm.operate(root,'files_extract',data)
            self.assertEqual(result['path'],'unpacked')
            self.assertEqual((root/'unpacked/app/index.php').read_bytes(),b'hello')
            self.assertTrue((root/'unpacked/empty').is_dir())
            with self.assertRaises(ValueError): fm.operate(root,'files_extract',data)
            (root/'linked.zip').symlink_to(root/'app.zip')
            with self.assertRaises(ValueError): fm.operate(root,'files_extract',dict(data,name='linked.zip',destination='other'))
            (root/'bad.zip').write_bytes(zip_bytes([('../outside',b'x')]))
            with self.assertRaises(ValueError): fm.operate(root,'files_extract',dict(data,name='bad.zip',destination='bad'))
            self.assertFalse((root/'bad').exists())


class ExtractionAPITests(unittest.TestCase):
    setUp=test_panel.PanelTests.setUp
    request=test_panel.PanelTests.request
    login=test_panel.PanelTests.login

    def test_extract_upload_select_destination_and_download(self):
        self.login(); self.app.backend.installed=True
        self.request('/api/sites', {'domain':'files.example.com'})
        archive=zip_bytes([('app/index.php',b'<?php echo 1;'),('empty/',b'')])
        upload=self.request('/api/files/upload',archive,QUERY_STRING='domain=files.example.com&path=&name=app.zip',CONTENT_TYPE='application/octet-stream')
        self.assertEqual(upload['status'],200)
        data={'domain':'files.example.com','path':'','name':'app.zip','destination':'unpacked'}
        self.assertEqual(self.request('/api/files/extract',data,HTTP_X_CSRF_TOKEN='')['status'],403)
        self.assertEqual(self.request('/api/files/extract',dict(data,destination='../escape'))['status'],400)
        result=self.request('/api/files/extract',data)
        self.assertEqual(result['status'],200,result)
        self.assertEqual(result['body']['path'],'unpacked')
        listing=self.request('/api/files',QUERY_STRING='domain=files.example.com&path=unpacked')['body']['entries']
        self.assertEqual([e['name'] for e in listing],['app','empty'])
        download=self.request('/api/files/download',QUERY_STRING='domain=files.example.com&path=unpacked/app&name=index.php')
        self.assertEqual(download['body'],b'<?php echo 1;')
        self.assertEqual(self.request('/api/files/extract',data)['status'],400)
        self.assertEqual(self.request('/api/files/download',QUERY_STRING='domain=files.example.com&path=&name=app.zip')['body'],archive)

    def test_unsafe_archive_does_not_create_destination(self):
        self.login(); self.app.backend.installed=True
        self.request('/api/sites',{'domain':'files.example.com'})
        archive=zip_bytes([('fine.txt',b'ok'),('../bad.txt',b'no')])
        self.request('/api/files/upload',archive,QUERY_STRING='domain=files.example.com&name=bad.zip',CONTENT_TYPE='application/octet-stream')
        result=self.request('/api/files/extract',{'domain':'files.example.com','name':'bad.zip','destination':'result'})
        self.assertEqual(result['status'],400)
        self.assertNotIn('result',self.app.backend.directories['files.example.com'])


if __name__ == '__main__': unittest.main()
