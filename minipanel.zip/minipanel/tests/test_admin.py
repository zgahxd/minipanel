import io
import os
from pathlib import Path
import tempfile
import types
import sys
import json
import unittest
from unittest.mock import patch
from urllib.parse import urlencode

import test_panel
from common import website_root, nginx_config, check_system_path, make_config, password_hash
import file_manager as fm
import helper


class AdminAPITests(unittest.TestCase):
    setUp = test_panel.PanelTests.setUp
    request = test_panel.PanelTests.request
    login = test_panel.PanelTests.login

    def test_system_files_before_stack_install_create_upload_download_delete(self):
        self.login()
        data = {'scope':'system', 'path':'/tmp', 'name':'cloud-test'}
        self.assertEqual(self.request('/api/files/mkdir', data)['status'],200)
        data.update(path='/tmp/cloud-test',name='empty.php')
        self.assertEqual(self.request('/api/files/create', data)['status'],200)
        self.assertEqual(self.request('/api/files/create', data)['status'],400)
        data['name']='payload.txt'
        self.assertEqual(self.request('/api/files/upload', b'hello', QUERY_STRING=urlencode(data), CONTENT_TYPE='application/octet-stream')['status'],200)
        self.assertEqual(self.request('/api/files/download',QUERY_STRING=urlencode(data))['body'],b'hello')
        self.assertEqual(self.request('/api/files/delete',dict(data,path='/tmp',name='cloud-test'))['status'],200)
        self.assertEqual(self.request('/api/files',QUERY_STRING=urlencode(data))['status'],400)

    def test_system_boundaries_and_protected_paths(self):
        self.login()
        for path in ['/tmp/../etc', '/proc', '/sys', '/dev', '/tmp//x']:
            self.assertEqual(self.request('/api/files',QUERY_STRING=urlencode({'scope':'system','path':path}))['status'],400)
        for path,name in [('/','etc'),('/','var'),('/opt','minipanel'),('/root','minipanel-login.txt')]:
            self.assertEqual(self.request('/api/files/delete',{'scope':'system','path':path,'name':name})['status'],400)
        self.assertEqual(self.request('/api/files/create',{'scope':'system','path':'/tmp','name':'../x'})['status'],400)
        self.assertEqual(self.request('/api/files/create',{'scope':'system','path':'/tmp','name':'ok'},HTTP_X_CSRF_TOKEN='bad')['status'],403)

    def test_custom_root_and_site_views_share_contents_and_root_change_keeps_old_files(self):
        self.login(); self.app.backend.installed=True
        self.assertEqual(self.request('/api/sites',{'domain':'disk.example.com','root':'/srv/pan/public'})['status'],200)
        self.request('/api/files/create',{'scope':'system','path':'/srv/pan/public','name':'shared.txt'})
        listing=self.request('/api/files',QUERY_STRING='domain=disk.example.com&path=')['body']
        self.assertIn('shared.txt',[e['name'] for e in listing['entries']])
        self.assertEqual(self.request('/api/files/delete',{'scope':'system','path':'/srv/pan','name':'public'})['status'],400)
        self.request('/api/sites/ssl',{'domain':'disk.example.com','ssl':True,'force_https':True})
        self.assertEqual(self.request('/api/sites/root',{'domain':'disk.example.com','root':'/srv/other'})['status'],200)
        site=self.request('/api/status')['body']['sites'][0]
        self.assertEqual(site['root'],'/srv/other');self.assertTrue(site['force_https'])
        self.assertEqual(self.request('/api/files/download',QUERY_STRING='scope=system&path=/srv/pan/public&name=shared.txt')['status'],200)

    def test_password_validation_invalidation_and_new_login(self):
        self.login(); old_cookie=self.cookie
        self.login(); second_cookie=self.cookie
        data={'old_password':'wrong','new_password':'replacement-secret-123','confirm_password':'replacement-secret-123'}
        self.assertEqual(self.request('/api/account/password',data)['status'],400)
        data['old_password']='test-password-12345'
        self.assertEqual(self.request('/api/account/password',dict(data,confirm_password='mismatch'))['status'],400)
        self.assertEqual(self.request('/api/account/password',data,HTTP_X_CSRF_TOKEN='bad')['status'],403)
        result=self.request('/api/account/password',data)
        self.assertEqual(result['status'],200);self.assertNotIn('config',result['body'])
        for cookie in (old_cookie,second_cookie):
            self.assertEqual(self.request('/api/status',HTTP_COOKIE=cookie)['status'],401)
        self.assertEqual(self.request('/api/login',{'username':'admin','password':'test-password-12345'})['status'],401)
        self.assertEqual(self.request('/api/login',{'username':'admin','password':data['new_password']})['status'],200)

    def test_password_failure_preserves_current_account_and_session(self):
        self.login(); before=self.app.config.copy()
        with patch.object(self.app.backend,'call',side_effect=RuntimeError('disk full')):
            result=self.request('/api/account/password',{'old_password':'test-password-12345','new_password':'replacement-secret-123','confirm_password':'replacement-secret-123'})
        self.assertEqual(result['status'],500);self.assertEqual(before,self.app.config)
        self.assertEqual(self.request('/api/session')['status'],200)

    def test_password_attempts_rate_limited(self):
        self.login()
        data={'old_password':'wrong','new_password':'replacement-secret-123','confirm_password':'replacement-secret-123'}
        for _ in range(5):self.assertEqual(self.request('/api/account/password',data)['status'],400)
        self.assertEqual(self.request('/api/account/password',data)['status'],429)


class AdminValidationTests(unittest.TestCase):
    def test_helper_password_persists_hash_and_rejects_wrong_old_password(self):
        with tempfile.TemporaryDirectory() as folder:
            auth=Path(folder)/'auth.json';auth.write_text(json.dumps(make_config('original-secret-123')))
            group=types.SimpleNamespace(getgrnam=lambda _:types.SimpleNamespace(gr_gid=123))
            with patch.object(helper,'Path',return_value=auth),patch.dict(sys.modules,{'grp':group}),patch.object(helper.os,'fchown',create=True),patch.object(helper.os,'fchmod',create=True):
                with self.assertRaises(ValueError):helper.change_password({'old_password':'wrong','new_password':'replacement-secret-123'})
                result=helper.change_password({'old_password':'original-secret-123','new_password':'replacement-secret-123'})
            saved=json.loads(auth.read_text());self.assertEqual(saved,result['config'])
            self.assertEqual(saved['password_hash'],password_hash('replacement-secret-123',saved['salt']))
            self.assertNotIn('replacement-secret-123',auth.read_text())
            self.assertEqual(list(Path(folder).iterdir()),[auth])

    def test_root_config_injection_and_critical_directories(self):
        for root in ['/','/etc','/var','/opt','/root/public','/srv/a;return 200','/srv/a\n','/srv/../etc','/srv/a b','/srv/$host']:
            with self.subTest(root=root),self.assertRaises(ValueError):website_root(root,'x.example.com')
        self.assertIn('root /mnt/disk/public;',nginx_config('x.example.com','8.2',root='/mnt/disk/public',ssl=True,force_https=True))

    def test_custom_root_failure_does_not_change_site_metadata(self):
        sites=[{'domain':'x.example.com','root':'/srv/old','php':'8.2','enabled':True,'ssl':True,'force_https':True}]
        with patch.object(helper,'read_json',return_value=sites),patch.object(helper,'prepare_root',return_value='/srv/new'),patch.object(helper,'write_json') as written,patch.object(helper,'apply_site',side_effect=RuntimeError('invalid nginx')):
            with self.assertRaises(RuntimeError):helper.site_root({'domain':'x.example.com','root':'/srv/new'})
            self.assertEqual(sites[0]['root'],'/srv/old');written.assert_not_called()

    def test_toggling_and_ssl_keep_custom_root(self):
        sites=[{'domain':'x.example.com','root':'/srv/keep','php':'8.2','enabled':True,'ssl':True,'force_https':True}]
        with patch.object(helper,'read_json',return_value=sites),patch.object(helper,'write_json'),patch.object(helper,'apply_site') as apply:
            helper.configure_ssl({'domain':'x.example.com','ssl':False,'force_https':False})
            self.assertIn('root /srv/keep;',apply.call_args.args[1])
            helper.toggle_site({'domain':'x.example.com','enabled':True})
            self.assertIn('root /srv/keep;',apply.call_args.args[1])

    @unittest.skipUnless(os.name=='posix','Native filesystem integration requires Linux')
    def test_real_recursive_deletion_does_not_follow_symlinks(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);(root/'nested').mkdir();(root/'keep').write_text('keep')
            (root/'nested'/'link').symlink_to(root/'keep')
            fm.operate(root,'files_create',{'path':'nested','name':'empty'})
            with self.assertRaises(ValueError):fm.operate(root,'files_create',{'path':'nested','name':'empty'})
            fm.operate(root,'files_delete',{'path':'','name':'nested'})
            self.assertTrue((root/'keep').exists());self.assertFalse((root/'nested').exists())


if __name__=='__main__':unittest.main()
