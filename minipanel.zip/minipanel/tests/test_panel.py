import io
import base64
import json
from pathlib import Path
import sys
import tempfile
import time
import types
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from app import DemoBackend, Panel, make_config
from common import database_name, domain_name, nginx_config
import file_manager


class PanelTests(unittest.TestCase):
    def setUp(self):
        self.app = Panel(make_config("test-password-12345"), DemoBackend())
        self.cookie = ""
        self.csrf = ""

    def request(self, path, data=None, **overrides):
        raw = data if isinstance(data, bytes) else json.dumps(data).encode() if data is not None else b""
        env = {"PATH_INFO": path, "REQUEST_METHOD": "POST" if data is not None else "GET", "HTTP_HOST": "127.0.0.1:8888",
               "CONTENT_TYPE": "application/json", "CONTENT_LENGTH": str(len(raw)), "wsgi.input": io.BytesIO(raw),
               "HTTP_COOKIE": self.cookie, "HTTP_X_CSRF_TOKEN": self.csrf}
        env.update(overrides)
        response = {}
        def start(status, headers):
            response["status"] = int(status.split()[0])
            response["headers"] = dict(headers)
        body = b"".join(self.app(env, start))
        response["body"] = json.loads(body) if "application/json" in response["headers"]["Content-Type"] else body
        return response

    def login(self):
        response = self.request("/api/login", {"username": "admin", "password": "test-password-12345"})
        self.assertEqual(response["status"], 200)
        self.cookie = response["headers"]["Set-Cookie"].split(";")[0]
        self.csrf = response["body"]["csrf"]

    def test_auth_and_logout(self):
        self.assertEqual(self.request("/api/status")["status"], 401)
        self.assertEqual(self.request("/api/login", {"username": "admin", "password": "bad"})["status"], 401)
        self.login()
        self.assertEqual(self.request("/api/status")["status"], 200)
        self.assertEqual(self.request("/api/logout", {})["status"], 200)
        self.assertEqual(self.request("/api/status")["status"], 401)

    def test_csrf_origin_and_rebinding(self):
        self.login()
        self.assertEqual(self.request("/api/install", {}, HTTP_X_CSRF_TOKEN="wrong")["status"], 403)
        self.assertEqual(self.request("/api/install", {}, HTTP_ORIGIN="http://evil.example")["status"], 403)
        self.assertEqual(self.request("/api/status", HTTP_HOST="evil.example:8888")["status"], 403)
        self.assertFalse(self.app.backend.installed)

    def test_install_site_and_database_lifecycle(self):
        self.login()
        self.assertEqual(self.request("/api/sites", {"domain": "example.com"})["status"], 409)
        self.assertEqual(self.request("/api/install", {})["status"], 200)
        self.assertEqual(self.request("/api/install", {})["status"], 409)
        self.assertEqual(self.request("/api/sites", {"domain": "example.com"})["status"], 409)
        deadline = time.monotonic() + 5
        while self.app.job["status"] == "running" and time.monotonic() < deadline:
            time.sleep(.05)
        self.assertEqual(self.app.job["status"], "success")
        self.assertEqual(self.request("/api/sites", {"domain": "Example.COM"})["status"], 200)
        self.assertEqual(self.request("/api/sites", {"domain": "example.com"})["status"], 400)
        self.assertEqual(self.request("/api/sites/toggle", {"domain": "example.com", "enabled": False})["status"], 200)
        self.assertFalse(self.request("/api/status")["body"]["sites"][0]["enabled"])
        response = self.request("/api/databases", {"name": "my_app"})
        self.assertEqual(response["status"], 200)
        self.assertEqual(len(response["body"]["password"]), 32)
        self.assertNotIn("password", self.request("/api/status")["body"]["databases"][0])
        self.assertEqual(self.request("/api/databases", {"name": "my_app"})["status"], 400)

    def test_request_limits_and_service_allowlist(self):
        self.login()
        self.assertEqual(self.request("/api/install", {}, CONTENT_LENGTH="999999")["status"], 413)
        self.assertEqual(self.request("/api/install", {}, CONTENT_TYPE="text/plain")["status"], 415)
        self.assertEqual(self.request("/api/restart", {"service": "nginx; id"})["status"], 400)
        self.assertEqual(self.request("/api/sites/toggle", {"domain": "example.com", "enabled": "false"})["status"], 400)

    def test_login_rate_limit(self):
        for _ in range(10):
            self.request("/api/login", {"username": "admin", "password": "bad"})
        self.assertEqual(self.request("/api/login", {"username": "admin", "password": "bad"})["status"], 429)

    def test_security_headers_and_no_static_traversal(self):
        response = self.request("/")
        self.assertEqual(response["status"], 200)
        self.assertIn("frame-ancestors 'none'", response["headers"]["Content-Security-Policy"])
        self.assertEqual(response["headers"]["Cache-Control"], "no-store")
        self.assertNotEqual(self.request("/static/../app.py")["status"], 200)

    def test_interrupted_job_is_failed(self):
        with tempfile.TemporaryDirectory() as folder:
            Path(folder, "last-job.json").write_text(json.dumps({"status":"running", "logs":[]}))
            app = Panel(self.app.config, DemoBackend(), folder)
            self.assertEqual(app.job["status"], "failed")

    def test_production_https_and_secure_cookie(self):
        from app import SystemBackend
        self.app.backend = SystemBackend()
        self.assertEqual(self.request("/", HTTP_HOST="203.0.113.10:8888")["status"], 403)
        result = self.request("/api/login", {"username":"admin", "password":"test-password-12345"},
                              HTTP_HOST="203.0.113.10:8888", HTTP_ORIGIN="https://203.0.113.10:8888", **{"wsgi.url_scheme":"https"})
        self.assertEqual(result["status"], 200)
        self.assertIn("; Secure", result["headers"]["Set-Cookie"])

    def test_file_manager_roundtrip_and_boundaries(self):
        self.login()
        self.app.backend.installed = True
        self.request('/api/sites', {'domain':'files.example.com'})
        meta = {'domain':'files.example.com', 'path':'', 'name':'images'}
        self.assertEqual(self.request('/api/files/mkdir', meta)['status'], 200)
        content = b'test-data-' * 2000
        query = 'domain=files.example.com&path=images&name=sample.txt'
        upload = {'QUERY_STRING':query, 'CONTENT_TYPE':'application/octet-stream'}
        self.assertEqual(self.request('/api/files/upload', content, **upload)['status'], 200)
        self.assertEqual(self.request('/api/files/upload', content, **upload)['status'], 400)
        self.assertEqual(self.request('/api/files/upload', content, **dict(upload,QUERY_STRING=query+'&overwrite=true'))['status'], 200)
        listing = self.request('/api/files', QUERY_STRING='domain=files.example.com&path=images')
        self.assertEqual(listing['body']['entries'][0]['name'], 'sample.txt')
        download = self.request('/api/files/download', QUERY_STRING='domain=files.example.com&path=images&name=sample.txt')
        self.assertEqual(download['body'], content)
        self.assertIn('attachment;', download['headers']['Content-Disposition'])
        self.assertEqual(self.request('/api/files', QUERY_STRING='domain=files.example.com&path=..%2F..')['status'], 400)
        self.assertEqual(self.request('/api/files/mkdir', dict(meta,name='../escape'))['status'], 400)
        self.assertEqual(self.request('/api/files/upload', content, HTTP_X_CSRF_TOKEN='', **upload)['status'], 403)

    def test_site_ssl_toggle_and_force_https(self):
        self.login()
        self.app.backend.installed = True
        self.request('/api/sites', {'domain':'ssl.example.com'})
        data = {'domain':'ssl.example.com', 'ssl':False, 'force_https':True}
        self.assertEqual(self.request('/api/sites/ssl', data)['status'], 400)
        self.assertEqual(self.request('/api/sites/ssl', dict(data,ssl=True))['status'], 200)
        site = self.request('/api/status')['body']['sites'][0]
        self.assertTrue(site['ssl']); self.assertTrue(site['force_https'])
        self.assertEqual(self.request('/api/sites/ssl', dict(data,force_https=False))['status'], 200)
        self.assertFalse(self.request('/api/status')['body']['sites'][0]['ssl'])


class ValidationTests(unittest.TestCase):
    def test_domain_normalization(self):
        self.assertEqual(domain_name(" Example.COM. "), "example.com")
        self.assertEqual(domain_name("示例.中国"), "xn--fsq092h.xn--fiqs8s")

    def test_reject_command_config_and_path_injection(self):
        for value in ["a.com;id", "a.com\nroot /tmp;", "$(id).com", "../etc/passwd", "https://a.com", "a.com:80", "*.a.com", "-a.com", "a_.com", "127.0.0.1", "a..com", "a"*64+".com", None]:
            with self.subTest(value=value), self.assertRaises(ValueError):
                domain_name(value)
        for value in ["abc; DROP DATABASE mysql;", "../tmp", "mysql root", "A", "a"*25, None]:
            with self.subTest(value=value), self.assertRaises(ValueError):
                database_name(value)

    def test_nginx_php_execution_guard(self):
        conf = nginx_config("example.com", "8.4")
        self.assertIn("try_files $uri =404;", conf)
        self.assertIn("/run/php/php8.4-fpm.sock", conf)
        self.assertIn("location ~ /\\.", conf)
        with self.assertRaises(ValueError):
            nginx_config("example.com", "8.4; include /tmp/*")

    def test_nginx_ssl_and_redirect_config(self):
        conf = nginx_config('example.com', '8.4', ssl=True, force_https=True)
        self.assertIn('listen 443 ssl;', conf)
        self.assertIn('/sites-ssl/example.com/cert.pem', conf)
        self.assertIn('return 308 https://example.com$request_uri;', conf)
        self.assertNotIn('return 308', nginx_config('example.com','8.4',ssl=True))
        disabled = nginx_config('example.com','8.4',ssl=True,force_https=True,enabled=False)
        self.assertIn('return 503;', disabled); self.assertNotIn('return 308', disabled)
        with self.assertRaises(ValueError):
            nginx_config('example.com','8.4',force_https=True)

    def test_file_path_validation(self):
        self.assertEqual(file_manager.relative_path('images/2026'), ['images','2026'])
        self.assertEqual(file_manager.relative_path(''), [])
        for path in ['../etc', '/etc', 'a/../b', 'a//b', 'a\\b', 'a\x00b']:
            with self.subTest(path=path), self.assertRaises(ValueError):
                file_manager.relative_path(path)
        with patch.object(file_manager.os, 'open') as opened, self.assertRaises(ValueError):
            file_manager.operate('/site', 'files_list', {'path':'../outside'})
        opened.assert_not_called()

    def test_directory_walk_requires_nofollow(self):
        with patch.object(file_manager.os, 'O_DIRECTORY', 0x10000, create=True), patch.object(file_manager.os, 'O_NOFOLLOW', 0x20000, create=True), patch.object(file_manager.os, 'open', side_effect=[10,11]) as opened, patch.object(file_manager.os, 'close'):
            with file_manager.directory_fd('/site', 'images') as fd:
                self.assertEqual(fd, 11)
            self.assertTrue(opened.call_args.args[1] & 0x20000)
            self.assertEqual(opened.call_args.kwargs['dir_fd'], 10)

    def test_large_upload_is_streamed_and_short_reads_fail(self):
        class Source:
            def read(self, size):
                assert 0 < size <= file_manager.CHUNK_SIZE
                return b'x' * size
        class Target:
            total = 0
            def write(self, value):
                self.total += len(value)
        target = Target()
        file_manager.copy_upload(Source(), target, 25*1024*1024)
        self.assertEqual(target.total, 25*1024*1024)
        with self.assertRaises(ValueError):
            file_manager.copy_upload(io.BytesIO(b'short'), io.BytesIO(), 100)

    def test_nginx_upload_has_no_fixed_cap(self):
        self.assertIn('client_max_body_size 0;', nginx_config('cloud.example.com','8.4'))


# The helper is Linux-only. Mock just fcntl when checking config rollback on Windows.
if sys.platform == "win32":
    sys.modules.setdefault("fcntl", types.SimpleNamespace())
import helper


class HelperTests(unittest.TestCase):
    def test_database_grants_escape_wildcards(self):
        with patch.object(helper, "mysql_command", return_value=["mysql"]), patch.object(helper, "read_json", return_value=[]), patch.object(helper, "write_json"), patch.object(helper, "run") as run:
            run.return_value = types.SimpleNamespace(stdout="")
            helper.create_database({"name":"my_app"})
            self.assertIn("`my\\_app`.*", run.call_args.kwargs["data"])

    def test_failed_nginx_validation_rolls_back_existing_config(self):
        with tempfile.TemporaryDirectory() as folder:
            available, enabled = Path(folder, "available"), Path(folder, "enabled")
            available.mkdir(); enabled.mkdir()
            file = available / "mp-example.com.conf"
            file.write_text("original")
            with patch.object(helper, "AVAILABLE", available), patch.object(helper, "ENABLED", enabled), patch.object(helper, "run") as run:
                run.side_effect = [RuntimeError("nginx rejected configuration"), None]
                with self.assertRaises(RuntimeError):
                    # Keep disabled so Windows test does not require symlink privileges.
                    helper.apply_site("example.com", "invalid config", False)
                self.assertEqual(file.read_text(), "original")
                self.assertFalse((enabled / file.name).exists())

    def test_failed_new_config_is_removed(self):
        with tempfile.TemporaryDirectory() as folder:
            available, enabled = Path(folder, "available"), Path(folder, "enabled")
            available.mkdir(); enabled.mkdir()
            with patch.object(helper, "AVAILABLE", available), patch.object(helper, "ENABLED", enabled), patch.object(helper, "run") as run:
                run.side_effect = [RuntimeError("reload failed"), None]
                with self.assertRaises(RuntimeError):
                    helper.apply_site("example.com", "bad", False)
                self.assertFalse((available / "mp-example.com.conf").exists())

    def test_pause_uses_explicit_503_vhost(self):
        sites = [{"domain":"example.com", "php":"8.2", "enabled":True}]
        with patch.object(helper, "read_json", return_value=sites), patch.object(helper, "write_json"), patch.object(helper, "apply_site") as apply:
            helper.toggle_site({"domain":"example.com", "enabled":False})
            self.assertIn("return 503", apply.call_args.args[1])
            self.assertTrue(apply.call_args.args[2])
            self.assertFalse(sites[0]["enabled"])

    def test_failed_database_grant_removes_only_new_resources(self):
        with patch.object(helper, "mysql_command", return_value=["mysql"]), patch.object(helper, "read_json", return_value=[]), patch.object(helper, "run") as run:
            run.side_effect = [types.SimpleNamespace(stdout=""), None, None, RuntimeError("grant failed"), None]
            with self.assertRaises(RuntimeError):
                helper.create_database({"name":"my_app"})
            self.assertIn("DROP USER 'my_app'", run.call_args.kwargs["data"])
            self.assertIn("DROP DATABASE `my_app`", run.call_args.kwargs["data"])


if __name__ == "__main__":
    unittest.main()
