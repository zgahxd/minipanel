#!/usr/bin/python3 -I
"""Root systemd timer entry point; shares the panel mutation lock."""
import fcntl
import os
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from helper import STATE, read_json, write_json, run
from ssl_manager import renewal_check

if __name__ == '__main__':
    if os.geteuid() != 0:
        raise SystemExit('必须由 root 运行')
    with (STATE / 'operation.lock').open('a') as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise SystemExit('面板正在执行其他操作，稍后自动重试')
        status = renewal_check(run, read_json, write_json, include_panel=True)
        error = '; '.join(filter(None, [status.get('error'), status.get('panel_error')]))
        print(error or status['message'])
        raise SystemExit(1 if error else 0)
