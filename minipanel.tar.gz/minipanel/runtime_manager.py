"""APT-backed runtime inventory and reviewed updates; never execute user commands."""
import hashlib
import json
from pathlib import Path
import re
import secrets
import time

PHP_BRANCHES = ('7.4','8.0','8.1','8.2','8.3','8.4','8.5')
PHP_EXTENSIONS = ('common','opcache','mysql','curl','mbstring','xml','zip','gd','redis','bcmath','intl')
MANAGED = re.compile(r'^(?:nginx(?:-[a-z0-9-]+)?|libnginx-mod-[a-z0-9-]+|redis-(?:server|tools)|php(?:[78]\.\d)?(?:-[a-z0-9-]+)?|mysql-(?:community-[a-z0-9-]+|client|server|common)|libmysqlclient\d+)$')
PACKAGE = re.compile(r'^[a-z0-9][a-z0-9+.-]*(?::[a-z0-9]+)?$')
VERSION = re.compile(r'^[0-9][A-Za-z0-9.+:~_-]*$')
MYSQL_SERVER = {'mysql-community-server','mysql-community-server-core','mysql-server','mysql-server-core'}


def broker():
    import helper
    return helper


def branch(value):
    if value not in PHP_BRANCHES: raise ValueError('请选择支持的 PHP 版本')
    return value


def family(version):
    match = re.match(r'^(?:\d+:)?(\d+\.\d+)', version or '')
    return match.group(1) if match else None


def installed_packages():
    out = broker().run(['dpkg-query','-W','-f=${Package}\t${Version}\t${db:Status-Status}\n']).stdout
    return {p:v for line in out.splitlines() if len(parts:=line.split('\t'))==3
            for p,v,status in [parts] if status=='installed' and PACKAGE.fullmatch(p)}


def versions(package):
    if not PACKAGE.fullmatch(package): raise ValueError('软件包名无效')
    out = broker().run(['apt-cache','madison',package], check=False).stdout
    rows=[]
    for line in out.splitlines():
        fields=[p.strip() for p in line.split('|')]
        if len(fields)==3 and VERSION.fullmatch(fields[1]) and not any(x['version']==fields[1] for x in rows):
            rows.append({'version':fields[1],'source':fields[2]})
    return rows[:50]


def candidates(packages):
    if not packages: return {}
    output=broker().run(['apt-cache','policy']+sorted(packages)).stdout
    result={}; current=None
    for line in output.splitlines():
        if line and not line[0].isspace() and line.endswith(':'): current=line[:-1]
        elif current and (match:=re.match(r'\s*Candidate:\s+(\S+)',line)):
            if VERSION.fullmatch(match.group(1)):result[current]=match.group(1)
    return result


def inventory(_=None):
    h=broker(); installed=installed_packages()
    packages=['nginx','mysql-community-server','redis-server']+['php'+v+'-fpm' for v in PHP_BRANCHES]
    return {'packages':[{'name':p,'installed':installed.get(p),'versions':versions(p)} for p in packages],
            'php_installed':[v for v in PHP_BRANCHES if 'php'+v+'-fpm' in installed],
            'php_modules':[h.php_module_status(v) for v in PHP_BRANCHES if 'php'+v+'-fpm' in installed],
            'updates':h.read_json('updates.json',{}), 'plan':h.read_json('runtime-plan.json',None),
            'last_result':h.read_json('runtime-result.json',None),
            'timer_active':h.run(['systemctl','is-active','minipanel-updates.timer'],check=False).stdout.strip()=='active'}


def check_updates(_=None):
    h=broker(); previous=h.read_json('updates.json',{})
    try:
        h.stream(['apt-get','-o','APT::Update::Error-Mode=any','update'])
        installed=installed_packages(); managed={p:v for p,v in installed.items() if MANAGED.fullmatch(p)}
        available=candidates(managed); updates=[]
        for p,old in managed.items():
            new=available.get(p)
            if new and h.run(['dpkg','--compare-versions',new,'gt',old],check=False).returncode==0:
                updates.append({'name':p,'installed':old,'candidate':new,
                                'migration_required':p in MYSQL_SERVER and family(old)!=family(new)})
        state={'checked':time.time(),'error':'','packages':updates,
               'unsupported_php':[v for v in ('7.4','8.0','8.1') if 'php'+v+'-fpm' in installed],
               'message':f'发现 {len(updates)} 个运行环境软件包可更新。包含安全和常规修复；未匹配公告不代表没有漏洞。'}
        h.write_json('updates.json',state)
        return {'message':state['message']}
    except Exception as error:
        previous.update(error=str(error),attempted=time.time())
        h.write_json('updates.json',previous)
        raise


def parse_simulation(text, installed):
    if re.search(r'^Remv\s',text,re.M):raise ValueError('APT 计划会移除软件包，已阻止；请通过 SSH 审核依赖')
    changes=[]
    for line in text.splitlines():
        if line.startswith('Inst '):
            m=re.match(r'^Inst\s+(\S+)(?:\s+\[([^\]]+)\])?\s+\((\S+)',line)
            if not m or not PACKAGE.fullmatch(m[1]) or not VERSION.fullmatch(m[3]):
                raise ValueError('无法解析 APT 更新计划')
            p,version=m[1],m[3]
            changes.append({'name':p,'from':installed.get(p) or m[2], 'to':version})
    return changes


def guard_changes(changes):
    h=broker()
    for change in changes:
        p,old,new=change['name'],change['from'],change['to']
        if old and h.run(['dpkg','--compare-versions',new,'lt',old],check=False).returncode==0:
            raise ValueError('不直接降级已安装软件：'+p+'；请使用独立实例迁移或经验证的备份恢复')
        if old and p in MYSQL_SERVER and family(old)!=family(new):
            raise ValueError('MySQL 跨系列更新必须使用迁移流程，未更改现有数据库')


def make_plan(data):
    h=broker(); installed=installed_packages(); kind=data.get('kind')
    if kind=='updates':
        state=h.read_json('updates.json',{})
        if state.get('error') or time.time()-state.get('checked',0)>86400:
            raise ValueError('请先成功检查更新，再生成更新计划')
        targets={u['name']:u['candidate'] for u in state.get('packages',[]) if not u['migration_required']}
    elif kind in ('nginx','mysql','redis','php'):
        package={'nginx':'nginx','mysql':'mysql-community-server','redis':'redis-server'}.get(kind)
        if kind=='php':
            v=branch(data.get('php'))
            if v in ('7.4','8.0','8.1') and data.get('legacy_ack') is not True:
                raise ValueError('此 PHP 分支已结束官方安全支持，请确认旧程序兼容用途')
            package='php'+v+'-fpm'
        version=data.get('version')
        if not any(row['version']==version for row in versions(package)):
            raise ValueError('所选版本不在当前软件源，请刷新版本列表')
        if kind=='redis' and 'redis-server' not in installed:
            for file in (Path('/etc/redis/redis.conf'),Path('/var/lib/redis/dump.rdb')):
                if file.exists():raise ValueError('发现已有 Redis 配置或数据，请先通过 SSH 检查，不自动接管')
        if kind=='mysql' and not (h.STATE/'mysql-managed').exists():
            raise ValueError('请先通过一键安装环境初始化 MySQL；不接管未知数据库')
        targets={package:version}
        if kind=='php':
            extras=['php'+v+'-'+name for name in ('cli',)+PHP_EXTENSIONS]
            available=candidates(extras)
            missing=[p for p in extras if p not in available and p not in installed]
            if missing:raise ValueError('软件源缺少扩展：'+', '.join(missing))
            targets.update({p:available[p] for p in extras if p in available})
    else:raise ValueError('更新类型无效')
    if not targets:raise ValueError('没有可应用的更新；跨系列 MySQL 请查看迁移清单')
    command=['apt-get','-s','--no-remove','install']+[p+'='+v for p,v in sorted(targets.items())]
    simulation=h.run(command,timeout=180).stdout
    changes=parse_simulation(simulation,installed);guard_changes(changes)
    if not changes:raise ValueError('所选软件包已是该版本，无需重复安装')
    if len(changes)>300:raise ValueError('变更超过 300 个包，请通过 SSH 检查软件源与依赖')
    plan={'id':secrets.token_hex(16),'created':time.time(),'kind':kind,'php':data.get('php'),
          'targets':targets,'changes':changes,'snapshot':installed,
          'message':'请先备份业务数据；更新可能重启服务，APT 包版本不能保证自动回滚。'}
    h.write_json('runtime-plan.json',plan)
    return {'message':'更新计划已生成，请在环境管理中审核', 'plan':plan}


def apply_plan(data):
    h=broker(); plan=h.read_json('runtime-plan.json',None)
    if not plan or data.get('id')!=plan['id'] or time.time()-plan['created']>1800:
        raise ValueError('更新计划已过期或不匹配，请重新生成')
    if data.get('backup_ack') is not True:raise ValueError('请确认已备份业务数据并接受服务可能重启')
    installed=installed_packages()
    if installed!=plan['snapshot']:raise ValueError('系统软件包已变化，请重新生成计划')
    specs=[p+'='+v for p,v in sorted(plan['targets'].items())]
    changes=parse_simulation(h.run(['apt-get','-s','--no-remove','install']+specs,timeout=180).stdout,installed)
    guard_changes(changes)
    if changes!=plan['changes']:raise ValueError('软件源或依赖计划已变化，请重新审核')
    # Remove the authorization before mutation: a disconnected request cannot replay it.
    h.write_json('runtime-plan.json',None)
    affected=[c['name'] for c in changes]
    record={'started':time.time(),'changes':changes,'status':'running'};h.write_json('runtime-result.json',record)
    try:
        if 'nginx' in installed:h.run(['nginx','-t'])
        specs=[c['name']+'='+c['to'] for c in changes]
        h.stream(['apt-get','-y','--no-remove','-o','Dpkg::Options::=--force-confold','install']+specs,timeout=2400)
        actual=installed_packages()
        if any(actual.get(c['name'])!=c['to'] for c in changes):
            raise RuntimeError('安装后的软件包版本与审核计划不符')
        if 'redis-server' in affected and 'redis-server' not in installed:
            config=Path('/etc/redis/redis.conf')
            if config.is_symlink():raise RuntimeError('Redis 配置路径异常')
            with config.open('a') as output:
                output.write('\n# MiniPanel: local applications only\nbind 127.0.0.1 ::1\nprotected-mode yes\n')
        for v in PHP_BRANCHES:
            if any(p.startswith('php'+v+'-') for p in affected) and (Path('/etc/php')/v/'fpm').is_dir():
                if 'php'+v+'-fpm' not in installed:
                    (Path('/etc/php')/v/'fpm/conf.d/99-minipanel-upload.ini').write_text(
                        '; MiniPanel streaming uploads\nupload_max_filesize = 0\npost_max_size = 0\nmax_execution_time = 0\nmax_input_time = -1\n')
                h.run(['php-fpm'+v,'-t']);h.run(['systemctl','enable','--now','php'+v+'-fpm'])
                h.run(['systemctl','restart','php'+v+'-fpm'])
                h.run(['systemctl','is-active','--quiet','php'+v+'-fpm'])
        if any('nginx' in p for p in affected):
            h.run(['nginx','-t']);h.run(['systemctl','restart','nginx']);h.run(['systemctl','is-active','--quiet','nginx'])
        if any(p.startswith('mysql-') for p in affected) and 'mysql-community-server' in actual:
            h.run(['systemctl','restart','mysql']);h.run(h.mysql_command(),data='SELECT 1;\n')
        if any(p.startswith('redis-') for p in affected) and 'redis-server' in actual:
            h.run(['systemctl','enable','--now','redis-server']);h.run(['systemctl','restart','redis-server'])
            h.run(['systemctl','is-active','--quiet','redis-server'])
        record.update(status='success',finished=time.time(),error='')
        h.write_json('runtime-result.json',record)
        # Inventory may be refreshed without another network refresh.
        h.write_json('updates.json',{'checked':0,'error':'','packages':[], 'message':'软件包已变更，请重新检查更新'})
        return {'message':'安装/更新完成，相关服务检查通过；请验证网站业务与 SG 加密程序'}
    except Exception as error:
        record.update(status='failed',finished=time.time(),error=str(error));h.write_json('runtime-result.json',record)
        raise RuntimeError('更新未完成，可能已有部分软件包更新。未自动降级；请检查日志和服务：'+str(error)) from error


def switch_site_php(data):
    h=broker(); v=branch(data.get('php')); domain=h.domain_name(data.get('domain'))
    sites=h.read_json('sites.json',[]);site=next((s for s in sites if s['domain']==domain),None)
    if not site:raise ValueError('网站不存在')
    if not (Path('/etc/php')/v/'fpm').is_dir():raise ValueError('请先安装目标 PHP-FPM')
    h.run(['php-fpm'+v,'-t']);h.run(['systemctl','is-active','--quiet','php'+v+'-fpm'])
    target=h.php_module_status(v);current=h.php_module_status(site['php'])
    missing=[m['name'] for m in current['modules'] if m['loaded'] and not any(n['name']==m['name'] and n['loaded'] for n in target['modules'])]
    if target['error'] or missing:raise ValueError('目标 PHP 缺少当前已加载扩展或加载异常：'+(target['error'] or ', '.join(missing)))
    if v in ('7.4','8.0','8.1') and data.get('legacy_ack') is not True:raise ValueError('请确认使用已结束官方支持的 PHP 分支')
    before=(h.AVAILABLE/f'mp-{domain}.conf').read_text()
    config=h.nginx_config(domain,v,ssl=site.get('ssl',False),enabled=site['enabled'],force_https=site.get('force_https',False),root=site['root'],cert_type=site.get('cert_type','selfsigned'),rewrite=site.get('rewrite'))
    h.apply_site(domain,config,True)
    try:
        site['php']=v;h.write_json('sites.json',sites)
    except Exception:
        h.apply_site(domain,before,True);raise
    return {'message':'网站已切换到 PHP '+v+'；其他网站与原 PHP 服务保留'}


def enable_php_repository(data):
    h=broker()
    if data.get('ack') is not True:raise ValueError('请确认启用 Sury 第三方 PHP 软件源')
    release=h.os_release();suite={'12':'bookworm','13':'trixie'}.get(release.get('VERSION_ID'))
    if release.get('ID')!='debian' or not suite:raise ValueError('仅支持 Debian 12/13')
    for file in Path('/etc/apt/sources.list.d').glob('*'):
        if file.is_file() and 'packages.sury.org/php' in file.read_text(errors='replace'):
            return {'message':'已配置 Sury PHP 软件源，请检查更新刷新版本列表'}
    from urllib.request import urlopen
    import tempfile
    with tempfile.TemporaryDirectory(dir=h.STATE) as directory:
        key=Path(directory)/'keyring.deb'
        with urlopen('https://packages.sury.org/debsuryorg-archive-keyring.deb',timeout=60) as response:
            content=response.read(4*1024*1024+1)
        if len(content)>4*1024*1024:raise ValueError('签名密钥包大小异常')
        key.write_bytes(content);h.run(['dpkg','-i',str(key)])
    Path('/etc/apt/sources.list.d/minipanel-php.list').write_text(f'deb [signed-by=/usr/share/keyrings/debsuryorg-archive-keyring.gpg] https://packages.sury.org/php/ {suite} main\n')
    return check_updates()


def service_action(data):
    h=broker(); unit=data.get('service');action=data.get('operation')
    if unit not in ('nginx','mysql','redis-server') or action not in ('start','stop','restart'):
        raise ValueError('服务操作无效')
    if data.get('ack') is not True:raise ValueError('请确认服务操作可能中断网站或缓存连接')
    if unit=='nginx' and action!='stop':h.run(['nginx','-t'])
    h.run(['systemctl',action,unit])
    if action!='stop':h.run(['systemctl','is-active','--quiet',unit])
    return {'message':'服务操作完成：'+unit+' / '+action}


def migration_plan(data):
    target=data.get('target')
    if not isinstance(target,str) or not re.fullmatch(r'\d{1,2}\.\d{1,2}',target):raise ValueError('请填写目标 MySQL 系列，例如 8.4')
    h=broker();installed=installed_packages();version=installed.get('mysql-community-server')
    if not version:raise ValueError('未找到面板管理的 MySQL')
    return {'source':version,'target':target,'databases':h.read_json('databases.json',[]),
            'steps':['核对 MySQL 官方支持的升级路径，在独立服务器/实例安装目标版本。',
                     '运行 MySQL Shell Upgrade Checker 检查兼容性；保留当前实例，不替换原数据目录。',
                     '暂停业务写入，导出所有业务库，另行核对账号、授权、视图/过程/事件 DEFINER。面板只列出由其创建的库。',
                     '在独立目标实例导入，核对表/行数、字符集、账号和业务功能。',
                     '维护窗口切换业务连接，观察后再退役旧实例；回退前处理切换后新增数据。'],
            'warning':'这是迁移清单，不会自动迁移或覆盖现有 MySQL；不要把旧数据目录交给低版本 mysqld。',
            'documentation':'https://dev.mysql.com/doc/refman/8.4/en/upgrade-paths.html'}
