"""Shared validation and fixed Nginx configuration generation."""
import ipaddress
import re
import hashlib
import secrets


def domain_name(value):
    if not isinstance(value, str) or len(value) > 253:
        raise ValueError("请输入有效域名，不要包含协议、端口或路径")
    value = value.strip().lower().rstrip(".")
    try:
        value = value.encode("idna").decode("ascii")
    except UnicodeError:
        raise ValueError("域名格式不正确") from None
    if len(value) > 253 or "." not in value:
        raise ValueError("请输入完整域名，例如 example.com")
    if any(not re.fullmatch(r"[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?", p) for p in value.split(".")):
        raise ValueError("域名格式不正确")
    try:
        ipaddress.ip_address(value)
    except ValueError:
        return value
    raise ValueError("请填写域名，不是 IP 地址")


def database_name(value):
    if not isinstance(value, str) or not re.fullmatch(r"[a-z][a-z0-9_]{0,23}", value):
        raise ValueError("数据库名须以小写字母开头，只含小写字母、数字和下划线，最多 24 字符")
    return value


def nginx_config(domain, php_version, ssl=False, enabled=True, force_https=False, root=None, cert_type='selfsigned'):
    from ssl_manager import certificate_paths
    domain = domain_name(domain)
    if not re.fullmatch(r"\d+\.\d+", php_version):
        raise ValueError('PHP 版本无效')
    if force_https and not ssl:
        raise ValueError('请先启用网站 SSL，再开启强制 HTTPS')
    root = website_root(root, domain)
    cert, key = certificate_paths(domain, cert_type)
    challenge = """    location ^~ /.well-known/acme-challenge/ {
        root /var/lib/minipanel-acme-webroot;
        default_type text/plain;
        try_files $uri =404;
    }
"""
    http = '    listen 80;\n    listen [::]:80;\n'
    tls = (f'    listen 443 ssl;\n    listen [::]:443 ssl;\n    ssl_certificate {cert.as_posix()};\n    ssl_certificate_key {key.as_posix()};\n    ssl_protocols TLSv1.2 TLSv1.3;\n    ssl_session_cache shared:MiniPanelSSL:10m;\n') if ssl else ''
    redirect = ''
    if enabled and force_https:
        redirect = f'server {{\n{http}    server_name {domain};\n{challenge}    location / {{ return 308 https://{domain}$request_uri; }}\n}}\n'
        http = ''
    header = f'{redirect}server {{\n{http}{tls}    server_name {domain};\n{challenge}'
    if not enabled:
        return header + '    location / { return 503; }\n}\n'
    return header + f"""    root {root};
    index index.php index.html;
    client_max_body_size 0;
    client_body_timeout 3600s;
    access_log /var/log/nginx/mp-{domain}.access.log;
    error_log /var/log/nginx/mp-{domain}.error.log;
    location / {{ try_files $uri $uri/ /index.php?$query_string; }}
    location ~ /\\. {{ deny all; }}
    location ~* \\.(?:sql|bak|ini|log|conf|env)$ {{ deny all; }}
    location ~ \\.php$ {{
        try_files $uri =404;
        include fastcgi_params;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        fastcgi_read_timeout 3600s;
        fastcgi_send_timeout 3600s;
        fastcgi_pass unix:/run/php/php{php_version}-fpm.sock;
    }}
}}
"""


def absolute_path(value):
    from file_manager import relative_path
    if not isinstance(value, str) or not value.startswith('/'):
        raise ValueError('请输入以 / 开头的绝对目录')
    if value == '/':
        return value
    relative_path(value[1:])
    return value


def within(path, parent):
    return path == parent or path.startswith(parent + '/')


def website_root(value, domain):
    value = value or f'/var/www/minipanel/{domain_name(domain)}/public'
    value = absolute_path(value)
    # Restrict configuration syntax, without restricting the disk/mount selected.
    if not re.fullmatch(r'/[A-Za-z0-9_./-]+', value) or value == '/':
        raise ValueError('网站目录请使用绝对路径，只能包含英文字母、数字、下划线、点和短横线')
    forbidden = ('/etc', '/proc', '/sys', '/dev', '/run', '/root', '/boot', '/usr', '/bin', '/sbin', '/lib', '/lib64', '/opt/minipanel', '/var/lib', '/var/log')
    if any(within(value, p) or within(p, value) for p in forbidden):
        raise ValueError('不能将系统配置、面板或数据库目录作为公开的网站目录')
    return value


def validate_file_request(data):
    from file_manager import relative_path
    scope = data.get('scope', 'site' if data.get('domain') else 'system')
    if scope == 'site':
        data['domain'] = domain_name(data.get('domain'))
        relative_path(data.get('path', ''))
    elif scope == 'system':
        data['path'] = absolute_path(data.get('path', '/'))
    else:
        raise ValueError('文件管理范围无效')
    data['scope'] = scope
    return data


def check_system_path(path, action):
    absolute_path(path)
    if any(within(path, p) for p in ('/proc', '/sys', '/dev', '/run')):
        raise ValueError('设备和运行时虚拟目录请使用 SSH 管理')
    protected = ('/opt/minipanel', '/etc/minipanel', '/var/lib/minipanel', '/var/lib/minipanel-system', '/var/lib/minipanel-acme', '/var/lib/minipanel-acme-webroot', '/var/log/minipanel-acme', '/root/minipanel-login.txt')
    if action == 'files_delete':
        critical = ('/', '/etc', '/root', '/var', '/var/www', '/usr', '/bin', '/sbin', '/lib', '/lib64', '/boot', '/home', '/opt', '/srv', '/mnt', '/media', '/tmp')
        if path in critical or any(within(p, path) for p in protected) or any(within(path, p) for p in ('/usr', '/boot', '/bin', '/sbin', '/lib', '/lib64', '/var/lib/mysql')):
            raise ValueError('不能删除系统关键目录、面板目录或数据库数据文件')
    if action != 'files_list' and any(within(path, p) for p in protected):
        raise ValueError('面板程序、认证与内部状态文件受保护，请使用 SSH 管理')


def password_hash(password, salt):
    return hashlib.scrypt(password.encode(), salt=bytes.fromhex(salt), n=16384, r=8, p=1).hex()


def make_config(password):
    if not isinstance(password, str) or not 1 <= len(password) <= 256:
        raise ValueError('管理员密码不能为空，最多 256 个字符')
    salt = secrets.token_hex(16)
    return {'username': 'admin', 'salt': salt, 'password_hash': password_hash(password, salt)}
