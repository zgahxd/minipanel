#!/usr/bin/env bash
set -euo pipefail
export DEBIAN_FRONTEND=noninteractive
php_branch=${PHP_BRANCH:-8.2}
[[ $php_branch =~ ^(7\.4|8\.[0-5])$ ]] || exit 2
source /etc/os-release
[[ $ID == debian && $VERSION_ID =~ ^(12|13)$ ]] || exit 2
apt-get update -o APT::Update::Error-Mode=any
apt-get install -y ca-certificates curl gnupg python3
curl --fail --location --proto '=https' --tlsv1.2 https://packages.sury.org/debsuryorg-archive-keyring.deb -o /tmp/php-keyring.deb
dpkg -i /tmp/php-keyring.deb
printf 'deb [signed-by=/usr/share/keyrings/debsuryorg-archive-keyring.gpg] https://packages.sury.org/php/ %s main\n' "$VERSION_CODENAME" > /etc/apt/sources.list.d/php.list
install -d -m 0755 /etc/apt/keyrings
curl --fail --location --proto '=https' --tlsv1.2 https://repo.mysql.com/RPM-GPG-KEY-mysql-2025 -o /tmp/mysql.asc
gpg --batch --yes --dearmor --output /etc/apt/keyrings/mysql.gpg /tmp/mysql.asc
printf 'deb [arch=amd64 signed-by=/etc/apt/keyrings/mysql.gpg] https://repo.mysql.com/apt/debian/ %s mysql-8.4-lts\n' "$VERSION_CODENAME" > /etc/apt/sources.list.d/mysql.list
apt-get update -o APT::Update::Error-Mode=any
python3 -m unittest discover -s /src/minipanel/tests -q
for script in /src/minipanel/*.sh; do bash -n "$script"; done
packages=(nginx mysql-community-server redis-server redis-tools python3 gunicorn sudo openssl certbot)
for extension in fpm cli common opcache mysql curl mbstring xml zip gd redis bcmath intl; do
    [[ $php_branch == 8.5 && $extension == opcache ]] && continue
    packages+=("php${php_branch}-${extension}")
done
python3 /src/minipanel/backup-packages.py /out/packages --packages "${packages[@]}"
cd /out/packages
sha256sum -c SHA256SUMS
cd /out
tar -czf "runtime-debian${VERSION_ID}-php${php_branch}-amd64.tar.gz" packages
sha256sum runtime-*.tar.gz > SHA256SUMS
