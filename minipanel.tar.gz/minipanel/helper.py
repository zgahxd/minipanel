#!/usr/bin/python3 -I
"""Root-only broker. Explicit authenticated administrative operations; no shell commands accepted."""
import fcntl
import json
import os
from pathlib import Path
import re
import secrets
import shutil
import socket
import subprocess
import sys
import time
import urllib.request

# -I deliberately excludes cwd and PYTHONPATH; code lives in a root-owned directory.
sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import database_name, domain_name, nginx_config, website_root, validate_file_request, check_system_path, within, password_hash, make_config
from file_manager import CHUNK_SIZE, drop_privileges, open_download, operate, directory_fd, relative_path, file_name

from ssl_manager import certificate_paths, certificate_info, issue, validate_registration, panel_certificate_info

STATE = Path("/var/lib/minipanel-system")
AVAILABLE = Path("/etc/nginx/sites-available")
ENABLED = Path("/etc/nginx/sites-enabled")
WEB = Path("/var/www/minipanel")
ENV = {"PATH": "/usr/sbin:/usr/bin:/sbin:/bin", "LANG": "C.UTF-8", "DEBIAN_FRONTEND": "noninteractive"}


def run(args, *, timeout=120, check=True, data=None):
    result = subprocess.run(args, input=data, text=True, capture_output=True, env=ENV, timeout=timeout)
    if check and result.returncode:
        raise RuntimeError((result.stderr or result.stdout or "命令执行失败")[-4000:])
    return result


def event(message):
    print(json.dumps({"log": message}, ensure_ascii=False), flush=True)


def stream(args, timeout=1800):
    # Temp file avoids pipe deadlocks and caps memory used by package-manager output.
    import tempfile
    with tempfile.TemporaryDirectory(prefix="minipanel-") as directory, open(Path(directory) / "output", "w", encoding="utf-8") as writer, open(Path(directory) / "output", encoding="utf-8", errors="replace") as output:
        proc = subprocess.Popen(args, stdout=writer, stderr=subprocess.STDOUT, env=ENV)
        start, offset = time.monotonic(), 0
        try:
            while True:
                time.sleep(0.3)
                output.seek(offset)
                chunk = output.read(16000)
                offset = output.tell()
                if chunk:
                    event(chunk)
                if proc.poll() is not None and not chunk:
                    break
                if time.monotonic() - start > timeout:
                    raise RuntimeError("操作超时，请检查网络和软件源后重试")
            if proc.returncode:
                raise RuntimeError("安装命令失败，详情见上方日志")
        finally:
            if proc.poll() is None:
                proc.kill()
                proc.wait()


def read_json(name, default):
    file = STATE / name
    return json.loads(file.read_text()) if file.exists() else default


def write_json(name, data):
    target = STATE / name
    temp = target.with_suffix(".tmp")
    temp.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n")
    temp.chmod(0o600)
    temp.replace(target)


def php_version():
    versions = [p.name for p in Path("/etc/php").glob("*") if re.fullmatch(r"\d+\.\d+", p.name) and (p / "fpm").is_dir()]
    if not versions:
        raise RuntimeError("尚未安装 PHP-FPM，请先安装运行环境")
    return max(versions, key=lambda x: tuple(map(int, x.split("."))))


def mysql_command():
    if not (STATE / "mysql-managed").exists():
        raise ValueError("请先通过本面板安装 MySQL")
    return ["mysql", "--no-defaults", "--protocol=socket", "--socket=/run/mysqld/mysqld.sock", "-uroot", "--batch", "--skip-column-names"]


def status(_):
    services = []
    for name, binary, unit in [("Nginx", "nginx", "nginx"), ("PHP", "php", None)]:
        installed = bool(shutil.which(binary, path=ENV["PATH"]))
        version = "未安装"
        if installed:
            result = run([binary, "-v"], check=False)
            version = (result.stdout or result.stderr).splitlines()[0][:130]
        if name == "PHP":
            try:
                unit = f"php{php_version()}-fpm"
            except RuntimeError:
                installed = False
        active = installed and unit and run(["systemctl", "is-active", unit], check=False).stdout.strip() == "active"
        services.append({"name": name, "installed": installed, "running": bool(active), "version": version})
    installed = bool(shutil.which("mysqld", path=ENV["PATH"]))
    version = run(["mysqld", "--version"], check=False).stdout.strip() if installed else "未安装"
    ready = installed and run(["systemctl", "is-active", "mysql"], check=False).stdout.strip() == "active"
    services.append({"name": "MySQL", "installed": installed, "running": ready, "version": version})
    sites = read_json('sites.json', [])
    for site in sites:
        if site.get('ssl'):
            site['certificate_info'] = certificate_info(site['domain'], site.get('cert_type','selfsigned'), run)
    renewal = read_json('renewal.json', {})
    renewal['timer_active'] = run(['systemctl','is-active','minipanel-renew.timer'],check=False).stdout.strip() == 'active'
    disk = shutil.disk_usage("/")
    panel_tls = panel_certificate_info(run)
    panel_tls['renewal'] = read_json('panel-renewal.json', {})
    return {"services": services, "sites": sites, "renewal": renewal, "panel_certificate": panel_tls, "databases": read_json("databases.json", []),
            "hostname": socket.gethostname(), "os": "Debian " + os_release().get("VERSION_ID", ""),
            "disk": {"used": disk.used, "total": disk.total}, "load": os.getloadavg()[0], "demo": False}


def os_release():
    return dict(line.split("=", 1) for line in Path("/etc/os-release").read_text().replace('"', "").splitlines() if "=" in line)


def install_stack(_):
    release = os_release()
    if release.get("ID") != "debian" or release.get("VERSION_ID") not in ("12", "13"):
        raise RuntimeError("当前仅支持 Debian 12 / 13")
    if run(["dpkg", "--print-architecture"]).stdout.strip() != "amd64":
        raise RuntimeError("此版 MySQL 官方源安装方案仅支持 amd64 / x86_64")
    marker = STATE / "mysql-managed"
    if not marker.exists():
        package = run(["dpkg-query", "-W", "-f=${db:Status-Status}", "mariadb-server", "mysql-community-server", "mysql-server"], check=False)
        data_dir = Path("/var/lib/mysql")
        if "installed" in package.stdout or (data_dir.exists() and any(data_dir.iterdir())):
            raise RuntimeError("发现已有 MySQL/MariaDB，未覆盖。此版请在未安装数据库的 Debian 上使用")
        with socket.socket() as sock:
            try:
                sock.bind(("127.0.0.1", 3306))
            except OSError:
                raise RuntimeError("3306 端口已占用，未修改已有数据库") from None
        for file in Path("/etc/apt/sources.list.d").glob("*"):
            if file.is_file() and file.name != "minipanel-mysql.list" and "repo.mysql.com" in file.read_text(errors="replace"):
                raise RuntimeError("发现已有 MySQL 软件源，请先检查它，避免重复配置")
    event("更新 Debian 软件源索引…")
    stream(["apt-get", "update"])
    event("原生安装 Nginx、PHP-FPM 及 PHP 扩展…")
    stream(["apt-get", "install", "-y", "--no-upgrade", "ca-certificates", "gnupg", "nginx", "php-fpm", "php-cli", "php-mysql", "php-curl", "php-mbstring", "php-xml", "php-zip", "php-gd"])
    event("配置 MySQL 官方 8.4 LTS 软件源及独立签名密钥…")
    key = STATE / "mysql-signing-key.asc"
    with urllib.request.urlopen("https://repo.mysql.com/RPM-GPG-KEY-mysql-2025", timeout=60) as response:
        key.write_bytes(response.read(65536))
    keyring = Path("/etc/apt/keyrings/minipanel-mysql.gpg")
    keyring.parent.mkdir(mode=0o755, exist_ok=True)
    run(["gpg", "--batch", "--yes", "--dearmor", "--output", str(keyring), str(key)])
    keyring.chmod(0o644)
    suite = {"12": "bookworm", "13": "trixie"}[release["VERSION_ID"]]
    Path("/etc/apt/sources.list.d/minipanel-mysql.list").write_text(f"deb [arch=amd64 signed-by={keyring}] https://repo.mysql.com/apt/debian/ {suite} mysql-8.4-lts\n")
    stream(["apt-get", "update"])
    candidate = run(["apt-cache", "policy", "mysql-community-server"]).stdout
    if not re.search(r"Candidate:\s+8\.4\.", candidate):
        raise RuntimeError("未找到 MySQL 8.4 候选包，停止安装，请检查官方源日志")
    settings = Path("/etc/mysql/mysql.conf.d")
    settings.mkdir(parents=True, exist_ok=True, mode=0o755)
    (settings / "zz-minipanel.cnf").write_text("[mysqld]\nbind-address = 127.0.0.1\nmysqlx-bind-address = 127.0.0.1\n")
    # Empty root password selects Debian/Oracle's auth_socket; no reusable root password is exposed.
    run(["debconf-set-selections"], data="mysql-community-server mysql-community-server/root-pass password\nmysql-community-server mysql-community-server/re-root-pass password\n")
    marker.touch(mode=0o600)
    event("原生安装 MySQL 8.4（systemd 服务：mysql）…")
    stream(["apt-get", "install", "-y", "--no-upgrade", "mysql-community-server"])
    for unit in ["nginx", f"php{php_version()}-fpm", "mysql"]:
        run(["systemctl", "enable", "--now", unit])
    # PHP 8.2/8.4 treat upload_max_filesize=0 as no file-size cap.
    # Keep a finite memory limit: file uploads are spooled to disk, not held in RAM.
    php_ini = Path('/etc/php') / php_version() / 'fpm/conf.d/99-minipanel-upload.ini'
    php_ini.write_text('; MiniPanel: streaming cloud-storage uploads\nupload_max_filesize = 0\npost_max_size = 0\nmax_execution_time = 0\nmax_input_time = -1\n')
    run(['systemctl', 'reload', f'php{php_version()}-fpm'])
    # Apply local binding even after an interrupted previous installation.
    run(["systemctl", "restart", "mysql"])
    run(mysql_command(), data="SELECT 1;\n")
    event("Nginx、PHP、MySQL 已在 Debian 系统中安装并启动")
    return {"message": "运行环境安装完成"}


def apply_site(domain, config, enabled):
    file = AVAILABLE / f"mp-{domain}.conf"
    link = ENABLED / file.name
    if file.is_symlink() or (link.exists() and not link.is_symlink()):
        raise RuntimeError("配置文件类型异常，停止操作")
    old = file.read_text() if file.exists() else None
    old_link = os.readlink(link) if link.is_symlink() else None
    try:
        file.write_text(config)
        file.chmod(0o644)
        if link.is_symlink():
            link.unlink()
        if enabled:
            link.symlink_to(file)
        run(["nginx", "-t"])
        run(["systemctl", "reload", "nginx"])
    except Exception:
        if link.is_symlink():
            link.unlink()
        if old is None:
            file.unlink(missing_ok=True)
        else:
            file.write_text(old)
        if old_link is not None:
            link.symlink_to(old_link)
        run(["systemctl", "reload", "nginx"], check=False)
        raise


def create_site(data):
    domain = domain_name(data.get("domain"))
    sites = read_json("sites.json", [])
    if any(x["domain"] == domain for x in sites) or (AVAILABLE / f"mp-{domain}.conf").exists():
        raise ValueError("该域名已经添加")
    # Check active custom configs to avoid silent conflicting server_name entries.
    conf = run(["nginx", "-T"]).stdout
    for names in re.findall(r"\bserver_name\s+([^;]+);", conf):
        if domain in names.split():
            raise ValueError("其他 Nginx 配置已使用该域名")
    version = php_version()
    public = prepare_root(website_root(data.get('root'), domain))
    apply_site(domain, nginx_config(domain, version, root=public), True)
    site = {"domain": domain, "root": str(public), "enabled": True, "php": version, "ssl": False, "force_https": False, "created": time.strftime("%Y-%m-%d %H:%M")}
    sites.append(site)
    write_json("sites.json", sites)
    return {"message": "网站已创建，请将域名 A 记录解析到服务器公网 IP", "site": site}


def toggle_site(data):
    domain = domain_name(data.get("domain"))
    enabled = data.get("enabled")
    if type(enabled) is not bool:
        raise ValueError("网站状态无效")
    sites = read_json("sites.json", [])
    site = next((x for x in sites if x["domain"] == domain), None)
    if site is None:
        raise ValueError("网站不存在")
    # Disabled sites remain explicit vhosts, preventing fallback to another site's content.
    config = nginx_config(domain, site["php"], ssl=site.get('ssl', False), enabled=enabled, force_https=site.get('force_https', False), root=site.get('root'), cert_type=site.get('cert_type', 'selfsigned'))
    apply_site(domain, config, True)
    site["enabled"] = enabled
    write_json("sites.json", sites)
    return {"message": "网站已启用" if enabled else "网站已暂停（HTTP 503）"}


def configure_ssl(data):
    domain = domain_name(data.get('domain'))
    enabled, force_https = data.get('ssl'), data.get('force_https')
    if type(enabled) is not bool or type(force_https) is not bool:
        raise ValueError('SSL 设置格式无效')
    if force_https and not enabled:
        raise ValueError('请先启用网站 SSL，再开启强制 HTTPS')
    sites = read_json('sites.json', [])
    site = next((s for s in sites if s['domain'] == domain), None)
    if not site:
        raise ValueError('网站不存在')
    kind = data.get('cert_type', site.get('cert_type', 'selfsigned'))
    cert, key = certificate_paths(domain, kind)
    certificate = site.get('certificate')
    if enabled and kind == 'letsencrypt':
        from ssl_manager import WEBROOT
        old_file = AVAILABLE / f'mp-{domain}.conf'
        old_config = old_file.read_text()
        registration = dict(data)
        if site.get('acme_agreed'):
            registration.update(email=data.get('email') or site.get('acme_email'), agree_tos=True)
        if not cert.exists() or run(['openssl','x509','-in',str(cert),'-noout','-checkend','0'],check=False).returncode:
            validate_registration(registration)
            WEBROOT.mkdir(parents=True, exist_ok=True, mode=0o755)
            # Add a webroot challenge route while keeping the current certificate.
            apply_site(domain, nginx_config(domain, site['php'], ssl=site.get('ssl', False), enabled=site['enabled'], force_https=site.get('force_https', False), root=site.get('root'), cert_type=site.get('cert_type','selfsigned')), True)
            try:
                event('正在验证域名并申请 Let’s Encrypt 证书…')
                issue(domain, registration, run)
            except Exception:
                apply_site(domain, old_config, True)
                raise
        try:
            run(['openssl', 'x509', '-in', str(cert), '-noout', '-checkend', '0'])
            run(['systemctl', 'enable', '--now', 'minipanel-renew.timer'])
            config = nginx_config(domain, site['php'], ssl=True, enabled=site['enabled'], force_https=force_https, root=site.get('root'), cert_type=kind)
            apply_site(domain, config, True)
        except Exception:
            apply_site(domain, old_config, True)
            raise
        site.update(acme_email=registration.get('email') or site.get('acme_email'), acme_agreed=True)
    else:
        if enabled:
            cert.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
            if not key.exists() or not cert.exists():
                run(['openssl', 'req', '-x509', '-newkey', 'rsa:3072', '-sha256', '-nodes', '-days', '365', '-keyout', str(key), '-out', str(cert), '-subj', f'/CN={domain}', '-addext', f'subjectAltName=DNS:{domain}'])
                key.chmod(0o600); cert.chmod(0o644)
        apply_site(domain, nginx_config(domain, site['php'], ssl=enabled, enabled=site['enabled'], force_https=force_https, root=site.get('root'), cert_type=kind), True)
    if enabled:
        certificate = run(['openssl', 'x509', '-in', str(cert), '-noout', '-enddate', '-issuer', '-fingerprint', '-sha256']).stdout.strip()
    site.update(ssl=enabled, force_https=force_https, certificate=certificate, cert_type=kind)
    write_json('sites.json', sites)
    return {'message': '域名证书设置已保存' + ('，已启用自动续期' if enabled and kind == 'letsencrypt' else ''), 'site': site}


def renew_certificates(_):
    from ssl_manager import renewal_check
    event('正在检查到期证书；未到续期窗口的证书不会重复签发…')
    result = renewal_check(run, read_json, write_json)
    if result.get('error'):
        raise RuntimeError(result['error'])
    return {'message': result['message']}


def prepare_root(path):
    import pwd
    account = pwd.getpwnam('www-data')
    flags = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW
    fd = os.open('/', flags)
    try:
        for part in relative_path(path.lstrip('/')):
            created = False
            try:
                os.mkdir(part, 0o755, dir_fd=fd)
                created = True
            except FileExistsError:
                pass
            child = os.open(part, flags, dir_fd=fd)
            os.close(fd); fd = child
            if created:
                os.fchown(fd, account.pw_uid, account.pw_gid)
        if created:
            index = os.open('index.html', os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o644, dir_fd=fd)
            with os.fdopen(index, 'w', encoding='utf-8') as output:
                os.fchown(output.fileno(), account.pw_uid, account.pw_gid)
                output.write('<!doctype html><meta charset="utf-8"><title>MiniPanel</title><h1>网站已创建</h1><p>请在文件管理中上传网站程序。</p>')
        # Existing website contents and permissions are never overwritten.
        # Failure leaves only newly created empty directories for inspection.
    finally:
        os.close(fd)
    for mode in ('-r', '-x'):
        if run(['runuser', '-u', 'www-data', '--', 'test', mode, path], check=False).returncode:
            raise ValueError('www-data 无法读取或进入网站目录，请通过 SSH 检查目录及上级目录权限')
    return path


def site_root(data):
    domain = domain_name(data.get('domain'))
    sites = read_json('sites.json', [])
    site = next((s for s in sites if s['domain'] == domain), None)
    if not site:
        raise ValueError('网站不存在')
    root = prepare_root(website_root(data.get('root'), domain))
    config = nginx_config(domain, site['php'], ssl=site.get('ssl', False), enabled=site['enabled'], force_https=site.get('force_https', False), root=root, cert_type=site.get('cert_type', 'selfsigned'))
    apply_site(domain, config, True)
    site['root'] = root
    write_json('sites.json', sites)
    return {'message': '网站目录已修改；原目录文件保留，不会自动搬移'}


def change_password(data):
    import hmac
    import grp
    import tempfile
    auth = Path('/etc/minipanel/auth.json')
    current = json.loads(auth.read_text())
    old = data.get('old_password')
    if not isinstance(old, str) or len(old) > 256 or not hmac.compare_digest(password_hash(old, current['salt']), current['password_hash']):
        raise ValueError('原密码不正确')
    config = make_config(data.get('new_password'))
    fd, temp = tempfile.mkstemp(prefix='.auth-', dir=auth.parent)
    try:
        with os.fdopen(fd, 'w') as output:
            json.dump(config, output)
            output.flush(); os.fsync(output.fileno())
            os.fchown(output.fileno(), 0, grp.getgrnam('minipanel').gr_gid)
            os.fchmod(output.fileno(), 0o640)
        os.replace(temp, auth)
    finally:
        if os.path.exists(temp):
            os.unlink(temp)
    # Only the authenticated WSGI process receives the new hash over the local pipe.
    return {'config': config}


def initial_credentials(_):
    import hmac
    result = {'username': 'admin'}
    try:
        saved = Path('/root/minipanel-login.txt').read_text(encoding='utf-8')
        current = json.loads(Path('/etc/minipanel/auth.json').read_text(encoding='utf-8'))
    except FileNotFoundError:
        return dict(result, message='没有保存初始密码，请使用当前密码；忘记密码可通过 SSH 重置')
    password = next((line[len('密码：'):] for line in saved.splitlines() if line.startswith('密码：')), None)
    if password and len(password) <= 256 and hmac.compare_digest(password_hash(password, current['salt']), current['password_hash']):
        return dict(result, password=password, message='安装时生成的初始密码（仍有效）')
    return dict(result, message='初始密码已失效，请使用你设置的密码登录；自定义密码不以明文保存或显示')


def manage_files(data):
    validate_file_request(data)
    sites = read_json('sites.json', [])
    if data['scope'] == 'site':
        site = next((s for s in sites if s['domain'] == data['domain']), None)
        if not site:
            raise ValueError('网站不存在')
        base = website_root(site.get('root'), site['domain'])
        absolute = base + ('/' + data['path'] if data.get('path') else '')
    else:
        base, absolute = '/', data['path']
    action = data['action']
    check_system_path(absolute, 'files_list' if action == 'files_delete' else action)
    for key in ('name', 'destination'):
        if data.get(key):
            check_system_path(absolute.rstrip('/') + '/' + file_name(data[key]), action)
    if action == 'files_delete':
        target = absolute.rstrip('/') + '/' + file_name(data.get('name'))
        if any(within(website_root(s.get('root'), s['domain']), target) for s in sites):
            raise ValueError('不能删除网站根目录或其上级目录；请进入目录管理里面的文件')
    # Website operations retain www-data ownership. Other system paths use the
    # explicitly requested administrator scope, with no symlink traversal.
    if any(within(absolute, website_root(s.get('root'), s['domain'])) for s in sites):
        drop_privileges()
    if action == 'files_copy':
        from common import absolute_path
        from file_manager import copy_path
        source = absolute_path(data.get('source'))
        target = absolute.rstrip('/') + '/' + file_name(data.get('name'))
        return copy_path(source, target, check_system_path)
    request = dict(data, path=absolute.lstrip('/'))
    if action == 'files_download':
        return open_download('/', request)
    result = operate('/', action, request)
    if action == 'files_list':
        result.update(path=data.get('path', ''), root=base)
    if action == 'files_extract':
        result['path'] = '/'.join(filter(None, [data.get('path', '').rstrip('/'), data['destination']]))
        if data['scope'] == 'system' and not result['path'].startswith('/'):
            result['path'] = '/' + result['path']
    return result


def restart_service(data):
    name = data.get("service")
    if name == "Nginx":
        run(["nginx", "-t"])
        run(["systemctl", "restart", "nginx"])
    elif name == "PHP":
        run(["systemctl", "restart", f"php{php_version()}-fpm"])
    elif name == "MySQL":
        mysql_command()
        run(["systemctl", "restart", "mysql"])
    else:
        raise ValueError("不支持的服务")
    return {"message": f"{name} 已重启"}


def create_database(data):
    name = database_name(data.get("name"))
    databases = read_json("databases.json", [])
    if any(x["name"] == name for x in databases):
        raise ValueError("数据库已经存在")
    password = secrets.token_hex(16)
    command = mysql_command()
    existing = run(command, data=f"SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME='{name}'; SELECT User FROM mysql.user WHERE User='{name}';\n").stdout.strip()
    if existing:
        raise ValueError("MySQL 中已存在同名数据库或账号，未修改")
    run(command, data=f"CREATE DATABASE `{name}` CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;\n")
    try:
        run(command, data=f"CREATE USER '{name}'@'localhost' IDENTIFIED BY '{password}';\n")
    except Exception:
        run(command, data=f"DROP DATABASE `{name}`;\n", check=False)
        raise
    try:
        # MySQL interprets '_' as a database wildcard in GRANT even inside backticks.
        grant_name = name.replace("_", "\\_")
        run(command, data=f"GRANT ALL PRIVILEGES ON `{grant_name}`.* TO '{name}'@'localhost';\n")
    except Exception:
        run(command, data=f"DROP USER '{name}'@'localhost'; DROP DATABASE `{name}`;\n", check=False)
        raise
    database = {"name": name, "username": name, "host": "127.0.0.1", "port": 3306}
    databases.append(database)
    write_json("databases.json", databases)
    return {"message": "数据库已创建，请立即保存密码，关闭后不再显示", "database": database, "password": password}


def main():
    os.umask(0o022)
    if os.geteuid() != 0:
        raise RuntimeError("系统助手必须由 root 运行")
    if len(sys.argv) != 1:
        raise ValueError("不接受命令行参数")
    STATE.mkdir(mode=0o700, exist_ok=True)
    raw = sys.stdin.buffer.readline(8193)
    if len(raw) > 8192:
        raise ValueError('请求体过大')
    request = json.loads(raw)
    if not isinstance(request, dict):
        raise ValueError("请求格式无效")
    action = request.get("action")
    if action == 'files_upload':
        request['_stream'] = sys.stdin.buffer
    handlers = {"status": status, "install": install_stack, "create_site": create_site, "toggle_site": toggle_site,
                "restart": restart_service, "create_database": create_database, 'configure_ssl': configure_ssl,
                'files_list': manage_files, 'files_upload': manage_files, 'files_download': manage_files, 'files_mkdir': manage_files, 'files_extract': manage_files, 'files_create': manage_files, 'files_delete': manage_files, 'files_copy': manage_files, 'site_root': site_root, 'change_password': change_password, 'initial_credentials': initial_credentials, 'renew_certificates': renew_certificates}
    if action not in handlers:
        raise ValueError("不支持的操作")
    with (STATE / "operation.lock").open("a") as lock:
        if action not in {'status', 'files_list', 'files_download', 'initial_credentials'}:
            try:
                fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError:
                raise RuntimeError("已有系统操作正在进行，请稍后重试") from None
        result = handlers[action](request)
        if action == 'files_download':
            file, size = result
            with file:
                print(json.dumps({'stream': {'size': size, 'name': request['name']}}), flush=True)
                remaining = size
                try:
                    while remaining:
                        chunk = file.read(min(CHUNK_SIZE, remaining))
                        if not chunk:
                            break
                        sys.stdout.buffer.write(chunk)
                        remaining -= len(chunk)
                    sys.stdout.buffer.flush()
                except (BrokenPipeError, OSError):
                    # Never append JSON error messages to a binary response.
                    return
            return
    print(json.dumps({"result": result}, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print(json.dumps({"error": str(error)}, ensure_ascii=False), flush=True)
        sys.exit(1)
