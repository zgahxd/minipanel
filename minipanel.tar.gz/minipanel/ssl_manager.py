"""Certbot webroot integration. All paths and executable arguments are fixed."""
from datetime import datetime, timezone
from pathlib import Path
import re
import time
import ipaddress
import os
import tempfile

from common import domain_name

ACME = Path('/etc/minipanel/acme')
WEBROOT = Path('/var/lib/minipanel-acme-webroot')
WORK = Path('/var/lib/minipanel-acme')
LOGS = Path('/var/log/minipanel-acme')
PANEL_CERT = Path('/etc/minipanel/tls.crt')
PANEL_KEY = Path('/etc/minipanel/tls.key')


def certificate_paths(domain, kind):
    domain = domain_name(domain)
    if kind == 'letsencrypt':
        return ACME / 'live' / domain / 'fullchain.pem', ACME / 'live' / domain / 'privkey.pem'
    if kind != 'selfsigned':
        raise ValueError('不支持的证书类型')
    base = Path('/etc/minipanel/sites-ssl') / domain
    return base / 'cert.pem', base / 'key.pem'


def certbot_command():
    return ['/usr/bin/certbot', '--config-dir', str(ACME), '--work-dir', str(WORK), '--logs-dir', str(LOGS)]


def validate_registration(data):
    email = data.get('email', '')
    if not isinstance(email, str) or len(email) > 254 or not re.fullmatch(r'[A-Za-z0-9.!#$%&\x27*+/=?^_`{|}~-]+@[A-Za-z0-9](?:[A-Za-z0-9.-]*[A-Za-z0-9])?\.[A-Za-z]{2,63}', email):
        raise ValueError('申请证书需要有效邮箱地址')
    if data.get('agree_tos') is not True:
        raise ValueError('请阅读并同意 Let’s Encrypt 服务协议后申请')
    return email


def issue(domain, data, run):
    email = validate_registration(data)
    for folder in (ACME, WORK, LOGS):
        folder.mkdir(parents=True, exist_ok=True, mode=0o700)
    WEBROOT.mkdir(parents=True, exist_ok=True, mode=0o755)
    result = run(certbot_command() + ['certonly', '--webroot', '--webroot-path', str(WEBROOT),
        '--cert-name', domain_name(domain), '-d', domain, '--email', email, '--agree-tos',
        '--non-interactive', '--keep-until-expiring', '--server', 'https://acme-v02.api.letsencrypt.org/directory'], timeout=240, check=False)
    if result.returncode:
        detail = (result.stderr or result.stdout or 'CA 未签发证书')[-3000:]
        raise RuntimeError('证书申请失败，请检查域名 A/AAAA 解析和公网 80 端口。\n' + detail)


def certificate_info(domain, kind, run):
    cert, _ = certificate_paths(domain, kind)
    return read_certificate(cert, kind, run)


def read_certificate(cert, kind, run):
    if not cert.exists():
        return {'type': kind, 'error': '证书文件不存在'}
    result = run(['openssl', 'x509', '-in', str(cert), '-noout', '-enddate', '-issuer', '-fingerprint', '-sha256'], check=False)
    if result.returncode:
        return {'type': kind, 'error': '无法读取证书'}
    values = dict(line.split('=', 1) for line in result.stdout.splitlines() if '=' in line)
    try:
        expires = datetime.strptime(values['notAfter'], '%b %d %H:%M:%S %Y %Z').replace(tzinfo=timezone.utc).timestamp()
    except (KeyError, ValueError):
        return {'type': kind, 'error': '证书日期无法解析'}
    return {'type': kind, 'expires': expires, 'days_remaining': int((expires-time.time()) // 86400),
            'issuer': values.get('issuer', ''), 'fingerprint': values.get('sha256 Fingerprint', values.get('SHA256 Fingerprint',''))}


def managed_panel_certificate(run):
    if not PANEL_CERT.exists():
        return False
    identity = run(['openssl', 'x509', '-in', str(PANEL_CERT), '-noout', '-subject', '-issuer', '-nameopt', 'RFC2253'], check=False)
    values = dict(line.split('=', 1) for line in identity.stdout.splitlines() if '=' in line)
    if identity.returncode or values.get('subject', '').strip() != 'CN=MiniPanel' or values.get('issuer', '').strip() != 'CN=MiniPanel':
        return False
    return run(['openssl', 'verify', '-check_ss_sig', '-no_check_time', '-CAfile', str(PANEL_CERT), str(PANEL_CERT)], check=False).returncode == 0


def panel_certificate_info(run):
    info = read_certificate(PANEL_CERT, 'panel', run)
    info['auto_renew'] = managed_panel_certificate(run)
    return info


def renew_panel_certificate(run, read_state, write_state):
    """Run outside the panel service; renew only MiniPanel self-signed certificates."""
    record = dict(read_state('panel-renewal.json', {}), last_check=time.time(), error='')
    temporary = None
    try:
        if not managed_panel_certificate(run):
            record.update(message='外部证书或证书不可识别，未自动替换', auto_renew=False)
        else:
            record['auto_renew'] = True
            if record.get('deployment_pending'):
                run(['systemctl', 'reload', 'minipanel'])
                record.update(deployment_pending=False, last_deployed=time.time())
            due = run(['openssl', 'x509', '-in', str(PANEL_CERT), '-noout', '-checkend', str(30 * 86400)], check=False)
            if due.returncode == 0:
                record['message'] = '后台自签名证书剩余超过 30 天，暂不换新'
            else:
                extension = run(['openssl', 'x509', '-in', str(PANEL_CERT), '-noout', '-ext', 'subjectAltName'])
                names = []
                for item in extension.stdout.split('\n', 1)[-1].strip().split(','):
                    item = item.strip()
                    if item.startswith('DNS:') and re.fullmatch(r'[A-Za-z0-9*.-]+', item[4:]):
                        names.append(item)
                    elif item.startswith('IP Address:'):
                        names.append('IP:' + str(ipaddress.ip_address(item[11:])))
                    elif item:
                        raise RuntimeError('证书 SAN 包含不支持的名称，保留原证书')
                if not names:
                    raise RuntimeError('证书 SAN 缺失，保留原证书')
                previous = PANEL_CERT.read_bytes()
                fd, filename = tempfile.mkstemp(prefix='.tls-renew-', suffix='.crt', dir=PANEL_CERT.parent)
                os.close(fd)
                temporary = Path(filename)
                # Reuse the protected key so one atomic certificate replacement is sufficient.
                run(['openssl', 'req', '-new', '-x509', '-sha256', '-key', str(PANEL_KEY), '-days', '365',
                     '-subj', '/CN=MiniPanel', '-addext', 'subjectAltName=' + ','.join(names), '-out', str(temporary)])
                run(['openssl', 'x509', '-in', str(temporary), '-noout', '-checkend', str(30 * 86400)])
                os.chmod(temporary, 0o644)
                record['deployment_pending'] = True
                write_state('panel-renewal.json', record)
                os.replace(temporary, PANEL_CERT)
                try:
                    run(['systemctl', 'reload', 'minipanel'])
                except Exception:
                    # Restore the certificate atomically if the reload command failed.
                    temporary.write_bytes(previous)
                    os.chmod(temporary, 0o644)
                    os.replace(temporary, PANEL_CERT)
                    run(['systemctl', 'reload', 'minipanel'])
                    record['deployment_pending'] = False
                    raise
                record.update(last_renewed=time.time(), last_deployed=time.time(), deployment_pending=False,
                              message='后台自签名证书已换新，有效期 365 天；浏览器仍会提示不受信任')
    except Exception as error:
        record.update(error=str(error), message='后台证书换新或加载失败，下次定时检查会重试')
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)
    write_state('panel-renewal.json', record)
    return record


def renewal_check(run, read_state, write_state, include_panel=False):
    """Caller holds the shared broker lock; retry failed deployments next check."""
    prior = read_state('renewal.json', {})
    record = dict(prior, last_check=time.time(), error='')
    certificates = sorted((ACME / 'live').glob('*/fullchain.pem'))
    if include_panel:
        panel = renew_panel_certificate(run, read_state, write_state)
        record['panel_error'] = panel.get('error', '')
    if not certificates:
        record.update(message='尚无 Let’s Encrypt 证书', deployment_pending=False)
        write_state('renewal.json', record)
        return record
    try:
        before = {str(p): p.read_bytes() for p in certificates}
        result = run(certbot_command() + ['renew', '--quiet', '--non-interactive', '--no-random-sleep-on-renew'], timeout=1800, check=False)
        changed = any(p.read_bytes() != before[str(p)] for p in certificates)
        if changed:
            record.update(last_renewed=time.time(), deployment_pending=True)
            write_state('renewal.json', record)
        if changed or record.get('deployment_pending'):
            run(['nginx', '-t'])
            run(['systemctl', 'reload', 'nginx'])
            record.update(last_deployed=time.time(), deployment_pending=False)
        if result.returncode:
            raise RuntimeError((result.stderr or result.stdout or '证书续期失败')[-3000:])
        record.update(last_success=time.time(), message='续期检查成功；到续期窗口时自动更新')
    except Exception as error:
        # If a timed-out Certbot updated certificates, retry nginx deployment too.
        record.update(error=str(error), deployment_pending=True, message='续期检查或部署失败，下次定时检查会重试')
    write_state('renewal.json', record)
    return record
