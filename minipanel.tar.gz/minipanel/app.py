"""MiniPanel WSGI application. Production: Gunicorn HTTPS on the Debian host."""
import argparse
import io
from collections import deque
import hashlib
import hmac
from http.cookies import SimpleCookie
import json
import mimetypes
import os
from pathlib import Path
import secrets
import re
import subprocess
import threading
import tempfile
import time
from urllib.parse import parse_qs, quote

from common import database_name, domain_name, website_root, validate_file_request, check_system_path, make_config, password_hash, within, absolute_path, rewrite_rules
from file_manager import CHUNK_SIZE, ARCHIVE_TIMEOUT, archive_members, copy_archive_member, copy_upload, file_name, relative_path, compression_request, write_compressed

BASE = Path(__file__).resolve().parent


class APIError(Exception):
    def __init__(self, status, message):
        self.status, self.message = status, message


class FileStream:
    def __init__(self, chunks, size, name):
        self.chunks, self.size, self.name = chunks, size, name


class DemoBackend:
    def __init__(self, initial_password=None):
        self.initial_password = initial_password
        self.password_changed = False
        self.installed = False
        self.sites, self.databases = [], []
        self.sql_dumps = {}
        self.files = {'': {}}
        self.directories = {'': {'', 'etc', 'root', 'var', 'var/www', 'var/www/minipanel', 'srv', 'opt', 'tmp', 'home', 'mnt'}}
        self.io_lock = threading.Lock()

    def file_context(self, data, action):
        validate_file_request(data)
        if data['scope'] == 'site':
            site = next((s for s in self.sites if s['domain'] == data['domain']), None)
            if not site:
                raise ValueError('网站不存在')
            base = site['root']
            absolute = base + ('/' + data['path'] if data.get('path') else '')
        else:
            base, absolute = '/', data['path']
        check_system_path(absolute, 'files_list' if action == 'files_delete' else action)
        for key in ('name', 'destination'):
            if data.get(key):
                check_system_path(absolute.rstrip('/') + '/' + file_name(data[key]), action)
        if action == 'files_delete':
            target = absolute.rstrip('/') + '/' + file_name(data.get('name'))
            if any(within(s['root'], target) for s in self.sites):
                raise ValueError('不能删除网站根目录或其上级目录')
        return '', absolute.lstrip('/'), base

    def upload(self, data, source, size):
        domain, path, _ = self.file_context(data, 'files_upload')
        name = data['name']
        if domain not in self.files or path not in self.directories[domain]:
            raise ValueError('网站或目录不存在')
        key = (path+'/' if path else '') + name
        if key in self.directories[domain] or (key in self.files[domain] and not data.get('overwrite')):
            raise ValueError('同名文件或目录已存在')
        file = tempfile.TemporaryFile()
        try:
            copy_upload(source, file, size)
            file.flush()
            self.files[domain][key] = file
        except Exception:
            file.close()
            raise
        return {'message':'演示文件已上传'}

    def download(self, data):
        domain, path, _ = self.file_context(data, 'files_download')
        name = data['name']
        key = (path+'/' if path else '') + name
        if domain not in self.files or key not in self.files[domain]:
            raise ValueError('文件不存在')
        file = self.files[domain][key]
        size = len(file) if isinstance(file, bytes) else os.fstat(file.fileno()).st_size
        def chunks():
            position = 0
            while position < size:
                if isinstance(file, bytes):
                    chunk = file[position:position+CHUNK_SIZE]
                else:
                    with self.io_lock:
                        file.seek(position)
                        chunk = file.read(min(CHUNK_SIZE, size-position))
                if not chunk:
                    raise IOError('文件读取中断')
                position += len(chunk)
                yield chunk
        return FileStream(chunks(), size, name)

    def database_import(self, data, source, size):
        name = database_name(data.get('name'))
        if not any(d['name']==name for d in self.databases):
            raise ValueError('数据库不存在')
        if data.get('confirm') != name or size <= 0:
            raise ValueError('请确认数据库名称并选择非空 SQL 文件')
        target = tempfile.TemporaryFile()
        try:
            copy_upload(source, target, size); target.flush()
        except Exception:
            target.close(); raise
        old = self.sql_dumps.get(name)
        self.sql_dumps[name] = target
        if old: old.close()
        return {'message':'演示导入完成，SQL 未实际执行'}

    def database_export(self, data):
        name = database_name(data.get('name'))
        if not any(d['name']==name for d in self.databases):
            raise ValueError('数据库不存在')
        saved = self.sql_dumps.get(name)
        content = b'-- MiniPanel demo export: no actual MySQL server\n' if saved is None else None
        size = len(content) if saved is None else os.fstat(saved.fileno()).st_size
        def chunks():
            if saved is None:
                yield content
            else:
                position = 0
                while position < size:
                    with self.io_lock:
                        saved.seek(position); part = saved.read(min(CHUNK_SIZE,size-position))
                    if not part: raise IOError('演示导出中断')
                    position += len(part); yield part
        return FileStream(chunks(),size,name+'.sql')

    def call(self, action, data, log=None):
        if action.startswith('runtime_') or action in ('check_updates','site_php','php_repository','mysql_migration'):
            from demo_runtime import demo_runtime
            return demo_runtime(self, action, data)
        if action == 'files_compress':
            _, path, _ = self.file_context(data, action)
            names, name, fmt = compression_request(data)
            prefix=path+'/' if path else ''
            target=prefix+name
            if target in self.files[''] or target in self.directories['']:raise ValueError('同名目标已存在')
            keys=[]
            for selected in names:
                source=prefix+selected
                matches=sorted(k for k in self.directories[''] | set(self.files['']) if within(k,source))
                if not matches:raise ValueError('选中的文件不存在')
                keys.extend(matches)
            def entries():
                for key in keys:
                    check_system_path('/'+key, 'files_download')
                    if key in self.directories['']:yield key[len(prefix):], True, 0, None
                    else:
                        value=self.files[''][key];reader=io.BytesIO(value) if isinstance(value,bytes) else value
                        reader.seek(0);size=len(value) if isinstance(value,bytes) else os.fstat(reader.fileno()).st_size
                        yield key[len(prefix):], False, size, reader
            output=tempfile.TemporaryFile()
            try:
                with self.io_lock:count=write_compressed(output,fmt,entries())
                output.flush();self.files[''][target]=output
            except Exception:output.close();raise
            return {'message':'压缩完成（演示），源文件保留','entries':count,'name':name}
        if action == 'files_copy':
            _, target_parent, _ = self.file_context(data, action)
            source = absolute_path(data.get('source')).lstrip('/')
            name = file_name(data.get('name'))
            target = (target_parent+'/' if target_parent else '') + name
            if not source or within(target, source):
                raise ValueError('不能复制到原位置、源目录的子目录或复制系统根目录')
            if target_parent not in self.directories['']:
                raise ValueError('目标目录不存在')
            if target in self.files[''] or target in self.directories['']:
                raise ValueError('目标存在同名文件或文件夹，未覆盖')
            entries = [key for key in self.files[''] if within(key, source)]
            folders = [key for key in self.directories[''] if within(key, source)]
            if not entries and not folders:
                raise ValueError('源文件或目录不存在')
            pending = {}
            try:
                for key in entries + folders:
                    check_system_path('/'+key, 'files_download')
                    check_system_path('/'+target+key[len(source):], action)
                for key in entries:
                    stream = self.download({'scope':'system','path':'/'+key.rsplit('/',1)[0] if '/' in key else '/', 'name':key.rsplit('/',1)[-1]})
                    output = tempfile.TemporaryFile()
                    pending[target+key[len(source):]] = output
                    for chunk in stream.chunks:
                        output.write(chunk)
                    output.flush()
                self.files[''].update(pending)
                self.directories[''].update(target+key[len(source):] for key in folders)
            except Exception:
                for output in pending.values(): output.close()
                raise
            return {'message':'复制完成（本地演示），源文件已保留'}
        if action == 'initial_credentials':
            if self.initial_password is not None and not self.password_changed:
                return {'username': 'admin', 'password': self.initial_password, 'message': '本地演示初始登录信息'}
            return {'username': 'admin', 'message': '初始密码已失效或未保存，请使用你设置的密码登录'}
        if action == "status":
            return {"demo": True, "updates":getattr(self,"update_state",{}), "php_extensions": {"version":"系统默认", "modules":[{"name":n,"loaded":self.installed and (n!="SourceGuardian" or getattr(self,"sourceguardian",False))} for n in ["OPcache","fileinfo","Redis","bcmath","intl","mysqli","PDO MySQL","curl","mbstring","XML","ZIP","GD","SourceGuardian"]],"error":""}, "panel_certificate": {"auto_renew":True,"expires":time.time()+365*86400,"days_remaining":365,"renewal":{"message":"演示：剩余 30 天时自动换新"}}, "renewal": {"timer_active":True,"message":"演示：每日两次检查"}, "hostname": "local-preview", "os": "Debian 12 / 13 · 演示", "load": 0,
                    "disk": {"used": 0, "total": 0}, "sites": self.sites[:], "databases": self.databases[:],
                    "services": [{"name": n, "installed": ('redis-server' in getattr(self,'runtime_versions',{})) if n=='Redis' else self.installed, "running": ('redis-server' in getattr(self,'runtime_versions',{})) if n=='Redis' else self.installed, "version": v if (('redis-server' in getattr(self,'runtime_versions',{})) if n=='Redis' else self.installed) else "未安装"}
                                 for n, v in [("Nginx", "系统仓库版本"), ("PHP", "系统仓库版本"), ("MySQL", "8.4 · 原生安装"), ("Redis", "7 · 本机缓存")]]}
        if action == 'install_sourceguardian':
            if data.get('agree_tos') is not True: raise ValueError('请先同意 SourceGuardian 使用条款')
            if not self.installed: raise ValueError('请先安装 PHP 环境')
            self.sourceguardian = True
            return {'message':'演示：SourceGuardian 已加载，未下载或执行真实 Loader'}
        if action == 'install_php_extensions':
            if not self.installed: raise ValueError('请先安装 PHP 环境')
            return {'message':'演示：PHP 常用扩展已补全'}
        if action == 'renew_certificates':
            return {'message':'演示：续期检查完成，未联系真实 CA'}
        if action == "install":
            for message in ["演示：更新软件源", "演示：安装 Nginx 与 PHP", "演示：准备 MySQL 8.4", "演示环境已就绪（未安装真实服务）"]:
                if log:
                    log(message)
                time.sleep(0.5)
            self.installed = True
            if data.get('sourceguardian'):
                self.call('install_sourceguardian', data, log)
            return {"message": "演示安装完成"}
        if not self.installed and not action.startswith('files_') and action != 'change_password':
            raise APIError(409, "请先安装运行环境")
        if action == "create_site":
            domain = domain_name(data.get("domain"))
            if any(s["domain"] == domain for s in self.sites):
                raise ValueError("该域名已经添加")
            self.sites.append({"domain": domain, "root": website_root(data.get("root"), domain), "enabled": True, "php": "系统默认", "ssl": False, "force_https": False, "created": time.strftime("%Y-%m-%d %H:%M")})
            path = self.sites[-1]['root'].lstrip('/')
            existed = path in self.directories['']
            for i in range(1, len(path.split('/'))+1):
                self.directories[''].add('/'.join(path.split('/')[:i]))
            if not existed:
                self.files[''][path+'/index.html'] = b'<!doctype html><h1>MiniPanel demo site</h1>'
        elif action == 'delete_site':
            domain = domain_name(data.get('domain'))
            if data.get('confirm') != domain: raise ValueError('请确认完整域名')
            if not any(s['domain']==domain for s in self.sites): raise ValueError('网站不存在')
            self.sites = [s for s in self.sites if s['domain']!=domain]
            return {'message':'域名配置已删除；网站文件、证书和数据库保留（演示）'}
        elif action == 'configure_rewrite':
            site = next((s for s in self.sites if s['domain']==data['domain']),None)
            if site is None: raise ValueError('网站不存在')
            site['rewrite'] = rewrite_rules(data.get('rewrite'))
            return {'message':'规则已保存（演示，未执行真实 Nginx 校验）'}
        elif action == 'delete_database':
            name = database_name(data.get('name'))
            if data.get('confirm') != name: raise ValueError('请输入完整数据库名称确认删除')
            if not any(d['name']==name for d in self.databases): raise ValueError('数据库不存在')
            self.databases = [d for d in self.databases if d['name']!=name]
            old = self.sql_dumps.pop(name,None)
            if old: old.close()
            return {'message':'数据库已删除（演示）'}
        elif action == 'change_password':
            config = make_config(data.get('new_password'))
            self.password_changed = True
            return {'config': config}
        elif action == 'site_root':
            site = next((s for s in self.sites if s['domain'] == data['domain']), None)
            if not site:
                raise ValueError('网站不存在')
            target = website_root(data.get('root'), data['domain'])
            for i in range(1, len(target.lstrip('/').split('/'))+1):
                self.directories[''].add('/'.join(target.lstrip('/').split('/')[:i]))
            site['root'] = target
        elif action == "toggle_site":
            site = next((s for s in self.sites if s["domain"] == data.get("domain")), None)
            if not site:
                raise ValueError("网站不存在")
            site["enabled"] = data["enabled"]
        elif action == 'configure_ssl':
            site = next((s for s in self.sites if s['domain'] == data.get('domain')), None)
            if not site:
                raise ValueError('网站不存在')
            if data['force_https'] and not data['ssl']:
                raise ValueError('请先启用网站 SSL，再开启强制 HTTPS')
            kind = data.get('cert_type',site.get('cert_type','selfsigned'))
            if data['ssl'] and kind == 'letsencrypt':
                from ssl_manager import validate_registration
                if not site.get('acme_agreed'):
                    validate_registration(data)
                site.update(acme_agreed=True, acme_email=data.get('email',''))
                if log: log('演示：HTTP-01 验证、签发并设置自动续期（未联系 CA）')
            site.update(ssl=data['ssl'], force_https=data['force_https'], cert_type=kind, certificate='本地演示证书，未实际签发', certificate_info={'type':kind,'expires':time.time()+(90 if kind=='letsencrypt' else 365)*86400,'days_remaining':90 if kind=='letsencrypt' else 365})
        elif action.startswith('files_'):
            domain, path, base = self.file_context(data, action)
            if domain not in self.files or path not in self.directories[domain]:
                raise ValueError('网站或目录不存在')
            prefix = path + '/' if path else ''
            if action == 'files_list':
                entries = []
                for key in self.directories[domain] | set(self.files[domain]):
                    if key.startswith(prefix) and key != path and '/' not in key[len(prefix):]:
                        content = self.files[domain].get(key, b'')
                        size = len(content) if isinstance(content,bytes) else os.fstat(content.fileno()).st_size
                        entries.append({'name': key[len(prefix):], 'kind': 'directory' if key in self.directories[domain] else 'file', 'size': size, 'modified': time.time()})
                return {'path': data.get('path', ''), 'root': base, 'entries': sorted(entries, key=lambda e: (e['kind'] != 'directory', e['name'])), 'limit': None}
            name = file_name(data.get('name'))
            key = prefix + name
            if action == 'files_delete':
                if key not in self.directories[domain] and key not in self.files[domain]:
                    raise ValueError('文件或目录不存在')
                for item in list(self.files[domain]):
                    if item == key or item.startswith(key + '/'):
                        content = self.files[domain].pop(item)
                        if not isinstance(content, bytes):
                            content.close()
                self.directories[domain].difference_update({p for p in self.directories[domain] if p == key or p.startswith(key + '/')})
                return {'message': '已删除'}
            if action == 'files_extract':
                destination = file_name(data.get('destination'))
                target = prefix + destination
                if target in self.directories[domain] or target in self.files[domain]:
                    raise ValueError('解压目标已存在，请使用新目录名')
                if key not in self.files[domain]:
                    raise ValueError('压缩包不存在')
                stored = self.files[domain][key]
                pending, folders = {}, {target}
                try:
                    with self.io_lock:
                        source = io.BytesIO(stored) if isinstance(stored, bytes) else stored
                        source.seek(0)
                        with archive_members(source, name) as (entries, opener):
                            deadline = time.monotonic() + ARCHIVE_TIMEOUT
                            for raw, directory, size, item in entries:
                                parts = raw.split('/')
                                for i in range(1, len(parts) + (1 if directory else 0)):
                                    folders.add(target + '/' + '/'.join(parts[:i]))
                                if not directory:
                                    output = tempfile.TemporaryFile()
                                    pending[target + '/' + raw] = output
                                    with opener(item) as content:
                                        copy_archive_member(content, output, size, deadline)
                                    output.flush()
                    self.directories[domain].update(folders)
                    self.files[domain].update(pending)
                    return {'message': '解压完成（本地演示）', 'path': (data.get('path', '').rstrip('/') + '/' + destination).lstrip('/') if data['scope'] == 'site' else '/' + target, 'entries': len(entries)}
                except Exception:
                    for output in pending.values():
                        output.close()
                    raise
            if key in self.directories[domain] or (key in self.files[domain] and (action in {'files_mkdir', 'files_create'} or not data.get('overwrite'))):
                raise ValueError('同名文件或目录已存在')
            if action == 'files_mkdir':
                self.directories[domain].add(key)
            elif action == 'files_create':
                self.files[domain][key] = b''
        elif action == "create_database":
            name = database_name(data.get("name"))
            if any(d["name"] == name for d in self.databases):
                raise ValueError("数据库已经存在")
            database = {"name": name, "username": name, "host": "127.0.0.1", "port": 3306}
            self.databases.append(database)
            return {"message": "演示数据库已创建", "database": database, "password": secrets.token_hex(16)}
        return {"message": "演示操作完成"}


class SystemBackend:
    COMMAND = ["/usr/bin/sudo", "-n", "/usr/bin/python3", "-I", "/opt/minipanel/helper.py"]

    def upload(self, data, source, size, action="files_upload"):
        process = subprocess.Popen(self.COMMAND, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
        try:
            request = dict(data, action=action, size=size)
            process.stdin.write((json.dumps(request)+'\n').encode())
            copy_upload(source, process.stdin, size)
            process.stdin.close(); process.stdin = None
            output, _ = process.communicate(timeout=1860 if action == "database_import" else 150)
            item = json.loads(output)
            if 'error' in item:
                raise RuntimeError(item['error'])
            return item['result']
        finally:
            if process.stdin:
                process.stdin.close()
            if process.poll() is None:
                try:
                    process.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    process.kill(); process.wait()
            process.stdout.close()

    def download(self, data, action="files_download"):
        process = subprocess.Popen(self.COMMAND, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
        try:
            process.stdin.write((json.dumps(dict(data,action=action))+'\n').encode())
            process.stdin.close()
            item = json.loads(process.stdout.readline(8193))
            if 'error' in item:
                raise RuntimeError(item['error'])
            metadata = item['stream']
        except Exception:
            process.stdout.close()
            process.kill(); process.wait()
            raise
        def chunks():
            remaining = metadata['size']
            try:
                while remaining:
                    chunk = process.stdout.read(min(CHUNK_SIZE, remaining))
                    if not chunk:
                        raise IOError('下载连接中断，文件未传输完整')
                    remaining -= len(chunk)
                    yield chunk
            finally:
                process.stdout.close()
                try:
                    process.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    process.kill(); process.wait()
        return FileStream(chunks(), metadata['size'], metadata['name'])

    def database_import(self, data, source, size):
        return self.upload(data, source, size, action='database_import')

    def database_export(self, data):
        return self.download(data, action='database_export')

    def call(self, action, data, log=None):
        request = dict(data, action=action)
        command = self.COMMAND
        if log is None:
            completed = subprocess.run(command, input=json.dumps(request), text=True, capture_output=True, timeout=2 * ARCHIVE_TIMEOUT + 60 if action in {'files_extract', 'files_copy', 'files_compress'} else 150)
            output = completed.stdout.splitlines()
            if not output:
                raise RuntimeError("系统助手未响应，请检查 minipanel 的 sudo 配置")
        else:
            process = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
            # The broker imposes per-command timeouts; the service's cgroup kills children on shutdown.
            process.stdin.write(json.dumps(request))
            process.stdin.close()
            output = []
            for line in process.stdout:
                try:
                    item = json.loads(line)
                except ValueError:
                    log(line[:4000])
                    continue
                if "log" in item:
                    log(item["log"])
                else:
                    output.append(line)
            process.wait()
        for line in reversed(output):
            item = json.loads(line)
            if "error" in item:
                raise RuntimeError(item["error"])
            if "result" in item:
                return item["result"]
        raise RuntimeError("系统助手返回格式异常")


class Panel:
    def __init__(self, config, backend=None, data_dir=None):
        self.config = config
        self.backend = backend or SystemBackend()
        self.data_dir = Path(data_dir) if data_dir else None
        self.sessions, self.attempts = {}, deque()
        self.password_attempts = deque()
        self.lock = threading.RLock()
        self.operation = threading.Lock()
        self.job = None
        if self.data_dir:
            self.data_dir.mkdir(parents=True, exist_ok=True)
            file = self.data_dir / "last-job.json"
            if file.exists():
                self.job = json.loads(file.read_text())
                if self.job["status"] == "running":
                    self.job.update(status="failed", message="面板曾重启，任务中断。请检查服务状态后重试。")

    def save_job(self):
        if self.data_dir:
            temp = self.data_dir / "last-job.tmp"
            temp.write_text(json.dumps(self.job, ensure_ascii=False), encoding="utf-8")
            temp.replace(self.data_dir / "last-job.json")

    def append_log(self, message):
        with self.lock:
            self.job["logs"].extend(message.strip().splitlines())
            self.job["logs"] = self.job["logs"][-350:]
            self.save_job()

    def install_worker(self, action="install", data=None):
        try:
            result = self.backend.call(action, data or {}, self.append_log)
            with self.lock:
                self.job.update(status="success", message=result["message"])
        except Exception as error:
            with self.lock:
                self.job.update(status="failed", message=str(error))
        finally:
            with self.lock:
                self.save_job()
            self.operation.release()

    def session(self, env):
        cookie = SimpleCookie()
        try:
            cookie.load(env.get("HTTP_COOKIE", ""))
        except Exception:
            return None, None
        item = cookie.get("mp_session")
        token = item.value if item else None
        with self.lock:
            now = time.time()
            self.sessions = {k: v for k, v in self.sessions.items() if v["expires"] > now}
            return token, self.sessions.get(token)

    def body(self, env, limit=8192):
        try:
            size = int(env.get("CONTENT_LENGTH") or "0")
        except ValueError:
            raise APIError(400, "请求长度无效") from None
        if not 0 < size <= limit:
            raise APIError(413, "请求过大或为空")
        if env.get("CONTENT_TYPE", "").split(";")[0] != "application/json":
            raise APIError(415, "仅接受 JSON 请求")
        try:
            data = json.loads(env["wsgi.input"].read(size))
        except (ValueError, UnicodeError):
            raise APIError(400, "JSON 格式无效") from None
        if not isinstance(data, dict):
            raise APIError(400, "请求内容必须是对象")
        return data

    def dispatch(self, env):
        path, method = env.get("PATH_INFO", "/"), env["REQUEST_METHOD"]
        headers = []
        host = env.get("HTTP_HOST", "")
        scheme = env.get("wsgi.url_scheme", "http")
        if isinstance(self.backend, DemoBackend):
            if host not in {"127.0.0.1:8888", "localhost:8888", "[::1]:8888"}:
                raise APIError(403, "演示模式仅允许本地访问")
        else:
            if not re.fullmatch(r"[a-zA-Z0-9.-]+:8888", host):
                raise APIError(403, "请通过服务器地址的 8888 端口访问")
            if scheme != "https":
                raise APIError(403, "请使用 HTTPS 访问面板")
        if method == "POST":
            origin = env.get("HTTP_ORIGIN")
            if origin and origin != f"{scheme}://{host}":
                raise APIError(403, "请求来源不匹配")
            if env.get("HTTP_SEC_FETCH_SITE") == "cross-site":
                raise APIError(403, "拒绝跨站请求")
        if method == "GET" and path in {"/", "/static/style.css", "/static/app.js", "/static/runtime.js"}:
            file = BASE / ("static/index.html" if path == "/" else path.lstrip("/"))
            content_type = {".html": "text/html", ".css": "text/css", ".js": "text/javascript"}[file.suffix]
            return 200, file.read_bytes(), [("Content-Type", content_type + "; charset=utf-8")]
        token, session = self.session(env)
        if method == "POST" and path == "/api/login":
            data = self.body(env)
            now = time.time()
            with self.lock:
                while self.attempts and self.attempts[0] < now - 300:
                    self.attempts.popleft()
                if len(self.attempts) >= 10:
                    raise APIError(429, "登录尝试过多，请 5 分钟后重试")
                # Count before hashing to bound concurrent attempts as well.
                self.attempts.append(now)
            password = data.get("password", "")
            username = data.get("username", "")
            if not isinstance(password, str) or len(password) > 256:
                raise APIError(400, "密码格式无效")
            with self.lock:
                config = self.config.copy()
            valid = hmac.compare_digest(password_hash(password, config["salt"]), config["password_hash"])
            if not valid or username != self.config["username"]:
                raise APIError(401, "用户名或密码不正确")
            token = secrets.token_urlsafe(32)
            session = {"csrf": secrets.token_urlsafe(24), "expires": now + 8 * 3600}
            with self.lock:
                if self.config != config:
                    raise APIError(401, "密码已变更，请重新登录")
                self.sessions[token] = session
            secure = "; Secure" if scheme == "https" else ""
            headers.append(("Set-Cookie", f"mp_session={token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=28800{secure}"))
            return 200, {"csrf": session["csrf"], "username": username}, headers
        if not session:
            raise APIError(401, "请先登录")
        if method == "POST":
            if not hmac.compare_digest(env.get("HTTP_X_CSRF_TOKEN", ""), session["csrf"]):
                raise APIError(403, "操作令牌失效，请重新登录")
            if path in {'/api/files/upload','/api/databases/import'}:
                query = parse_qs(env.get('QUERY_STRING', ''), keep_blank_values=True)
                data = {key: values[0] for key, values in query.items() if len(values) == 1}
                if data.get('overwrite', 'false') not in {'true', 'false'}:
                    raise ValueError('覆盖选项无效')
                data['overwrite'] = data.get('overwrite') == 'true'
                if env.get('CONTENT_TYPE') != 'application/octet-stream':
                    raise APIError(415, '上传接口仅接受文件二进制数据')
                size = int(env.get('CONTENT_LENGTH') or '-1')
                if size < 0:
                    raise APIError(411, '上传请求必须提供文件大小')
            else:
                data = self.body(env)
        else:
            data = {}
        if method == "GET" and path == "/api/session":
            result = {"csrf": session["csrf"], "username": self.config["username"]}
        elif method == "POST" and path == "/api/logout":
            with self.lock:
                self.sessions.pop(token, None)
            headers.append(("Set-Cookie", "mp_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0"))
            result = {"message": "已退出登录"}
        elif method == 'POST' and path == '/api/account/password':
            old, new = data.get('old_password'), data.get('new_password')
            if not isinstance(old, str) or len(old) > 256:
                raise ValueError('原密码格式无效')
            if not isinstance(new, str) or not 1 <= len(new) <= 256:
                raise ValueError('新密码不能为空，最多 256 个字符')
            if new != data.get('confirm_password'):
                raise ValueError('两次输入的新密码不一致')
            if not self.operation.acquire(blocking=False):
                raise APIError(409, '已有任务正在进行，请稍后修改密码')
            try:
                with self.lock:
                    if token not in self.sessions:
                        raise APIError(401, '登录已失效')
                    now = time.time()
                    while self.password_attempts and self.password_attempts[0] < now - 300:
                        self.password_attempts.popleft()
                    if len(self.password_attempts) >= 5:
                        raise APIError(429, '密码验证尝试过多，请 5 分钟后重试')
                    self.password_attempts.append(now)
                    if not hmac.compare_digest(password_hash(old, self.config['salt']), self.config['password_hash']):
                        raise ValueError('原密码不正确')
                    result = self.backend.call('change_password', {'old_password': old, 'new_password': new})
                    self.config = result['config']
                    self.sessions.clear()
                    self.attempts.clear()
                headers.append(('Set-Cookie', 'mp_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0'))
                result = {'message': '密码已修改，所有登录已退出，请使用新密码登录'}
            finally:
                self.operation.release()
        elif method == "GET" and path == "/api/status":
            result = self.backend.call("status", {})
        elif method == 'GET' and path in {'/api/files', '/api/files/download'}:
            query = parse_qs(env.get('QUERY_STRING', ''), keep_blank_values=True)
            data = {key: values[0] for key, values in query.items() if len(values) == 1}
            validate_file_request(data)
            if path.endswith('download'):
                data['name'] = file_name(data.get('name'))
                result = self.backend.download(data)
                return 200, result, [('Content-Type', 'application/octet-stream'), ('Content-Disposition', "attachment; filename*=UTF-8''" + quote(result.name, safe=''))]
            result = self.backend.call('files_list', data)
        elif method == 'GET' and path == '/api/databases/export':
            query = parse_qs(env.get('QUERY_STRING',''))
            name = database_name(query.get('name',[''])[0])
            result = self.backend.database_export({'name':name})
            return 200, result, [('Content-Type','application/sql'), ('Content-Disposition',"attachment; filename*=UTF-8''"+quote(result.name,safe=''))]
        elif method == 'GET' and path == '/api/runtime':
            result = self.backend.call('runtime_inventory', {})
        elif method == 'POST' and path in {'/api/runtime/check','/api/runtime/plan','/api/runtime/apply','/api/runtime/php-repository','/api/runtime/site-php','/api/runtime/migration','/api/runtime/sg','/api/runtime/service'}:
            action={'check':'check_updates','plan':'runtime_plan','apply':'runtime_apply','php-repository':'php_repository','site-php':'site_php','migration':'mysql_migration','sg':'install_sourceguardian','service':'runtime_service'}[path.rsplit('/',1)[-1]]
            if action=='mysql_migration':
                return 200, self.backend.call(action,data), headers
            if not self.operation.acquire(blocking=False):raise APIError(409,'已有任务正在进行')
            with self.lock:
                self.job={'status':'running','message':'正在执行环境管理任务','logs':[],'started':time.time()};self.save_job()
            threading.Thread(target=self.install_worker,args=(action,data),daemon=True).start()
            result={'message':'任务已开始，请查看日志；完成后返回环境管理查看结果'}
        elif method == "GET" and path == "/api/job":
            with self.lock:
                result = json.loads(json.dumps(self.job)) if self.job else None
        elif method == 'GET' and path == '/api/account/initial-credentials':
            with self.lock:
                if token not in self.sessions:
                    raise APIError(401, '登录已失效')
                result = self.backend.call('initial_credentials', {})
        elif method == "POST" and path in {"/api/install", "/api/certificates/renew", "/api/php/extensions", "/api/php/sourceguardian"}:
            if type(data.get('sourceguardian', False)) is not bool:
                raise ValueError('SG 安装选项无效')
            if path == '/api/install' and data.get('sourceguardian') and data.get('agree_tos') is not True:
                raise ValueError('请先阅读并同意 SourceGuardian Loader 使用条款')
            if path.endswith("sourceguardian") and data.get("agree_tos") is not True:
                raise ValueError("请先阅读并同意 SourceGuardian Loader 使用条款")
            if not self.operation.acquire(blocking=False):
                raise APIError(409, "已有任务正在进行")
            action = {"/api/install":"install","/api/certificates/renew":"renew_certificates","/api/php/extensions":"install_php_extensions", "/api/php/sourceguardian":"install_sourceguardian"}[path]
            with self.lock:
                self.job = {"status": "running", "message": "正在安装 SourceGuardian" if action == "install_sourceguardian" else "正在补全 PHP 扩展" if action == "install_php_extensions" else "正在检查域名证书续期" if path.endswith("renew") else "正在安装运行环境", "logs": [], "started": time.time()}
                self.save_job()
            threading.Thread(target=self.install_worker, args=(action, {"agree_tos":data.get("agree_tos"), "sourceguardian":data.get("sourceguardian", False)}), daemon=True).start()
            result = {"message": "任务已开始，请查看安装日志"}
        elif method == "POST" and path in {"/api/sites", "/api/sites/toggle", "/api/sites/ssl", "/api/restart", "/api/databases", '/api/files/upload', '/api/files/mkdir', '/api/files/extract', '/api/files/create', '/api/files/delete', '/api/files/copy', '/api/files/compress', '/api/sites/root', '/api/sites/delete', '/api/sites/rewrite', '/api/databases/delete', '/api/databases/import'}:
            actions = {"/api/sites": "create_site", "/api/sites/toggle": "toggle_site", "/api/restart": "restart", "/api/databases": "create_database", '/api/sites/ssl': 'configure_ssl', '/api/files/upload': 'files_upload', '/api/files/mkdir': 'files_mkdir', '/api/files/extract': 'files_extract', '/api/files/create': 'files_create', '/api/files/delete': 'files_delete', '/api/files/copy': 'files_copy', '/api/files/compress':'files_compress', '/api/sites/root': 'site_root', '/api/sites/delete': 'delete_site', '/api/sites/rewrite': 'configure_rewrite', '/api/databases/delete': 'delete_database', '/api/databases/import': 'database_import'}
            if path.startswith("/api/sites"):
                data["domain"] = domain_name(data.get("domain"))
                if path in {"/api/sites", "/api/sites/root"}:
                    data["root"] = website_root(data.get("root"), data["domain"])
                if path.endswith('rewrite'):
                    data['rewrite'] = rewrite_rules(data.get('rewrite'))
                if path.endswith("toggle") and type(data.get("enabled")) is not bool:
                    raise ValueError("网站状态无效")
                if path.endswith('ssl'):
                    if type(data.get('ssl')) is not bool or type(data.get('force_https')) is not bool:
                        raise ValueError('SSL 设置格式无效')
                    if data.get('cert_type', 'selfsigned') not in {'selfsigned', 'letsencrypt'}:
                        raise ValueError('证书类型无效')
                    if data['force_https'] and not data['ssl']:
                        raise ValueError('请先启用网站 SSL，再开启强制 HTTPS')
            if path.startswith('/api/files/'):
                validate_file_request(data)
                data['name'] = file_name(data.get('name'))
                if path == '/api/files/compress':
                    compression_request(data)
                if path == '/api/files/copy':
                    data['source'] = absolute_path(data.get('source'))
                if path == '/api/files/extract':
                    data['destination'] = file_name(data.get('destination'))
            if path.startswith("/api/databases"):
                data["name"] = database_name(data.get("name"))
            if path == "/api/restart" and data.get("service") not in {"Nginx", "PHP", "MySQL", "Redis"}:
                raise ValueError("不支持的服务")
            if not self.operation.acquire(blocking=False):
                raise APIError(409, "已有任务正在进行，请稍后重试")
            if path == '/api/sites/ssl' and data.get('cert_type') == 'letsencrypt' and data.get('ssl'):
                with self.lock:
                    self.job = {'status':'running', 'message':'正在申请或配置域名证书', 'logs':[], 'started':time.time()}
                    self.save_job()
                threading.Thread(target=self.install_worker,args=('configure_ssl',data),daemon=True).start()
                return 200, {'message':'证书任务已启动，请查看任务日志', 'job':True}, headers
            try:
                if path == '/api/databases/import':
                    result = self.backend.database_import(data, env['wsgi.input'], size)
                elif path == '/api/files/upload':
                    result = self.backend.upload(data, env['wsgi.input'], size)
                else:
                    result = self.backend.call(actions[path], data)
            finally:
                self.operation.release()
        else:
            raise APIError(404, "接口不存在")
        return 200, result, headers

    def __call__(self, env, start_response):
        try:
            status, data, headers = self.dispatch(env)
        except APIError as error:
            status, data, headers = error.status, {"error": error.message}, []
        except ValueError as error:
            status, data, headers = 400, {"error": str(error)}, []
        except Exception as error:
            status, data, headers = 500, {"error": str(error)}, []
        streamed = isinstance(data, FileStream)
        if not isinstance(data, bytes) and not streamed:
            data = json.dumps(data, ensure_ascii=False).encode()
            headers.append(("Content-Type", "application/json; charset=utf-8"))
        headers.extend([("Content-Length", str(data.size if streamed else len(data))), ("Cache-Control", "no-store"), ("X-Content-Type-Options", "nosniff"),
                        ("X-Frame-Options", "DENY"), ("Referrer-Policy", "no-referrer"),
                        ("Content-Security-Policy", "default-src 'self'; style-src 'self'; script-src 'self'; img-src 'self' data:; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")])
        from http import HTTPStatus
        start_response(f"{status} {HTTPStatus(status).phrase}", headers)
        return data.chunks if streamed else [data]


def create_app():
    config = json.loads(Path("/etc/minipanel/auth.json").read_text())
    return Panel(config, data_dir="/var/lib/minipanel")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--demo", action="store_true", help="Local preview; all system actions are simulated")
    args = parser.parse_args()
    if args.demo:
        password = os.environ.get("MINIPANEL_DEMO_PASSWORD") or secrets.token_urlsafe(16)
        app = Panel(make_config(password), DemoBackend(password))
        print(f"DEMO ONLY http://127.0.0.1:8888  admin / {password}", flush=True)
        from socketserver import ThreadingMixIn
        from wsgiref.simple_server import make_server, WSGIServer
        class ThreadedServer(ThreadingMixIn, WSGIServer):
            daemon_threads = True
        make_server("127.0.0.1", 8888, app, server_class=ThreadedServer).serve_forever()
    else:
        raise SystemExit("服务器请使用安装脚本创建的 minipanel systemd 服务启动。预览可使用 --demo。")


if __name__ == "__main__":
    main()
