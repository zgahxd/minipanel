#!/usr/bin/python3
"""Download a package snapshot. Never copy configuration, credentials or business data."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time


def run(args, cwd=None):
    result=subprocess.run(args, cwd=cwd, text=True, capture_output=True,
                          env=dict(os.environ, LC_ALL='C', DEBIAN_FRONTEND='noninteractive'))
    if result.returncode:
        raise RuntimeError((result.stderr or result.stdout)[-12000:])
    return result.stdout


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('destination', help='A new directory, preferably outside website directories')
    parser.add_argument('--packages', nargs='+', help='Resolve named packages and their dependencies instead of snapshotting installed packages')
    args=parser.parse_args()
    output=Path(args.destination).resolve()
    output.mkdir(mode=0o700, parents=False, exist_ok=False)
    debs=output/'debs';debs.mkdir(mode=0o755)
    manifest={'created':time.time(),'architecture':run(['dpkg','--print-architecture']).strip(),
              'os_release':Path('/etc/os-release').read_text(),'complete':False,'packages':[],
              'scope':'APT packages only; excludes manually installed SourceGuardian binaries, configuration and business data.'}
    try:
        if args.packages:
            import re
            if any(not re.fullmatch(r'[a-z0-9][a-z0-9+.-]*(?:=[0-9][A-Za-z0-9.+:~_-]*)?', p) for p in args.packages):
                raise ValueError('Invalid package specification')
            # Empty status forces resolution and download of dependencies even when installed on the builder.
            status=output/'empty-status';status.write_text('')
            run(['apt-get','-y','--download-only','--no-remove','-o','Dir::State::status='+str(status),
                 '-o','Dir::Cache::archives='+str(debs),'install']+args.packages)
        else:
            listing=run(['dpkg-query','-W','-f=${binary:Package}\t${Version}\t${db:Status-Status}\n'])
            specs=[p+'='+v for row in listing.splitlines() if len(parts:=row.split('\t'))==3
                   for p,v,s in [parts] if s=='installed']
            manifest['requested']=specs
            for start in range(0,len(specs),20):run(['apt-get','download']+specs[start:start+20],cwd=debs)
        sums=[]
        for file in sorted(debs.glob('*.deb')):
            metadata=run(['dpkg-deb','-f',str(file),'Package','Version','Architecture'])
            with file.open('rb') as source: digest=hashlib.file_digest(source,'sha256').hexdigest()
            sums.append(digest+'  debs/'+file.name+'\n')
            manifest['packages'].append({'file':file.name,'metadata':metadata,'sha256':digest})
        if not sums:raise RuntimeError('No packages downloaded')
        (output/'SHA256SUMS').write_text(''.join(sums))
        manifest['complete']=True
    except Exception as error:
        manifest['error']=str(error)
        raise
    finally:
        (output/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
    print(f'Backed up {len(manifest["packages"])} packages to {output}')


if __name__=='__main__':main()
