#!/usr/bin/python3 -I
"""Daily package metadata check, with no unattended package installation."""
import fcntl
import os
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from helper import STATE
from runtime_manager import check_updates

if __name__=='__main__':
    if os.geteuid()!=0:raise SystemExit('请使用 root')
    with (STATE/'operation.lock').open('a') as lock:
        try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:raise SystemExit('面板正在执行其他任务，下次检查时重试')
        try:print(check_updates()['message'])
        except Exception as error:raise SystemExit(str(error))
