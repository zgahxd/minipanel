'use strict';
let runtimeState=null, compressionSelection=null, compressing=false;
function runtimeTable(rows, columns) {
  return '<div class="table-wrap"><table><thead><tr>'+columns.map(c=>'<th>'+esc(c[1])+'</th>').join('')+'</tr></thead><tbody>'+rows.map(r=>'<tr>'+columns.map(c=>'<td>'+esc(r[c[0]]??'未安装')+'</td>').join('')+'</tr>').join('')+'</tbody></table></div>';
}
function runtimeVersions() {
  const kind=$('#runtime-kind').value;
  $('#runtime-branch-label').hidden=kind!=='php';
  const name=kind==='php'?'php'+$('#runtime-branch').value+'-fpm':({mysql:'mysql-community-server',redis:'redis-server',nginx:'nginx'})[kind];
  const pkg=runtimeState?.packages.find(p=>p.name===name);
  $('#runtime-version').innerHTML=(pkg?.versions||[]).map(v=>`<option value="${esc(v.version)}">${esc(v.version)} — ${esc(v.source)}</option>`).join('');
  $('#runtime-current').textContent='当前安装：'+(pkg?.installed||'未安装')+(!pkg?.versions.length?'；软件源中无可选版本，请先检查更新或配置对应软件源。':'');
}
async function loadRuntime() {
  $('#runtime-error').textContent='';
  try {
    runtimeState=await api('runtime');
    const u=runtimeState.updates||{}, p=runtimeState.plan;
    $('#runtime-update-state').textContent=(u.checked?'上次检查：'+new Date(u.checked*1000).toLocaleString():'尚未检查')+' · '+(runtimeState.timer_active?'每日检查已启用':'每日检查未运行 / 演示模式')+(u.error?' · 检查失败：'+u.error:'')+(u.unsupported_php?.length?' · PHP '+u.unsupported_php.join('、')+' 已结束上游安全支持':'');
    $('#runtime-updates').innerHTML=runtimeTable((u.packages||[]).map(x=>({...x,note:x.migration_required?'需要迁移':'可预览更新'})),[['name','软件包'],['installed','已安装'],['candidate','可用版本'],['note','操作']]);
    $('#runtime-plan').innerHTML=p?runtimeTable(p.changes,[['name','软件包'],['from','原版本'],['to','目标版本']])+'<p>'+esc(p.message)+'</p>':'暂无待执行计划';
    $('#apply-runtime').disabled=!p || !$('#runtime-backup-ack').checked;
    const r=runtimeState.last_result;
    $('#runtime-result').textContent=r?'上次执行：'+r.status+(r.error?' · '+r.error:''):'';
    runtimeVersions();
    const previous=$('#runtime-site').value;
    $('#runtime-site').innerHTML=(state?.sites||[]).map(s=>`<option value="${esc(s.domain)}">${esc(s.domain)} · PHP ${esc(s.php)}</option>`).join('');
    if([...$('#runtime-site').options].some(o=>o.value===previous))$('#runtime-site').value=previous;
    for(const id of ['runtime-site-php','runtime-sg-php'])$('#'+id).innerHTML=runtimeState.php_installed.map(v=>`<option>${esc(v)}</option>`).join('');
    $('#runtime-modules').innerHTML=(runtimeState.php_modules||[]).map(p=>'<p>PHP '+esc(p.version||p.php)+' '+(p.modules||[]).map(m=>`<span class="tag ${m.loaded?'good':'neutral'}">${esc(m.name)} · ${m.loaded?'已加载':'未加载'}</span>`).join(' ')+'</p><p class="error">'+esc(p.error||'')+'</p>').join('');
  }catch(e){$('#runtime-error').textContent=e.message;}
}
async function runtimeAction(action,data={}) {
  const r=await api('runtime/'+action,data);notify(r.message||'任务已提交');await pollJob();
  if(job?.status==='running')$('#runtime-result').textContent='任务执行中，可在安装日志查看进度。';
  else await loadRuntime();
}
$('#runtime-refresh').onclick=()=>busy($('#runtime-refresh'),loadRuntime);
$('#runtime-kind').onchange=runtimeVersions;$('#runtime-branch').onchange=runtimeVersions;
$('#check-updates').onclick=()=>busy($('#check-updates'),()=>runtimeAction('check'));
$('#plan-updates').onclick=()=>busy($('#plan-updates'),()=>runtimeAction('plan',{kind:'updates'}));
$('#runtime-version-form').onsubmit=e=>{e.preventDefault();busy(e.submitter,()=>runtimeAction('plan',{kind:$('#runtime-kind').value,php:$('#runtime-branch').value,version:$('#runtime-version').value,legacy_ack:$('#runtime-legacy').checked}));};
$('#runtime-backup-ack').onchange=()=>{$('#apply-runtime').disabled=!runtimeState?.plan||!$('#runtime-backup-ack').checked;};
$('#apply-runtime').onclick=async()=>{await busy($('#apply-runtime'),async()=>{await runtimeAction('apply',{id:runtimeState?.plan?.id,backup_ack:$('#runtime-backup-ack').checked});$('#runtime-backup-ack').checked=false;});$('#apply-runtime').disabled=!runtimeState?.plan||!$('#runtime-backup-ack').checked;};
$('#php-repository').onclick=()=>busy($('#php-repository'),async()=>{if(await confirmAction('启用第三方 PHP 软件源','将安装 Sury 签名密钥并添加 packages.sury.org 软件源，后续 PHP 更新可能由该源提供。是否继续？'))await runtimeAction('php-repository',{ack:true});});
$('#site-php-form').onsubmit=e=>{e.preventDefault();busy(e.submitter,()=>runtimeAction('site-php',{domain:$('#runtime-site').value,php:$('#runtime-site-php').value,legacy_ack:$('#site-php-legacy').checked}));};
$('#runtime-sg-form').onsubmit=e=>{e.preventDefault();busy(e.submitter,()=>runtimeAction('sg',{php:$('#runtime-sg-php').value,update:true,agree_tos:$('#runtime-sg-agree').checked}));};
$('#runtime-service-form').onsubmit=e=>{e.preventDefault();busy(e.submitter,async()=>{if(await confirmAction('执行服务操作','该操作可能中断网站、数据库或缓存连接。是否继续？'))await runtimeAction('service',{service:$('#runtime-service').value,operation:$('#runtime-service-operation').value,ack:true});});};
$('#mysql-migration-form').onsubmit=e=>{e.preventDefault();busy(e.submitter,async()=>{const r=await api('runtime/migration',{target:$('#mysql-migration-target').value});$('#mysql-migration-result').innerHTML='<p>'+esc(r.source)+' → '+esc(r.target)+'</p><p>'+esc(r.warning)+'</p><ol>'+r.steps.map(s=>'<li>'+esc(s)+'</li>').join('')+'</ol><p>面板管理的数据库：</p>'+r.databases.map(d=>`<a href="/api/databases/export?name=${encodeURIComponent(d.name)}">导出 ${esc(d.name)}</a> `).join('');});};
$('#compress-selected').onclick=()=>{
  compressionSelection={...fileView,names:[...selectedFiles]};
  $('#compress-form').reset();$('#compress-form .form-error').textContent='';
  $('#compress-selection').textContent=compressionSelection.path+'：'+compressionSelection.names.join('、');$('#compress-dialog').showModal();
};
$('#compress-format').onchange=()=>{$('#compress-name').value=$('#compress-name').value.replace(/\.(zip|tar\.gz)$/i,'')+'.'+$('#compress-format').value;};
$('#compress-dialog').addEventListener('cancel',e=>{if(compressing)e.preventDefault();});
$('#compress-form').onsubmit=async e=>{
  e.preventDefault();if(compressing)return;compressing=true;
  const payload={...compressionSelection,name:$('#compress-name').value,format:$('#compress-format').value};
  const controls=[...$('#compress-form').elements];controls.forEach(c=>c.disabled=true);
  try{const r=await api('files/compress',payload);$('#compress-dialog').close();notify(r.message);await openFiles('',payload.path);}
  catch(error){$('#compress-form .form-error').textContent=error.message;}
  finally{compressing=false;controls.forEach(c=>c.disabled=false);}
};
