"""Site-scoped filesystem operations, executed only after dropping to www-data."""
from contextlib import contextmanager
import os
import secrets
import stat

CHUNK_SIZE = 256 * 1024


def relative_path(value):
    if not isinstance(value, str) or len(value) > 2048 or '\x00' in value or '\\' in value:
        raise ValueError("目录路径无效")
    if value == '':
        return []
    parts = value.split('/')
    if any(p in ('', '.', '..') or len(p.encode('utf-8')) > 255 for p in parts):
        raise ValueError("只能访问当前网站目录，不允许跳转到上级目录")
    return parts


def file_name(value):
    parts = relative_path(value)
    if len(parts) != 1:
        raise ValueError("文件名不能包含目录或路径分隔符")
    return parts[0]


@contextmanager
def directory_fd(root, path):
    # No resolve()+open() race: every component is opened relative to a held fd,
    # with symlink following forbidden. root's parent belongs to root, not PHP.
    flags = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW
    fd = os.open(root, flags)
    try:
        for part in relative_path(path):
            child = os.open(part, flags, dir_fd=fd)
            os.close(fd)
            fd = child
        yield fd
    finally:
        os.close(fd)


def open_download(root, data):
    with directory_fd(root, data.get('path', '')) as folder:
        fd = os.open(file_name(data.get('name')), os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=folder)
    file = os.fdopen(fd, 'rb')
    info = os.fstat(file.fileno())
    if not stat.S_ISREG(info.st_mode):
        file.close()
        raise ValueError('仅支持下载普通文件，不支持链接或设备文件')
    return file, info.st_size


def copy_upload(source, target, size):
    if type(size) is not int or size < 0:
        raise ValueError('文件大小无效')
    remaining = size
    while remaining:
        chunk = source.read(min(CHUNK_SIZE, remaining))
        if not chunk:
            raise ValueError('上传连接中断，文件尚未完整接收')
        target.write(chunk)
        remaining -= len(chunk)


def operate(root, action, data):
    path = data.get('path', '')
    relative_path(path)
    try:
        with directory_fd(root, path) as folder:
            if action == 'files_list':
                result = []
                for name in os.listdir(folder):
                    try:
                        info = os.stat(name, dir_fd=folder, follow_symlinks=False)
                    except FileNotFoundError:
                        continue
                    kind = 'directory' if stat.S_ISDIR(info.st_mode) else 'file' if stat.S_ISREG(info.st_mode) else 'blocked'
                    result.append({'name': name, 'kind': kind, 'size': info.st_size, 'modified': info.st_mtime})
                    if len(result) > 5000:
                        raise ValueError("此目录超过 5000 个条目，请通过 SFTP 管理")
                result.sort(key=lambda x: (x['kind'] != 'directory', x['name'].casefold()))
                return {'path': path, 'entries': result, 'limit': None}
            name = file_name(data.get('name'))
            if action == 'files_mkdir':
                os.mkdir(name, mode=0o755, dir_fd=folder)
                return {'message': '文件夹已创建'}
            if action == 'files_upload':
                overwrite = data.get('overwrite', False)
                if type(overwrite) is not bool:
                    raise ValueError("覆盖选项无效")
                temporary = '.minipanel-upload-' + secrets.token_hex(12)
                fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o644, dir_fd=folder)
                try:
                    with os.fdopen(fd, 'wb') as file:
                        copy_upload(data['_stream'], file, data['size'])
                        file.flush()
                        os.fsync(file.fileno())
                    if overwrite:
                        try:
                            existing = os.stat(name, dir_fd=folder, follow_symlinks=False)
                        except FileNotFoundError:
                            existing = None
                        if existing and not stat.S_ISREG(existing.st_mode):
                            raise ValueError("不能覆盖目录、符号链接或特殊文件")
                        # rename replaces the entry itself, never follows its target.
                        os.replace(temporary, name, src_dir_fd=folder, dst_dir_fd=folder)
                    else:
                        # Atomic create-if-absent, so a concurrent upload cannot overwrite.
                        os.link(temporary, name, src_dir_fd=folder, dst_dir_fd=folder, follow_symlinks=False)
                    return {'message': '文件上传完成'}
                finally:
                    try:
                        os.unlink(temporary, dir_fd=folder)
                    except FileNotFoundError:
                        pass
            raise ValueError("不支持的文件操作")
    except FileExistsError:
        raise ValueError("同名文件或目录已存在；如需替换文件，请勾选覆盖") from None
    except FileNotFoundError:
        raise ValueError("文件或目录不存在，请刷新后重试") from None
    except (NotADirectoryError, PermissionError):
        raise ValueError("无法访问此目录或文件：请检查权限，不允许访问符号链接") from None
    except OSError as error:
        if error.errno == 40:  # ELOOP, symlink with O_NOFOLLOW
            raise ValueError("不允许访问符号链接") from None
        raise


def drop_privileges():
    import pwd
    account = pwd.getpwnam('www-data')
    os.setgroups([])
    os.setgid(account.pw_gid)
    os.setuid(account.pw_uid)
