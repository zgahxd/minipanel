"""Runtime UI fixture; never modifies the host or contacts package repositories."""
import secrets
import time
from runtime_manager import PHP_BRANCHES, branch


def demo_runtime(backend, action, data):
    if not hasattr(backend,'runtime_versions'):
        backend.runtime_versions={'nginx':'1.22.1-demo','mysql-community-server':'8.4.0-demo','php8.2-fpm':'8.2.0-demo'} if backend.installed else {}
        backend.runtime_plan=None;backend.runtime_result=None
    packages=['nginx','mysql-community-server','redis-server']+['php'+v+'-fpm' for v in PHP_BRANCHES]
    available={p:('1.22.2-demo' if p=='nginx' else '8.4.1-demo' if p=='mysql-community-server' else '7.0.1-demo' if p=='redis-server' else p[3:-4]+'.99-demo') for p in packages}
    if action=='runtime_inventory':
        return {'packages':[{'name':p,'installed':backend.runtime_versions.get(p),'versions':[{'version':available[p],'source':'本地模拟软件源'}]} for p in packages],
                'php_installed':[v for v in PHP_BRANCHES if 'php'+v+'-fpm' in backend.runtime_versions],
                'php_modules':[], 'updates':getattr(backend,'update_state',{}),'plan':backend.runtime_plan,'last_result':backend.runtime_result,'timer_active':False}
    if action in ('check_updates','php_repository'):
        backend.update_state={'checked':time.time(),'packages':[{'name':p,'installed':old,'candidate':available[p],'migration_required':False} for p,old in backend.runtime_versions.items() if old!=available.get(p)],'error':'','message':'演示检查完成，未查询真实软件源','unsupported_php':[]}
        return {'message':'演示检查完成'}
    if action=='runtime_plan':
        kind=data.get('kind');package={'nginx':'nginx','mysql':'mysql-community-server','redis':'redis-server'}.get(kind)
        if kind=='php':package='php'+branch(data.get('php'))+'-fpm'
        targets={p:available[p] for p in backend.runtime_versions} if kind=='updates' else {package:data.get('version')}
        if any(p not in available or available[p]!=v for p,v in targets.items()):raise ValueError('版本无效')
        backend.runtime_plan={'id':secrets.token_hex(16),'created':time.time(),'kind':kind,'targets':targets,'changes':[{'name':p,'from':backend.runtime_versions.get(p),'to':v} for p,v in targets.items()],'message':'本地演示，不安装真实软件'}
        return {'message':'演示计划已生成'}
    if action=='runtime_apply':
        if not backend.runtime_plan or backend.runtime_plan['id']!=data.get('id') or data.get('backup_ack') is not True:raise ValueError('请确认更新计划和备份')
        backend.runtime_versions.update(backend.runtime_plan['targets']);backend.runtime_plan=None
        backend.runtime_result={'status':'success','finished':time.time()}
        return {'message':'演示更新完成，没有修改系统'}
    if action=='site_php':
        v=branch(data.get('php'))
        if 'php'+v+'-fpm' not in backend.runtime_versions:raise ValueError('请先安装目标 PHP')
        site=next((s for s in backend.sites if s['domain']==data.get('domain')),None)
        if not site:raise ValueError('网站不存在')
        site['php']=v
        return {'message':'演示网站 PHP 已切换'}
    if action=='runtime_service':return {'message':'演示服务操作完成'}
    if action=='mysql_migration':
        return {'source':'8.4-demo','target':data.get('target'),'databases':backend.databases,
                'steps':['在独立实例安装目标版本，检查兼容性。','暂停写入并导出数据；在目标库导入验收。','切换应用连接，保留旧实例用于经核验的回退。'],
                'warning':'迁移清单不会自动迁移现有数据库。'}
    raise ValueError('演示操作无效')
