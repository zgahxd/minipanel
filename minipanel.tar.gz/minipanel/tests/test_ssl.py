import copy
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch

import test_panel
import helper
import ssl_manager as ssl
from common import nginx_config


def result(stdout='', code=0, stderr=''):
    return SimpleNamespace(stdout=stdout, returncode=code, stderr=stderr)


class CertificateTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.base = Path(self.tmp.name)
        for name, value in [('ACME', self.base/'acme'), ('PANEL_CERT', self.base/'tls.crt'), ('PANEL_KEY', self.base/'tls.key')]:
            p = patch.object(ssl, name, value); p.start(); self.addCleanup(p.stop)
        ssl.PANEL_CERT.write_bytes(b'old certificate')
        ssl.PANEL_KEY.write_bytes(b'original key')
        self.records = {}
        self.calls = []
        self.due = True
        self.fail_generation = False
        self.reload_failures = 0

    def read(self, name, default):
        return copy.deepcopy(self.records.get(name, default))

    def write(self, name, value):
        self.records[name] = copy.deepcopy(value)

    def fake_run(self, args, **kwargs):
        self.calls.append(args)
        if '-subject' in args:
            return result('subject=CN=MiniPanel\nissuer=CN=MiniPanel\n')
        if '-ext' in args:
            return result('X509v3 Subject Alternative Name:\n    DNS:localhost, IP Address:127.0.0.1, IP Address:203.0.113.9\n')
        if '-checkend' in args and str(ssl.PANEL_CERT) in args:
            return result(code=int(self.due))
        if 'req' in args:
            if self.fail_generation:
                raise RuntimeError('openssl failed')
            Path(args[args.index('-out')+1]).write_bytes(b'new certificate')
        if args == ['systemctl', 'reload', 'minipanel'] and self.reload_failures:
            self.reload_failures -= 1
            raise RuntimeError('reload failed')
        return result()

    def test_panel_renews_due_certificate_retains_key_and_san(self):
        status = ssl.renew_panel_certificate(self.fake_run, self.read, self.write)
        self.assertFalse(status['error']); self.assertFalse(status['deployment_pending'])
        self.assertEqual(ssl.PANEL_CERT.read_bytes(), b'new certificate')
        self.assertEqual(ssl.PANEL_KEY.read_bytes(), b'original key')
        command = next(c for c in self.calls if 'req' in c)
        self.assertIn('subjectAltName=DNS:localhost,IP:127.0.0.1,IP:203.0.113.9', command)
        self.assertIn(['systemctl', 'reload', 'minipanel'], self.calls)
        self.assertEqual(list(self.base.glob('.tls-renew-*')), [])

    def test_panel_not_due_skips_generation_and_reload(self):
        self.due = False
        ssl.renew_panel_certificate(self.fake_run, self.read, self.write)
        self.assertFalse(any('req' in c or 'reload' in c for c in self.calls))
        self.assertIn(['openssl', 'x509', '-in', str(ssl.PANEL_CERT), '-noout', '-checkend', '2592000'], self.calls)

    def test_foreign_certificate_is_preserved(self):
        def run(args, **kwargs):
            return result('subject=CN=Custom\nissuer=CN=Trusted CA\n')
        status = ssl.renew_panel_certificate(run, self.read, self.write)
        self.assertFalse(status['auto_renew'])
        self.assertEqual(ssl.PANEL_CERT.read_bytes(), b'old certificate')

    def test_claimed_minipanel_identity_requires_valid_self_signature(self):
        def run(args, **kwargs):
            return result(code=1) if 'verify' in args else self.fake_run(args, **kwargs)
        self.assertFalse(ssl.managed_panel_certificate(run))

    def test_panel_generation_failure_preserves_certificate(self):
        self.fail_generation = True
        status = ssl.renew_panel_certificate(self.fake_run, self.read, self.write)
        self.assertIn('openssl failed', status['error'])
        self.assertEqual(ssl.PANEL_CERT.read_bytes(), b'old certificate')

    def test_panel_failed_reload_rolls_back_and_retries_next_check(self):
        self.reload_failures = 1
        status = ssl.renew_panel_certificate(self.fake_run, self.read, self.write)
        self.assertIn('reload failed', status['error'])
        self.assertEqual(ssl.PANEL_CERT.read_bytes(), b'old certificate')
        status = ssl.renew_panel_certificate(self.fake_run, self.read, self.write)
        self.assertFalse(status['error'])
        self.assertEqual(ssl.PANEL_CERT.read_bytes(), b'new certificate')

    def test_pending_panel_reload_is_recovered_after_interruption(self):
        self.records['panel-renewal.json'] = {'deployment_pending': True}
        self.due = False
        status = ssl.renew_panel_certificate(self.fake_run, self.read, self.write)
        self.assertFalse(status['deployment_pending'])
        self.assertIn(['systemctl', 'reload', 'minipanel'], self.calls)

    def make_domain_cert(self):
        cert = ssl.ACME/'live/example.com/fullchain.pem'
        cert.parent.mkdir(parents=True)
        cert.write_bytes(b'old')
        return cert

    def test_domain_unchanged_skips_nginx_reload_and_does_not_force_renew(self):
        self.make_domain_cert()
        status = ssl.renewal_check(self.fake_run, self.read, self.write)
        self.assertFalse(status['error'])
        self.assertFalse(any('reload' in c for c in self.calls))
        command = self.calls[0]
        self.assertIn('renew', command)
        self.assertNotIn('--force-renewal', command)

    def test_domain_successful_renewal_reloads_nginx(self):
        cert = self.make_domain_cert()
        def run(args, **kwargs):
            if 'renew' in args:
                cert.write_bytes(b'new')
            return self.fake_run(args, **kwargs)
        status = ssl.renewal_check(run, self.read, self.write)
        self.assertFalse(status['error']); self.assertFalse(status['deployment_pending'])
        self.assertIn(['nginx', '-t'], self.calls)
        self.assertIn(['systemctl', 'reload', 'nginx'], self.calls)

    def test_domain_nginx_failure_retries_deployment_without_another_certificate_change(self):
        cert = self.make_domain_cert()
        def run(args, **kwargs):
            if 'renew' in args:
                cert.write_bytes(b'new')
            if args == ['nginx', '-t']:
                raise RuntimeError('invalid unrelated nginx configuration')
            return self.fake_run(args, **kwargs)
        status = ssl.renewal_check(run, self.read, self.write)
        self.assertTrue(status['deployment_pending']); self.assertTrue(status['error'])
        status = ssl.renewal_check(self.fake_run, self.read, self.write)
        self.assertFalse(status['deployment_pending']); self.assertFalse(status['error'])
        self.assertIn(['systemctl', 'reload', 'nginx'], self.calls)

    def test_partial_certbot_failure_deploys_successes_and_reports_error(self):
        cert = self.make_domain_cert()
        def run(args, **kwargs):
            if 'renew' in args:
                cert.write_bytes(b'new')
                return result(code=1, stderr='another domain failed')
            return self.fake_run(args, **kwargs)
        status = ssl.renewal_check(run, self.read, self.write)
        self.assertIn('another domain failed', status['error'])
        self.assertIn(['systemctl', 'reload', 'nginx'], self.calls)

    def test_timer_checks_panel_even_without_domain_certificates(self):
        ssl.renewal_check(self.fake_run, self.read, self.write, include_panel=True)
        self.assertEqual(ssl.PANEL_CERT.read_bytes(), b'new certificate')
        self.assertIn('panel-renewal.json', self.records)

    def test_domain_check_continues_after_panel_failure(self):
        self.make_domain_cert(); self.fail_generation = True
        status = ssl.renewal_check(self.fake_run, self.read, self.write, include_panel=True)
        self.assertIn('openssl failed', status['panel_error'])
        self.assertFalse(status['error'])
        self.assertTrue(any('renew' in c for c in self.calls))

    def test_registration_requires_explicit_terms_and_email(self):
        for data in ({}, {'email':'a@example.com'}, {'email':'bad','agree_tos':True}, {'email':'a@example.com','agree_tos':'yes'}):
            with self.assertRaises(ValueError):
                ssl.validate_registration(data)
        self.assertEqual(ssl.validate_registration({'email':'a@example.com','agree_tos':True}), 'a@example.com')

    def test_http_challenge_survives_force_https_and_pause(self):
        for enabled in (True, False):
            config = nginx_config('example.com','8.2',ssl=True,force_https=True,enabled=enabled,root='/srv/cloud',cert_type='letsencrypt')
            self.assertEqual(config.count('location ^~ /.well-known/acme-challenge/'),2 if enabled else 1)
            if enabled:
                self.assertIn('location / { return 308',config)
            self.assertIn((ssl.ACME/'live/example.com/fullchain.pem').as_posix(),config)
            self.assertIn('location / { return 503; }' if not enabled else 'root /srv/cloud;',config)

    def test_failed_issuance_restores_previous_site_configuration(self):
        available = self.base/'available'; available.mkdir()
        (available/'mp-example.com.conf').write_text('old nginx config')
        sites = [{'domain':'example.com','php':'8.2','enabled':True,'ssl':False,'root':'/srv/cloud'}]
        with patch.object(helper,'AVAILABLE',available), patch.object(helper,'read_json',return_value=sites), patch.object(helper,'write_json') as save, patch.object(helper,'apply_site') as apply, patch.object(helper,'issue',side_effect=RuntimeError('DNS validation failed')), patch.object(ssl,'WEBROOT',self.base/'webroot'):
            with self.assertRaisesRegex(RuntimeError,'DNS validation failed'):
                helper.configure_ssl({'domain':'example.com','ssl':True,'force_https':True,'cert_type':'letsencrypt','email':'a@example.com','agree_tos':True})
            self.assertEqual(apply.call_args.args,('example.com','old nginx config',True))
            save.assert_not_called()
            self.assertFalse(sites[0]['ssl'])


if __name__ == '__main__':
    unittest.main()
