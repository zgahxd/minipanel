import copy
import io
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch
import zipfile

import test_panel
import helper
import ssl_manager
from common import nginx_config, rewrite_rules


class ManagementAPITests(unittest.TestCase):
    setUp = test_panel.PanelTests.setUp
    request = test_panel.PanelTests.request
    login = test_panel.PanelTests.login

    def test_new_routes_require_auth_and_csrf(self):
        for path in ('sites/delete','sites/rewrite','databases/delete','databases/import','php/extensions','php/sourceguardian'):
            self.assertEqual(self.request('/api/'+path,{})['status'],401)
        self.assertEqual(self.request('/api/databases/export',QUERY_STRING='name=demo')['status'],401)
        self.login()
        for path in ('sites/delete','sites/rewrite','databases/delete','databases/import','php/extensions','php/sourceguardian'):
            self.assertEqual(self.request('/api/'+path,{},HTTP_X_CSRF_TOKEN='wrong')['status'],403)

    def test_delete_site_keeps_content_and_other_sites(self):
        self.login(); self.app.backend.installed=True
        for domain in ('a.example.com','b.example.com'):
            self.request('/api/sites',{'domain':domain,'root':'/srv/'+domain})
        self.request('/api/files/create',{'scope':'system','path':'/srv/a.example.com','name':'keep.txt'})
        self.assertEqual(self.request('/api/sites/delete',{'domain':'a.example.com','confirm':'wrong'})['status'],400)
        self.assertEqual(self.request('/api/sites/delete',{'domain':'a.example.com','confirm':'a.example.com'})['status'],200)
        self.assertEqual([s['domain'] for s in self.app.backend.sites],['b.example.com'])
        self.assertEqual(self.request('/api/files/download',QUERY_STRING='scope=system&path=/srv/a.example.com&name=keep.txt')['status'],200)

    def test_import_export_and_delete_database(self):
        self.login(); self.app.backend.installed=True
        self.request('/api/databases',{'name':'cloud_app'})
        sql=b'CREATE TABLE demo (id INT);\nINSERT INTO demo VALUES (1);\n'
        args={'QUERY_STRING':'name=cloud_app&confirm=cloud_app','CONTENT_TYPE':'application/octet-stream'}
        self.assertEqual(self.request('/api/databases/import',sql,**dict(args,QUERY_STRING='name=cloud_app&confirm=wrong'))['status'],400)
        self.assertEqual(self.request('/api/databases/import',sql,**args)['status'],200)
        exported=self.request('/api/databases/export',QUERY_STRING='name=cloud_app')
        self.assertEqual(exported['body'],sql)
        self.assertIn('attachment;',exported['headers']['Content-Disposition'])
        self.assertEqual(self.request('/api/databases/delete',{'name':'cloud_app','confirm':'wrong'})['status'],400)
        self.assertEqual(self.request('/api/databases/delete',{'name':'cloud_app','confirm':'cloud_app'})['status'],200)
        self.assertEqual(self.request('/api/databases/export',QUERY_STRING='name=cloud_app')['status'],400)

    def test_rewrite_preserved_by_toggle_root_and_ssl(self):
        self.login(); self.app.backend.installed=True
        domain='example.com'; self.request('/api/sites',{'domain':domain})
        rules='try_files $uri $uri/ =404;'
        self.assertEqual(self.request('/api/sites/rewrite',{'domain':domain,'rewrite':rules})['status'],200)
        self.request('/api/sites/toggle',{'domain':domain,'enabled':False})
        self.request('/api/sites/root',{'domain':domain,'root':'/srv/cloud'})
        self.request('/api/sites/ssl',{'domain':domain,'ssl':False,'force_https':False})
        self.assertEqual(self.app.backend.sites[0]['rewrite'],rules)
        self.assertEqual(self.request('/api/sites/rewrite',{'domain':domain,'rewrite':'include /etc/passwd;'})['status'],400)
        self.assertEqual(self.app.backend.sites[0]['rewrite'],rules)

    def test_sourceguardian_requires_explicit_terms(self):
        self.login()
        for agreed in (None,False,'true',1):
            self.assertEqual(self.request('/api/php/sourceguardian',{'agree_tos':agreed})['status'],400)
        self.assertFalse(self.app.operation.locked())
        self.assertEqual(self.request('/api/install',{'sourceguardian':True})['status'],400)
        self.assertFalse(self.app.backend.installed)

    def test_stack_job_passes_sourceguardian_selection(self):
        self.login()
        with patch('app.threading.Thread') as thread:
            self.assertEqual(self.request('/api/install',{'sourceguardian':True,'agree_tos':True})['status'],200)
        args=thread.call_args.kwargs['args']
        self.assertEqual(args,('install',{'sourceguardian':True,'agree_tos':True}))
        self.app.operation.release()


class ManagementHelperTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
        self.base=Path(self.tmp.name)
        for name in ('STATE','AVAILABLE','ENABLED'):
            path=self.base/name; path.mkdir()
            patcher=patch.object(helper,name,path);patcher.start();self.addCleanup(patcher.stop)
        (helper.STATE/'mysql-managed').touch()
        helper.write_json('databases.json',[{'name':'cloud_app','username':'cloud_app','host':'127.0.0.1'}])
        helper.write_json('sites.json',[{'domain':'example.com','php':'8.2','enabled':True,'root':'/srv/cloud'}])
        self.config=helper.AVAILABLE/'mp-example.com.conf';self.config.write_text('original nginx config')

    def test_delete_site_nginx_failure_restores_config_and_record(self):
        with patch.object(helper,'run',side_effect=[RuntimeError('nginx failed'),None]):
            with self.assertRaisesRegex(RuntimeError,'nginx failed'):
                helper.delete_site({'domain':'example.com','confirm':'example.com'})
        self.assertEqual(self.config.read_text(),'original nginx config')
        self.assertEqual(len(helper.read_json('sites.json',[])),1)

    def test_delete_site_only_removes_config_and_record(self):
        other=helper.AVAILABLE/'other.conf';other.write_text('keep')
        with patch.object(helper,'run') as run:
            helper.delete_site({'domain':'example.com','confirm':'example.com'})
        self.assertFalse(self.config.exists()); self.assertEqual(other.read_text(),'keep')
        self.assertEqual(helper.read_json('sites.json',[]),[])
        self.assertEqual(run.call_args_list[0].args[0],['nginx','-t'])

    def test_rewrite_apply_failure_preserves_metadata(self):
        with patch.object(helper,'apply_site',side_effect=RuntimeError('bad rule')):
            with self.assertRaises(RuntimeError):helper.configure_rewrite({'domain':'example.com','rewrite':'rewrite ^ /x invalidflag;'})
        self.assertNotIn('rewrite',helper.read_json('sites.json',[])[0])

    def test_rewrite_state_write_failure_rolls_back(self):
        with patch.object(helper,'apply_site') as apply,patch.object(helper,'write_json',side_effect=OSError('full')):
            with self.assertRaises(OSError):helper.configure_rewrite({'domain':'example.com','rewrite':'try_files $uri =404;'})
        self.assertEqual(apply.call_args_list[-1].args,('example.com','original nginx config',True))

    def test_delete_database_confirmation_and_partial_failure(self):
        with patch.object(helper,'run') as run:
            with self.assertRaises(ValueError):helper.delete_database({'name':'cloud_app','confirm':'wrong'})
            run.assert_not_called()
        with patch.object(helper,'run',side_effect=[None,RuntimeError('user drop failed')]):
            with self.assertRaisesRegex(RuntimeError,'记录保留'):helper.delete_database({'name':'cloud_app','confirm':'cloud_app'})
        self.assertEqual(len(helper.read_json('databases.json',[])),1)

    def test_export_failure_never_returns_partial_backup(self):
        def fake_run(command,**kw):
            kw['stdout'].write(b'partial');kw['stderr'].write(b'dump error')
            return SimpleNamespace(returncode=1)
        with patch.object(helper.subprocess,'run',side_effect=fake_run):
            with self.assertRaisesRegex(RuntimeError,'未提供不完整备份'):helper.export_database({'name':'cloud_app'})

    def test_export_is_streamed_and_includes_database_objects(self):
        def fake_run(command,**kw):
            self.assertEqual(command[-1],'cloud_app');self.assertIn('--routines',command);self.assertIn('--triggers',command)
            self.assertIn('--single-transaction',command);kw['stdout'].write(b'backup SQL')
            return SimpleNamespace(returncode=0)
        with patch.object(helper.subprocess,'run',side_effect=fake_run):
            file,size=helper.export_database({'name':'cloud_app'})
            with file:self.assertEqual(file.read(),b'backup SQL');self.assertEqual(size,10)

    def test_import_incomplete_upload_never_executes_sql(self):
        with patch.object(helper,'run') as run:
            with self.assertRaises(ValueError):helper.import_database({'name':'cloud_app','confirm':'cloud_app','size':20,'_stream':io.BytesIO(b'few')})
            run.assert_not_called()

    def test_import_uses_scoped_user_blocks_client_commands_and_cleans_up_after_failure(self):
        commands=[]
        def fake_root(args,**kw):commands.append(kw.get('data',''))
        def fake_import(args,**kw):
            self.assertNotIn('-uroot',args);self.assertIn('--binary-mode=1',args);self.assertIn('--local-infile=0',args)
            self.assertNotIn('password=',str(args));self.assertTrue(args[1].startswith('--defaults-file='))
            self.assertEqual(kw['stdin'].read(),b'SQL')
            kw['stderr'].write(b'cross-database denied')
            return SimpleNamespace(returncode=1)
        with patch.object(helper,'run',side_effect=fake_root),patch.object(helper.subprocess,'run',side_effect=fake_import):
            with self.assertRaisesRegex(RuntimeError,'不能自动回滚'):
                helper.import_database({'name':'cloud_app','confirm':'cloud_app','size':3,'_stream':io.BytesIO(b'SQL')})
        self.assertIn('`cloud\\_app`.*',commands[1]);self.assertTrue(commands[-1].startswith('DROP USER IF EXISTS'))
        self.assertEqual(list(helper.STATE.glob('db-import-*')),[])

    def test_unmanaged_and_injected_database_names_rejected(self):
        with patch.object(helper,'run') as run:
            for name in ('mysql','other','cloud_app; DROP USER root','../cloud_app'):
                with self.assertRaises(ValueError):helper.export_database({'name':name})
            run.assert_not_called()

    def test_deleted_domain_not_renewed(self):
        acme=self.base/'acme'; cert=acme/'live/example.com/fullchain.pem';cert.parent.mkdir(parents=True);cert.write_bytes(b'cert')
        helper.write_json('sites.json',[])
        with patch.object(ssl_manager,'ACME',acme),patch.object(helper,'run') as run:
            ssl_manager.renewal_check(run,helper.read_json,helper.write_json)
            self.assertFalse(any('renew' in c.args[0] for c in run.call_args_list))


class RewriteAndExtensionTests(unittest.TestCase):
    def test_rewrite_injection_and_duplicate_directives_rejected(self):
        for rules in ('location / { return 200; }','include /etc/passwd;','rewrite ^ /; include /tmp/x;', 'try_files $uri =404;\ntry_files\t$uri =403;', 'rewrite ^ /x', 'rewrite ^ /x; # inline'):
            with self.assertRaises(ValueError):rewrite_rules(rules)
        self.assertIn('try_files',rewrite_rules(''))

    def test_paused_site_still_validates_rewrite_without_serving_it(self):
        rules='rewrite ^ /index.php last;\ntry_files $uri =404;'
        config=nginx_config('example.com','8.2',enabled=False,rewrite=rules)
        self.assertIn('location / { return 503; }',config)
        self.assertIn('location @minipanel_rewrite_validation',config)
        self.assertIn('rewrite ^ /index.php last;',config)

    def test_extension_status_checks_fpm_not_cli(self):
        with patch.object(helper,'php_version',return_value='8.2'),patch.object(helper,'run',return_value=SimpleNamespace(stdout='[PHP Modules]\nfileinfo\nredis\nSourceGuardian\n[Zend Modules]\nZend OPcache\n',stderr='',returncode=0)) as run:
            status=helper.php_module_status()
        run.assert_called_once_with(['php-fpm8.2','-m'],check=False)
        modules={m['name']:m['loaded'] for m in status['modules']}
        self.assertTrue(all(modules[n] for n in ('OPcache','fileinfo','Redis','SourceGuardian')))
        self.assertFalse(modules['intl'])

    def test_loader_selects_matching_version_and_rejects_invalid_binary(self):
        elf=bytearray(64);elf[:6]=b'\x7fELF\x02\x01';elf[18:20]=b'\x3e\x00'
        for content,ok in ((bytes(elf),True),(b'not an ELF file',False)):
            stream=io.BytesIO()
            with zipfile.ZipFile(stream,'w') as z:
                z.writestr('ixed.8.2.lin',content);z.writestr('ixed.8.4.lin',b'other');z.writestr('../../escape',b'bad')
            if ok:self.assertEqual(helper.sourceguardian_payload(stream.getvalue(),'8.2'),bytes(elf))
            else:
                with self.assertRaises(RuntimeError):helper.sourceguardian_payload(stream.getvalue(),'8.2')
            with self.assertRaises(RuntimeError):helper.sourceguardian_payload(stream.getvalue(),'8.3')

    def test_sourceguardian_no_download_without_terms(self):
        with patch.object(helper.urllib.request,'urlopen') as download:
            with self.assertRaises(ValueError):helper.install_sourceguardian({})
            download.assert_not_called()
        with patch.object(helper,'stream') as install:
            with self.assertRaises(ValueError):helper.install_stack({'sourceguardian':True})
            install.assert_not_called()

    def test_sourceguardian_failed_load_restores_ini(self):
        with tempfile.TemporaryDirectory() as tmp:
            base=Path(tmp);ini=base/'etc/php/8.2/fpm/conf.d/00-minipanel-sourceguardian.ini'
            ini.parent.mkdir(parents=True);ini.write_text('; previous')
            status={'modules':[{'name':'SourceGuardian','loaded':False}],'error':''}
            response=io.BytesIO(b'fake zip');response.geturl=lambda:'https://www.sourceguardian.com/loaders/download/loaders.linux-x86_64.zip'
            def path(value):return base/str(value).lstrip('/')
            with patch.object(helper,'Path',side_effect=path),patch.object(helper,'php_version',return_value='8.2'),patch.object(helper,'os_release',return_value={'ID':'debian'}),patch.object(helper,'run',return_value=SimpleNamespace(stdout='amd64')),patch.object(helper,'php_module_status',return_value=status),patch.object(helper.urllib.request,'urlopen',return_value=response),patch.object(helper,'sourceguardian_payload',return_value=b'fake ELF'):
                with self.assertRaisesRegex(RuntimeError,'加载检查失败'):helper.install_sourceguardian({'agree_tos':True})
            self.assertEqual(ini.read_text(),'; previous')
