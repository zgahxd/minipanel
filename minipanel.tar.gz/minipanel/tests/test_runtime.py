import copy
import io
import json
import os
from pathlib import Path
import tarfile
import tempfile
import time
from types import SimpleNamespace
import unittest
from unittest.mock import patch
import zipfile

import test_panel
import file_manager as fm
import runtime_manager as rm


class CompressionTests(unittest.TestCase):
    def test_roundtrip_both_formats_large_file_unicode_empty_directory(self):
        payload=b'abcdef'*100000
        for fmt in ('zip','tar.gz'):
            data=io.BytesIO()
            fm.write_compressed(data,fmt,[('empty',True,0,None),('中文.txt',False,len(payload),io.BytesIO(payload))])
            data.seek(0)
            if fmt=='zip':
                with zipfile.ZipFile(data) as archive:
                    self.assertEqual(archive.read('中文.txt'),payload)
                    self.assertTrue(archive.getinfo('empty/').is_dir())
            else:
                with tarfile.open(fileobj=data) as archive:
                    self.assertEqual(archive.extractfile('中文.txt').read(),payload)
                    self.assertTrue(archive.getmember('empty').isdir())

    def test_invalid_selection_and_output(self):
        for names,name,fmt in [([], 'x.zip','zip'),(['../secret'],'x.zip','zip'),(['x'],'x','zip'),(['x.zip'],'x.zip','zip'),(['x','x'],'x.zip','zip')]:
            with self.assertRaises(ValueError):fm.compression_request(dict(names=names,name=name,format=fmt))

    @unittest.skipUnless(os.name=='posix','Linux descriptor operations')
    def test_native_no_overwrite_symlink_or_protected_descendant(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);(root/'source').mkdir();(root/'source/a').write_bytes(b'abc')
            request={'names':['source'],'name':'a.zip','format':'zip'}
            fm.compress_paths(tmp,request,lambda *args:None)
            original=(root/'a.zip').read_bytes()
            with self.assertRaises(ValueError):fm.compress_paths(tmp,request,lambda *args:None)
            self.assertEqual((root/'a.zip').read_bytes(),original)
            (root/'source/link').symlink_to('/etc/passwd')
            request['name']='b.zip'
            with self.assertRaises(OSError):fm.compress_paths(tmp,request,lambda *args:None)
            self.assertFalse((root/'b.zip').exists())
            self.assertFalse(list(root.glob('.minipanel-pack-*')))
            (root/'source/link').unlink()
            def deny(path,action):
                if path.endswith('/a'):raise ValueError('protected')
            with self.assertRaises(ValueError):fm.compress_paths(tmp,request,deny)
            self.assertFalse((root/'b.zip').exists())


class RuntimeAPITests(unittest.TestCase):
    setUp=test_panel.PanelTests.setUp
    request=test_panel.PanelTests.request
    login=test_panel.PanelTests.login

    def test_auth_csrf_all_new_routes(self):
        paths=['runtime/'+p for p in ('check','plan','apply','php-repository','site-php','migration','sg','service')]+['files/compress']
        for path in paths:self.assertEqual(self.request('/api/'+path,{})['status'],401)
        self.assertEqual(self.request('/api/runtime')['status'],401)
        self.login()
        for path in paths:self.assertEqual(self.request('/api/'+path,{},HTTP_X_CSRF_TOKEN='wrong')['status'],403)

    def test_demo_compress_keeps_source_and_refuses_overwrite(self):
        self.login();self.app.backend.installed=True
        self.request('/api/sites',{'domain':'example.com','root':'/srv/demo'})
        self.request('/api/files/create',{'scope':'system','path':'/srv/demo','name':'hello.txt'})
        data={'scope':'system','path':'/srv/demo','names':['hello.txt'],'name':'test.zip','format':'zip'}
        result=self.request('/api/files/compress',data)
        self.assertEqual(result['status'],200,result)
        download=self.request('/api/files/download',QUERY_STRING='scope=system&path=/srv/demo&name=test.zip')
        with zipfile.ZipFile(io.BytesIO(download['body'])) as archive:self.assertEqual(archive.read('hello.txt'),b'')
        self.assertEqual(self.request('/api/files/compress',data)['status'],400)
        self.assertEqual(self.request('/api/files/download',QUERY_STRING='scope=system&path=/srv/demo&name=hello.txt')['status'],200)


class RuntimePlanTests(unittest.TestCase):
    def setUp(self):
        self.state={};self.calls=[];self.current={'redis-tools':'7.0.1'}
        def run(args,**kw):
            self.calls.append(args)
            if args[0]=='dpkg':return SimpleNamespace(returncode=1,stdout='')
            if args[:2]==['apt-get','-s']:return SimpleNamespace(stdout='Inst redis-tools [7.0.1] (7.0.2 Debian:12 [amd64])\n')
            return SimpleNamespace(stdout='',returncode=0)
        self.h=SimpleNamespace(run=run,stream=lambda *a,**k:None,read_json=lambda key,default:copy.deepcopy(self.state.get(key,default)),write_json=lambda k,v:self.state.update({k:copy.deepcopy(v)}))
        self.broker=patch.object(rm,'broker',return_value=self.h);self.broker.start();self.addCleanup(self.broker.stop)
        self.installed=patch.object(rm,'installed_packages',side_effect=lambda:dict(self.current));self.installed.start();self.addCleanup(self.installed.stop)
        self.state['updates.json']={'checked':time.time(),'packages':[{'name':'redis-tools','candidate':'7.0.2','migration_required':False}]}

    def plan(self):rm.make_plan({'kind':'updates'});return self.state['runtime-plan.json']

    def test_parser_refuses_removal_and_invalid_version(self):
        for text in ('Remv php8.2-fpm [8.2.0]','Inst test (evil;cmd)'):
            with self.assertRaises(ValueError):rm.parse_simulation(text,{})

    def test_mysql_cross_series_and_downgrade_blocked(self):
        with self.assertRaises(ValueError):rm.guard_changes([{'name':'mysql-community-server','from':'8.0.40','to':'8.4.0'}])
        self.h.run=lambda *a,**k:SimpleNamespace(returncode=0)
        with self.assertRaises(ValueError):rm.guard_changes([{'name':'nginx','from':'1.24','to':'1.22'}])

    def test_stale_and_changed_plans_do_not_install(self):
        plan=self.plan();self.current['unrelated']='1.0'
        with self.assertRaises(ValueError):rm.apply_plan({'id':plan['id'],'backup_ack':True})
        self.current.pop('unrelated');self.state['runtime-plan.json']['created']=time.time()-1801
        with self.assertRaises(ValueError):rm.apply_plan({'id':plan['id'],'backup_ack':True})
        self.assertFalse(any('-y' in c for c in self.calls))

    def test_changed_repository_dependencies_require_new_review(self):
        plan=self.plan();self.h.run=lambda *a,**k:SimpleNamespace(returncode=1,stdout='Inst redis-tools [7.0.1] (7.0.3 Debian [amd64])')
        with self.assertRaises(ValueError):rm.apply_plan({'id':plan['id'],'backup_ack':True})
        self.assertIsNotNone(self.state['runtime-plan.json'])

    def test_failed_install_consumes_plan_and_records_partial_failure(self):
        plan=self.plan()
        def fail(*a,**k):raise RuntimeError('download failed')
        self.h.stream=fail
        with self.assertRaisesRegex(RuntimeError,'部分'):rm.apply_plan({'id':plan['id'],'backup_ack':True})
        self.assertIsNone(self.state['runtime-plan.json']);self.assertEqual(self.state['runtime-result.json']['status'],'failed')
        with self.assertRaises(ValueError):rm.apply_plan({'id':plan['id'],'backup_ack':True})

    def test_success_pins_packages_and_verifies_actual_version(self):
        plan=self.plan();executed=[]
        def install(args,**kw):executed.append(args);self.current['redis-tools']='7.0.2'
        self.h.stream=install
        rm.apply_plan({'id':plan['id'],'backup_ack':True})
        self.assertIn('redis-tools=7.0.2',executed[0]);self.assertEqual(self.state['runtime-result.json']['status'],'success')

    def test_source_and_service_require_explicit_confirmation(self):
        with self.assertRaises(ValueError):rm.enable_php_repository({})
        with self.assertRaises(ValueError):rm.service_action({'service':'redis-server','operation':'stop'})
        self.assertEqual(self.calls,[])

    def test_php85_plan_uses_builtin_opcache_but_keeps_redis(self):
        self.h.run=lambda *a,**k:SimpleNamespace(returncode=1,stdout='Inst php8.5-fpm (8.5.12 Sury [amd64])')
        requested=[]
        def available(packages):
            requested.extend(packages)
            return {p:'8.5.12' for p in packages}
        with patch.object(rm,'versions',return_value=[{'version':'8.5.12'}]),patch.object(rm,'candidates',side_effect=available):
            rm.make_plan({'kind':'php','php':'8.5','version':'8.5.12'})
        self.assertNotIn('php8.5-opcache',requested)
        self.assertIn('php8.5-redis',requested)
        self.assertIn('opcache',rm.php_extension_names('8.4'))


if __name__=='__main__':unittest.main()
