import os
from pathlib import Path
import tempfile
import unittest
from urllib.parse import urlencode

import test_panel
import file_manager as fm
from common import check_system_path


class CopyAPITests(unittest.TestCase):
    setUp = test_panel.PanelTests.setUp
    request = test_panel.PanelTests.request
    login = test_panel.PanelTests.login

    def upload(self, path, name, content):
        return self.request('/api/files/upload', content, QUERY_STRING=urlencode({'scope':'system','path':path,'name':name}), CONTENT_TYPE='application/octet-stream')

    def download(self, path, name):
        return self.request('/api/files/download', QUERY_STRING=urlencode({'scope':'system','path':path,'name':name}))

    def test_copy_nested_directory_and_file_keep_source_and_contents(self):
        self.login()
        self.request('/api/files/mkdir', {'scope':'system','path':'/tmp','name':'source'})
        self.request('/api/files/mkdir', {'scope':'system','path':'/tmp/source','name':'nested'})
        payload = b'cloud data' * 100000
        self.assertEqual(self.upload('/tmp/source/nested','a.bin',payload)['status'],200)
        data={'scope':'system','source':'/tmp/source','path':'/srv','name':'source'}
        self.assertEqual(self.request('/api/files/copy',data)['status'],200)
        self.assertEqual(self.download('/srv/source/nested','a.bin')['body'],payload)
        self.assertEqual(self.download('/tmp/source/nested','a.bin')['body'],payload)
        # A subsequent edit to the original must not change its independent copy.
        self.request('/api/files/delete',{'scope':'system','path':'/tmp/source/nested','name':'a.bin'})
        self.assertEqual(self.download('/srv/source/nested','a.bin')['body'],payload)
        self.assertEqual(self.request('/api/files/copy',dict(data,source='/srv/source/nested/a.bin',path='/tmp',name='a.bin'))['status'],200)
        self.assertEqual(self.download('/tmp','a.bin')['body'],payload)

    def test_conflict_and_descendant_do_not_overwrite(self):
        self.login()
        self.upload('/tmp','a.txt',b'original'); self.upload('/srv','a.txt',b'existing')
        data={'scope':'system','source':'/tmp/a.txt','path':'/srv','name':'a.txt'}
        self.assertEqual(self.request('/api/files/copy',data)['status'],400)
        self.assertEqual(self.download('/srv','a.txt')['body'],b'existing')
        self.assertEqual(self.request('/api/files/copy',dict(data,source='/tmp',path='/tmp',name='nested'))['status'],400)

    def test_copy_requires_login_csrf_and_valid_paths(self):
        data={'scope':'system','source':'/tmp/a.txt','path':'/srv','name':'a.txt'}
        self.assertEqual(self.request('/api/files/copy',data)['status'],401)
        self.login()
        self.assertEqual(self.request('/api/files/copy',data,HTTP_X_CSRF_TOKEN='bad')['status'],403)
        for source in ('/tmp/../etc/passwd','relative','/','/proc/meminfo','/etc/minipanel/tls.key'):
            self.assertEqual(self.request('/api/files/copy',dict(data,source=source))['status'],400)

    def test_recursive_copy_does_not_bypass_protected_paths(self):
        self.login()
        self.app.backend.directories[''].add('etc/minipanel')
        self.app.backend.files['']['etc/minipanel/auth.json']=b'private'
        data={'scope':'system','source':'/etc','path':'/tmp','name':'etc-copy'}
        self.assertEqual(self.request('/api/files/copy',data)['status'],400)
        self.assertNotIn('tmp/etc-copy/minipanel/auth.json',self.app.backend.files[''])

    def test_copy_to_website_from_system_folder(self):
        self.login(); self.app.backend.installed=True
        self.request('/api/sites',{'domain':'cloud.example.com','root':'/srv/cloud'})
        self.upload('/tmp','index.php',b'<?php echo 1;')
        self.upload('/srv/cloud','index.php',b'existing page')
        data={'scope':'site','domain':'cloud.example.com','source':'/tmp/index.php','path':'','name':'index.php'}
        # An existing page must never be overwritten by paste.
        self.assertEqual(self.request('/api/files/copy',data)['status'],400)
        data['name']='cloud.php'
        self.assertEqual(self.request('/api/files/copy',data)['status'],200)
        self.assertEqual(self.download('/srv/cloud','cloud.php')['body'],b'<?php echo 1;')


class NativeCopyTests(unittest.TestCase):
    @unittest.skipUnless(os.name == 'posix', 'Native no-follow copy requires Linux')
    def test_native_recursive_copy_and_link_rejection(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory); source=root/'source'; source.mkdir()
            (source/'nested').mkdir(); (source/'nested/file.txt').write_bytes(b'hello'*100000)
            target=root/'target'
            fm.copy_path(str(source),str(target),check_system_path)
            self.assertEqual((target/'nested/file.txt').read_bytes(),(source/'nested/file.txt').read_bytes())
            with self.assertRaises(ValueError): fm.copy_path(str(source),str(target),check_system_path)
            (source/'link').symlink_to('/etc/passwd')
            with self.assertRaises(ValueError): fm.copy_path(str(source),str(root/'blocked'),check_system_path)
            self.assertFalse((root/'blocked/link').exists())
            with self.assertRaises(ValueError): fm.copy_path(str(source),str(source/'inside'),check_system_path)


if __name__ == '__main__':
    unittest.main()
