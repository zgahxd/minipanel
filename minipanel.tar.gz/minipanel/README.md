# MiniPanel 0.6.0

面向个人服务器的轻量中文面板。直接安装在 **Debian 12 / 13，x86_64 / amd64** 上，打开 `https://服务器IP:8888` 登录后台使用。

## v0.6.0 更新

- 修复刷新时先闪现登录页面；会话检查失败显示重新连接，只有确认未登录时才显示登录表单。
- 网站新增删除域名配置（保留网站目录、证书和数据库）；删除后停止面板为该域名续期。
- 网站新增 URL Rewrite / 伪静态编辑与模板，Nginx 校验失败恢复原配置，暂停、SSL 和目录变更保留规则。
- MySQL 新增删除数据库及账号、SQL 导出和导入；删除/导入需确认目标库名。
- 常用 PHP 扩展明确安装并检查 PHP-FPM 加载状态；SG 可随环境一起安装，也可单独补装。
- 网站 SSL 表单只提供 Let’s Encrypt，移除“测试用途 · 不自动续期”自签名选项；已有证书保留到新证书成功申请。后台 IP 自签名自动换新继续保留。


## 已实现

- 管理员登录，随机初始密码，登录限流、CSRF 校验、HTTPS；面板设置中验证原密码后修改密码，并退出所有旧会话。
- 一键安装系统原生 **Nginx + PHP-FPM + MySQL 8.4 LTS**，使用 systemd 管理。
- 后台安装任务、实时日志、失败原因、服务状态与重启。
- 添加域名时可指定网站绝对目录；已有网站可修改目录，保留原文件与 SSL 设置；Nginx 校验失败回滚配置。
- 暂停 / 恢复网站；暂停时返回 503，保留文件。
- 创建 MySQL 数据库及同名独立用户，随机密码只在创建时返回。
- 从系统 / 浏览目录，支持路径跳转、返回、上一级，新建空文件/文件夹、上传、下载、选择、复制粘贴、解压和删除。
- 网站支持 Let’s Encrypt 申请与自动续期和“强制 HTTPS”开关；后台自签名证书到期前 30 天自动换新。
- PHP / Nginx 上传不设置固定大小上限，面板采用流式文件传输。

数据库确实是 Oracle MySQL，不是 MariaDB。没有 Docker 依赖。PHP 随 Debian 软件源使用默认版本，暂不支持多版本切换。

## 安装

推荐使用未安装其他面板、网站和数据库的 Debian 服务器。此版不是已有 aaPanel 的迁移工具。脚本遇到已有数据库会停止，避免覆盖数据。

1. 将 `minipanel.tar.gz` 上传至服务器，例如 `/tmp`。
2. 在服务器执行：

```bash
cd /tmp
tar -xzf minipanel.tar.gz
cd minipanel
sudo bash install.sh
```

安装脚本会安装面板运行依赖、创建低权限服务账号、配置权限受限的系统助手，启用开机自启动，并输出管理员账号和随机密码。重复执行保留现有管理员密码。

3. 云平台安全组和系统防火墙放行 **TCP 8888**；网站放行 **TCP 80**。如果已启用 UFW，可以执行 `sudo ufw allow 8888/tcp` 与 `sudo ufw allow 80/tcp`。脚本不会自动改变现有防火墙规则。
4. 浏览器访问 **`https://你的服务器公网IP:8888`**，账号为 `admin`，密码以安装输出为准。初始密码也保存在服务器 `/root/minipanel-login.txt`（仅 root 可读）。
5. 登录后点击 **一键安装环境**，等待日志显示成功。Nginx 与 PHP 使用 Debian 软件源；MySQL 使用官方 `mysql-8.4-lts` 软件源及签名校验。下载失败可以查看日志后重试。

如果使用解压后的源码文件夹，直接上传整个 `minipanel` 文件夹并执行其中的 `install.sh` 即可。GitHub 已为公开仓库，在线安装命令见仓库 README，不需要 Token。当前安装包版本为 v0.6.0。

### 原服务器升级

使用新版安装包重复执行 `sudo bash install.sh`。脚本更新 `/opt/minipanel` 程序和面板服务定义，保留已有认证配置、网站文件/记录、数据库数据/记录与证书。面板服务会短暂重启，已有登录需重新登录；不需要重装 Debian，也不需要重新添加网站。升级前建议自行保存重要网站与数据库备份。升级安装本身不执行环境安装或修改既有 Nginx 网站配置。

### 初始登录信息

安装完成后终端会显示账号与初始密码；登录后台的「安装日志」页也可查看仍有效的初始密码。修改密码后不再展示旧初始密码，自定义密码仍只保存散列，不显示在日志中。此信息不会写入环境安装任务日志或普通状态接口。

### 修改管理员密码

进入「面板设置」，填写原密码、新密码和确认密码。新密码长度可自定义（非空，最多 256 个字符），修改后所有旧登录失效。服务器仅保存密码散列，升级保留修改后的密码；`/root/minipanel-login.txt` 仍是安装时的初始信息，不会同步写入新密码。忘记密码可在服务器执行 `sudo python3 /opt/minipanel/reset-password.py`。

### 后台 HTTPS

安装时会生成服务器专属的自签名证书。首次访问可能出现不受信任 / 名称不匹配提示，安装输出包含证书 SHA256 指纹供你核对。正式使用可将自己的有效证书链与私钥分别替换到：

```text
/etc/minipanel/tls.crt
/etc/minipanel/tls.key
```

保留私钥权限 `root:minipanel 0640`，然后执行 `sudo systemctl restart minipanel`。如果证书对应域名，应使用 `https://该域名:8888` 访问。安装器生成的后台自签名证书有效期 365 天，到期前 30 天自动换新；外部证书不会自动替换。

后台独立于 Nginx 运行，因此网站环境尚未安装或重启 Nginx 时，面板仍可访问。生产入口强制 HTTPS；本地演示入口才使用 HTTP。

## 添加域名和网站

1. 在域名服务商处添加 A 记录，指向服务器公网 IPv4。
2. 面板 → 网站管理 → 添加网站，填写 `example.com`，不带协议、端口或路径。
3. 网站默认目录为 `/var/www/minipanel/example.com/public`，也可填写 `/srv/www/example/public` 或挂载数据盘上的目录；实际在哪块磁盘由 Linux 挂载位置决定。目录只允许英文、数字、点、下划线和短横线，不允许将系统敏感目录公开为网站。已有目录不覆盖内容、不递归修改权限，需确保 `www-data` 能读取、进入，上传写入还需要写权限。
4. 上传自己的首页后，移除自动生成的 `index.html`（如不再需要）。默认首页顺序是 `index.php`、`index.html`。
5. 访问 `http://example.com`。DNS 生效时间取决于域名服务商与缓存。

`www.example.com` 可独立添加并指定相同目录。已有网站点击「修改目录」可以变更指向，原文件保留，不自动搬移。域名绑定不等于注册域名，也不自动修改 DNS。

网站支持 PHP 及常见前端控制器路由 `try_files $uri $uri/ /index.php?$query_string`。本版暂不提供反向代理配置、FTP、备份或多个管理员。

### 网站文件管理

网站列表中点击网站目录即可直接进入。侧栏「文件管理」可以从系统 `/` 浏览目录，输入绝对路径跳转，并使用返回、上一级及路径导航。支持新建空文件和文件夹，多文件上传、选择下载、ZIP/TAR/TGZ 解压到新的目录，单项或多项删除。删除文件夹会递归删除内容，确认框显示完整路径，无回收站；途中失败可能已删除部分内容。上传默认不覆盖已有文件，勾选“覆盖同名文件”才会替换普通文件。

文件传输不设固定大小上限，服务端以 256 KiB 缓冲区流式读写；浏览器直接把下载写入下载流程，不在页面中生成整个文件的 Blob。磁盘容量、网速、浏览器和系统仍构成实际边界。中断上传会尽量清理临时文件，不支持断点续传；新建文件为空文件，暂不提供在线内容编辑。

文件管理是可信管理员功能。网站目录内操作仍使用 `www-data`；其他系统目录操作由 root 系统助手执行，不能将面板账号交给不可信的网站使用者。所有目录逐层禁止跟随符号链接；`/proc`、`/sys`、`/dev`、`/run` 虚拟目录不开放操作。面板程序、认证和状态文件不允许下载或修改；关键系统目录、活动网站根目录及其上级目录不能删除。新建在其他系统路径的文件通常归 root 所有，现有文件权限不会自动修复。

### 域名 SSL 与强制 HTTPS

网站与后台的证书独立管理：

- **网站域名**：网站 → SSL 设置 → 使用 Let’s Encrypt，填写邮箱并阅读/同意服务协议后保存。域名 A/AAAA 必须指向本机，公网 TCP 80 必须可达，HTTPS 放行 TCP 443。申请失败会保留原网站配置；已有自签名证书不会只因升级就自动变成可信证书，需要首次手动申请。
- **域名自动续期**：安装启用 `minipanel-renew.timer`，每天 00:00、12:00（服务器时区）各检查一次，附加最多 1 小时随机延迟。Certbot 按其续期窗口决定是否签发，未到窗口不会重复签发。新证书通过 `nginx -t` 后自动重新加载；失败记录原因并重试。强制 HTTPS 与暂停网站均保留 HTTP 验证路径。
- **后台 IP 自签名证书**：同一定时任务每天两次检查，剩余有效期不超过 30 天时换成新的 365 天证书，保留原 SAN 和私钥，重新加载后台。加载失败恢复原证书。浏览器仍会提示不受信任，新指纹会变化，后台会话可能需要重新登录。面板设置显示到期和检查结果；外部证书不自动覆盖。
- 网站表单不再提供创建自签名证书的选项；旧网站自签名证书保留，成功申请 Let’s Encrypt 后才切换。旧网站自签名仍不自动续期，建议切换为 Let’s Encrypt。后台 IP 自签名自动换新继续保留。

域名证书位于 `/etc/minipanel/acme`，自签名网站证书位于 `/etc/minipanel/sites-ssl`。不接管系统已有的 `/etc/letsencrypt`。

查看定时器与日志：

```bash
sudo systemctl list-timers minipanel-renew.timer
sudo journalctl -u minipanel-renew.service -n 100 --no-pager
```

如需立即检查网站和后台证书，可在没有安装/文件任务运行时执行 `sudo systemctl start minipanel-renew.service`。后台页面的「检查域名证书续期」只检查域名，避免从后台任务中重新加载自身。定时任务失败 1 小时后重试；停机期间遗漏的定时检查在开机后补做。

强制 HTTPS 可单独开关，未启用 SSL 时不能强制跳转。开启后除验证路径外 HTTP 308 跳转到同域名 HTTPS，保留路径与查询参数。暂停时正常网页返回 503。

### 文件复制与粘贴

选中文件或文件夹 → **复制** → 进入任意允许访问的目标目录 → **粘贴到此目录**。可以把子目录中的文件复制到上级目录、其他网站或其他磁盘；目录会递归复制，原文件保留。同名目标拒绝覆盖，也不合并已有文件夹。复制在服务器内流式进行，无需下载到电脑再上传；目标网站仍按 www-data 权限操作。单项最多 10000 个条目、64 层、20 分钟；中途失败可能保留部分目标目录，页面显示已完成数量。暂不提供剪切移动，也不支持从电脑资源管理器直接 Ctrl+V 上传。

### 网盘用途的上传配置

安装运行环境时，会为 PHP-FPM 写入 `/etc/php/版本/fpm/conf.d/99-minipanel-upload.ini`：

```ini
upload_max_filesize = 0
post_max_size = 0
max_execution_time = 0
max_input_time = -1
```

PHP 8.2 / 8.4 的 multipart 上传在 `upload_max_filesize = 0` 时不执行单文件大小限制；`post_max_size = 0` 取消 POST 大小上限（PHP 对某些内容类型有例外）。Nginx 配置 `client_max_body_size 0`。不把 PHP 的内存限制改为无限：网盘程序应流式处理文件，不能把整个大文件读入内存。

Nginx 的请求体及 FastCGI 无数据等待超时为 3600 秒，这不是整个文件的传输时长上限。网盘程序自己的上传限制、文件名/文件类型限制、CDN 限制、磁盘空间、配额和系统资源仍需独立配置。不要将“不设文件大小上限”理解为无限磁盘或永不超时。

网站文件采用 `www-data` 权限，适合单一可信管理员管理自己的站点，不提供多租户 / 不可信网站之间的隔离。

## MySQL 的使用

面板 → 数据库 → 创建数据库。保存弹窗中的账号与密码，然后在 PHP 程序中填写：

```text
主机：127.0.0.1
端口：3306
数据库：你创建的数据库名
用户：与数据库同名
密码：创建时生成的随机密码
```

用户只被授权访问对应的数据库，数据库端口只监听本机。Root 采用 Unix socket 身份验证，服务器上可以执行 `sudo mysql --no-defaults --protocol=socket -uroot`；面板不显示数据库 root 密码。

MySQL 数据保存在 `/var/lib/mysql`。不要删除它或盲目 purge 数据库软件包。安装源启用后，后续系统软件更新会受 MySQL 官方仓库影响；更新前应自行备份。

## 常用维护

```bash
# 面板状态 / 日志
sudo systemctl status minipanel
sudo journalctl -u minipanel -n 100 --no-pager

# 重启面板
sudo systemctl restart minipanel

# 查看数据库状态
sudo systemctl status mysql

# 检查 Nginx 配置
sudo nginx -t

# 重设面板密码（在上传的源码目录内运行）
sudo python3 reset-password.py
```

密码重设会重启面板、使旧会话失效。不要在环境安装任务运行中重启面板或更新源码；重启会中断同一服务中的安装子进程。APT 被中断时先检查 `sudo dpkg --audit`，按实际情况执行 `sudo dpkg --configure -a`，再重试安装。无法访问后台时先检查 8888 端口、安全组、systemd 日志和证书。

面板文件位置：

| 内容 | 路径 |
| --- | --- |
| 程序与静态文件（root 所有） | `/opt/minipanel` |
| 管理员密码哈希与后台证书 | `/etc/minipanel` |
| 面板任务日志 | `/var/lib/minipanel/last-job.json` |
| 系统助手状态（仅 root 可写） | `/var/lib/minipanel-system` |
| 网站配置 | `/etc/nginx/sites-available/mp-域名.conf` |
| 网站访问日志 | `/var/log/nginx/mp-域名.access.log` |
| MySQL 本地监听配置 | `/etc/mysql/mysql.conf.d/zz-minipanel.cnf` |
| MySQL 官方软件源 | `/etc/apt/sources.list.d/minipanel-mysql.list` |

## 本地演示与测试

演示支持 Windows / Linux 的 Python 3.11+，不需要安装第三方包：

```bash
python app.py --demo
```

终端会输出临时演示密码。打开 `http://127.0.0.1:8888`。演示中的安装、建站、数据库和 SSL 均为模拟，不会安装真实软件或写入系统配置；演示上传数据使用临时文件，进程退出后演示数据丢失。

```bash
python -m unittest discover -s tests -v
```

自动测试包含登录/退出、CSRF、域名与数据库名注入防护、安装互斥、模拟业务流程、配置回滚及数据库失败清理。Windows 上的 Linux 专属调用会使用替身。

**验证边界：这是一版可部署的初始实现，当前未在真实 Debian 12 / 13 服务器执行整套 APT 安装、systemd、MySQL、Nginx、PHP 请求链路验证。请先在空白测试服务器验收，不能把本地模拟测试视为已通过实机验证。**

## 参考与安装源

- [MySQL 官方 APT 安装说明](https://dev.mysql.com/doc/mysql-apt-repo-quick-guide/en/)
- [Debian 12 / bookworm 官方 MySQL 仓库元数据](https://repo.mysql.com/apt/debian/dists/bookworm/Release)
- [Debian 13 / trixie 官方 MySQL 仓库元数据](https://repo.mysql.com/apt/debian/dists/trixie/Release)
- [Nginx FastCGI 官方文档](https://nginx.org/en/docs/http/ngx_http_fastcgi_module.html)
- [PHP 上传配置](https://www.php.net/manual/en/ini.core.php#ini.upload-max-filesize)
- [PHP 8.4 上传实现：只在 upload_max_filesize 大于 0 时限制文件大小](https://github.com/php/php-src/blob/PHP-8.4/main/rfc1867.c)

2026-09-28 核对官方元数据时，Debian 13 的仓库架构为 amd64；本安装包因此明确限定 amd64。签名密钥从 MySQL 官方 HTTPS 地址获取，并仅通过此源的 `signed-by` 使用；不关闭 APT 的签名校验。

## v0.3 文件管理

- 文件和文件夹支持勾选、多选、全选和取消选择。可下载选中的普通文件；多个下载可能需要浏览器允许。
- “返回”回到上次浏览的目录；“上一级”返回父目录；点击路径可跳转到任意已显示的父目录。不能超出网站 public 根目录。
- 单选压缩包后点击“解压”，也可使用文件行里的解压按钮。支持 ZIP、TAR、TAR.GZ/TGZ、TAR.BZ2/TBZ2、TAR.XZ/TXZ。
- 解压到当前目录下的新文件夹，可填写文件夹名称，完成后自动进入。不覆盖已有目录或文件。RAR、7z 和加密压缩包暂不支持。
- 解压会先检查所有路径，拒绝路径穿越、符号链接、硬链接、设备、稀疏文件、重复路径和文件/目录冲突。实际文件写入仍以 www-data 身份、相对目录文件描述符及 O_NOFOLLOW 执行。
- 每包最多 10000 个条目、目录深度最多 64 层；解析和写入各最多 20 分钟。上传大小仍不设固定上限。会先检查声明的解压大小与可用磁盘空间；解压过程中磁盘不足或数据损坏时可能保留不完整的目标文件夹，错误提示会说明。
- 已装服务器重新执行新版安装命令会更新面板代码、重启面板服务，保留账号配置、网站及数据库。正在上传或解压时不要升级。

## PHP 扩展与 SourceGuardian

新安装环境包含 OPcache、fileinfo、Redis、bcmath、intl、mysqli/PDO MySQL、curl、mbstring、XML、ZIP、GD。fileinfo 由 PHP common 提供；面板读取 **PHP-FPM** 模块状态，不用 CLI 状态代替网站运行环境。Debian 12 默认 PHP 8.2，Debian 13 默认 PHP 8.4，补丁版本随系统仓库更新。Redis 扩展是客户端，**不包含 Redis 服务端**。

一键安装环境默认勾选“同时安装 SG / SourceGuardian Loader”，阅读并同意 Loader 使用条款后开始安装，也可取消 SG 选择。SG 从官方 HTTPS 下载，匹配 Debian amd64 的 PHP-FPM 8.2/8.4；验证文件类型及加载状态后重新加载 PHP-FPM，失败恢复原扩展配置。SG 安装失败时基础环境保留，可在设置页重试。已有加载成功的 SG 保留，暂不自动升级它或配置 CLI；加密程序仍须兼容当前 PHP 版本并具备自身授权。

**旧服务器升级面板不会自动重装环境。** 升级后进入「面板设置」，点击「安装 / 补全常用扩展」；需要 SG 时点击「安装 SG / SourceGuardian」。安装会重新加载 PHP-FPM。模块旁的“已加载”表示检测到模块，不表示 Redis 服务端已启动或加密业务程序已验收。

- [SourceGuardian 官方 Loader](https://www.sourceguardian.com/loaders.html)
- [SourceGuardian Loader 使用条款](https://www.sourceguardian.com/termsloaders.html)

## URL Rewrite、网站删除与数据库维护

网站 → **URL Rewrite**：支持通用 PHP/Laravel、WordPress、纯静态模板，也可填写自定义 `rewrite` 和 `try_files`。规则放在 `location /` 内，每行一条、以分号结尾，最多 4096 字符、最多一条 `try_files`；暂不支持 `location` / `if` 块、花括号正则或行内注释。空白恢复默认 PHP 规则。保存时执行 `nginx -t`，失败保留原配置；暂停的网站也校验规则。修改根目录、开关 SSL/强制 HTTPS 和暂停恢复均保留规则。WordPress 模板不覆盖多站点等复杂配置。

网站 → **删除**：删除面板记录与该域名 Nginx 配置，停止面板为该域名续期；网站文件、证书、数据库和 DNS 记录保留。需要继续使用时重新添加域名并指定原目录。域名删除后 Nginx 默认站点行为取决于其余配置，不保证旧域名一定无法连到服务器。

数据库列表每行提供 **导出 SQL / 导入 SQL / 删除**：

- 导出在服务器临时文件完成后才开始下载，不在内存组装整个备份；包含表、数据、触发器、存储过程和事件。`--single-transaction` 适合 InnoDB；导出期间不要执行 DDL，非事务表需要维护窗口或其他一致性备份办法。磁盘需能容纳临时 SQL，导出执行上限 30 分钟。
- 导入接受未压缩 `.sql`，输入目标库名确认，完整上传后才执行 SQL。通过仅授权目标数据库的临时用户运行，禁止客户端 shell/source 指令和 LOCAL INFILE；不会以 MySQL root 执行上传的 SQL。含跨库操作、其他账号 DEFINER 或需要全局权限的语句会失败；含视图/过程/事件的跨账号备份可能需要由管理员用 SSH 审核处理，不能承诺任意备份一键恢复。
- 导入可能覆盖或删除表，**先导出备份**。执行上限 30 分钟，失败可能已写入部分数据，不能自动回滚；连接中断后先检查结果，不要盲目再次导入。临时 SQL / 凭据正常清理；若临时账号清理失败会明确报出账号名。
- 删除需输入完整数据库名，将删除整个数据库与同名面板账号，**无法撤销**。仅支持面板记录的数据库；部分删除失败会保留记录供检查重试。

